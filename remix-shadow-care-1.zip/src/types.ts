export type Language = 'ar' | 'en';

export interface PatentClaimItem {
  id: number;
  titleAr: string;
  titleEn: string;
  claimNumber: string;
  summaryAr: string;
  summaryEn: string;
  status: 'active' | 'synced' | 'standby';
  category: 'Vital' | 'Pharmacology' | 'Biomechanics' | 'AudioFirst' | 'Security' | 'EcoSports' | 'Emergency';
}

export interface CurrentVitals {
  heartRate: number; // BPM
  spo2: number; // %
  bloodPressureSystolic: number; // mmHg
  bloodPressureDiastolic: number; // mmHg
  temperature: number; // °C
  respiratoryRate: number; // resp/min
  stressLevel: number; // %
  hrvIndex: number; // ms
  bodyEnergy: number; // % (Ready Index)
  postureNeckAngle: number; // degrees
  spineAlignmentScore: number; // %
  failSafeBufferPercent: number; // % battery reserved for emergency
}

export interface FamilyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
  isHouseResident: boolean;
  notifyPriority: number;
}

export interface PatientProfile {
  name: string;
  idNumber: string;
  age: number;
  gender: string;
  bloodGroup: string;
  heightCm: number;
  weightKg: number;
  emergencyContactName: string;
  emergencyContactPhone: string;
  emergencyContactRelation: string;
  familyContacts: FamilyContact[];
  autoEscalateOfficial: boolean;
  escalationTimeoutSeconds: number;
  doctorName: string;
  doctorSpecialty: string;
  allergies: string[];
  chronicConditions: string[];
  targetHeartRateMin?: number;
  targetHeartRateMax?: number;
  targetBpSystolicMax?: number;
  targetBpDiastolicMax?: number;
  targetWaterIntakeMl?: number;
}

export interface MedicationItem {
  id: string;
  nameAr: string;
  nameEn: string;
  dosage: string;
  frequency: string;
  timeSlot: string;
  takenToday: boolean;
  type: 'chronic' | 'vitamin' | 'supplement';
  crossInteractionWarningAr?: string;
  crossInteractionWarningEn?: string;
}

export interface VisionScanResult {
  type: 'food' | 'coffee' | 'medication';
  titleAr: string;
  titleEn: string;
  riskLevel: 'green' | 'yellow' | 'red';
  audioAlertAr: string;
  audioAlertEn: string;
  detailsAr: string;
  detailsEn: string;
  timestamp: string;
  imageUrl?: string;
}

export interface EcoWeatherData {
  locationNameAr: string;
  locationNameEn: string;
  temperatureC: number;
  humidityPercent: number;
  heatIndexC: number;
  altitudeMeters: number;
  uvIndex: number;
  airQualityIndex: number;
  heatStressRisk: 'low' | 'moderate' | 'high' | 'critical';
}

export interface EmergencyAlert {
  id: string;
  timestamp: string;
  timeAgo: string;
  severity: 'info' | 'warning' | 'critical';
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  metric: string;
  metricValue: string;
  acknowledged: boolean;
  actionTaken?: string;
}

export interface LegalLedgerEntry {
  id: string;
  timestamp: string;
  claimRef: string;
  eventAr: string;
  eventEn: string;
  userResponse: string;
  encryptedHash: string;
}

export interface CaffeineLogItem {
  id: string;
  nameAr: string;
  nameEn: string;
  caffeineMg: number;
  time: string;
  type: 'espresso' | 'americano' | 'turkish' | 'tea' | 'energy' | 'custom';
}

export interface VitaminSupplementItem {
  id: string;
  nameAr: string;
  nameEn: string;
  dosage: string;
  category: 'vitamin' | 'supplement' | 'mineral';
  timeSlot: string;
  takenToday: boolean;
  bestTakenWithAr: string;
  bestTakenWithEn: string;
  benefitsAr: string;
  benefitsEn: string;
}

export interface ScheduleEventItem {
  id: string;
  time: string;
  titleAr: string;
  titleEn: string;
  category: 'morning_charge' | 'medication' | 'caffeine_window' | 'work_posture' | 'workout' | 'sleep_shield' | 'custom';
  completed: boolean;
  energyBudgetPercent: number;
  priority: 'normal' | 'high' | 'critical';
  notesAr?: string;
  notesEn?: string;
}

