import React, { useEffect, useState } from 'react';
import { BatteryCharging, ShieldAlert } from 'lucide-react';
import { BreathingExerciseOverlay } from './components/BreathingExerciseOverlay';
import { ClinicPassModal } from './components/ClinicPassModal';
import { Navbar } from './components/Navbar';
import { OrangeActionButton } from './components/OrangeActionButton';
import { PatentClaimsModal } from './components/PatentClaimsModal';
import { PatientProfileModal } from './components/PatientProfileModal';
import { PersistentVitalsToastSystem } from './components/PersistentVitalsToastSystem';
import { Screen1Readiness } from './components/Screen1Readiness';
import { Screen2HeartRate } from './components/Screen2HeartRate';
import { Screen3SafeMed } from './components/Screen3SafeMed';
import { Screen4VisionScanner } from './components/Screen4VisionScanner';
import { Screen5EcoSportsRadar } from './components/Screen5EcoSportsRadar';
import { Screen6Subscription } from './components/Screen6Subscription';
import { SOSModal } from './components/SOSModal';
import { VisualHapticFeedback } from './components/VisualHapticFeedback';
import { WeeklyDigestOverlay } from './components/WeeklyDigestOverlay';
import { initialEcoWeatherData, initialLegalLedger, initialMedications, initialPatentClaims, initialPatientProfile } from './data/initialData';
import { CurrentVitals, EcoWeatherData, Language, LegalLedgerEntry, MedicationItem, PatentClaimItem, PatientProfile } from './types';

export default function App() {
  const [language, setLanguage] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<string>('readiness');
  const [ultraBatterySaver, setUltraBatterySaver] = useState<boolean>(false);
  const [hapticTriggerToken, setHapticTriggerToken] = useState<number>(0);

  // Core Vitals State
  const [vitals, setVitals] = useState<CurrentVitals>({
    heartRate: 74,
    spo2: 98,
    bloodPressureSystolic: 122,
    bloodPressureDiastolic: 80,
    temperature: 36.8,
    respiratoryRate: 16,
    stressLevel: 22,
    hrvIndex: 68,
    bodyEnergy: 88,
    postureNeckAngle: 12,
    spineAlignmentScore: 92,
    failSafeBufferPercent: 15,
  });

  const [patientProfile, setPatientProfile] = useState<PatientProfile>(initialPatientProfile);
  const [medications, setMedications] = useState<MedicationItem[]>(initialMedications);
  const [ecoWeather, setEcoWeather] = useState<EcoWeatherData>(initialEcoWeatherData);
  const [patentClaims, setPatentClaims] = useState<PatentClaimItem[]>(initialPatentClaims);
  const [legalLedger, setLegalLedger] = useState<LegalLedgerEntry[]>(initialLegalLedger);

  // Modals state
  const [isSOSOpen, setIsSOSOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isPatentModalOpen, setIsPatentModalOpen] = useState<boolean>(false);
  const [isClinicPassOpen, setIsClinicPassOpen] = useState<boolean>(false);
  const [isBreathingOverlayOpen, setIsBreathingOverlayOpen] = useState<boolean>(false);
  const [breathingTriggerReason, setBreathingTriggerReason] = useState<string | undefined>(undefined);
  const [isWeeklyDigestOpen, setIsWeeklyDigestOpen] = useState<boolean>(false);

  // Automatic Sunset Night Mode State
  const [autoNightMode, setAutoNightMode] = useState<boolean>(true);
  const [manualNightModeOverride, setManualNightModeOverride] = useState<boolean | null>(null);

  // Check local time vs local sunset (sunset at ~18:30)
  const currentHour = new Date().getHours();
  const isSunsetTime = currentHour >= 18 || currentHour < 6;
  const isLowBlueLightActive =
    manualNightModeOverride !== null
      ? manualNightModeOverride
      : autoNightMode && isSunsetTime;

  const toggleNightModeOverride = () => {
    setManualNightModeOverride((prev) => (prev === true ? false : true));
  };

  // Auto-trigger Weekly Digest overlay if today is Sunday
  useEffect(() => {
    const isSunday = new Date().getDay() === 0;
    const hasSeenToday = sessionStorage.getItem('hasSeenSundayDigest');
    if (isSunday && !hasSeenToday) {
      setIsWeeklyDigestOpen(true);
      sessionStorage.setItem('hasSeenSundayDigest', 'true');
    }
  }, []);

  const handleOpenBreathingOverlay = (reason?: string) => {
    setBreathingTriggerReason(reason);
    setIsBreathingOverlayOpen(true);
  };

  const isAr = language === 'ar';

  // Text-To-Speech Output Helper
  const triggerSpeech = (textMessage: string) => {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(textMessage);
        utterance.lang = isAr ? 'ar-SA' : 'en-US';
        utterance.rate = 1.0;
        utterance.volume = 1.0;
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        // Speech restriction fallback
      }
    }
  };

  // Real-Time Live Vital Oscillation Ticks
  useEffect(() => {
    const tickInterval = ultraBatterySaver ? 6000 : 3000;

    const interval = setInterval(() => {
      setVitals((prev) => {
        const hrDelta = Math.floor(Math.random() * 5) - 2;
        const newHR = Math.max(55, Math.min(145, prev.heartRate + hrDelta));

        const spo2Delta = Math.random() > 0.8 ? (Math.random() > 0.5 ? 1 : -1) : 0;
        const newSpo2 = Math.max(88, Math.min(100, prev.spo2 + spo2Delta));

        const tempDelta = Number((Math.random() * 0.1 - 0.05).toFixed(1));
        const newTemp = Number(Math.max(36.2, Math.min(39.2, prev.temperature + tempDelta)).toFixed(1));

        return {
          ...prev,
          heartRate: newHR,
          spo2: newSpo2,
          temperature: newTemp,
        };
      });
    }, tickInterval);

    return () => clearInterval(interval);
  }, [ultraBatterySaver]);

  // Handler for Manual Vital Updates
  const handleUpdateVitals = (partial: Partial<CurrentVitals>) => {
    setVitals((prev) => ({ ...prev, ...partial }));
  };

  // Toggle Medication Item
  const handleToggleMedication = (id: string) => {
    setMedications((prev) =>
      prev.map((m) => (m.id === id ? { ...m, takenToday: !m.takenToday } : m))
    );
  };

  // Spike Trigger Simulation (Tachycardia / Hypoxia)
  const handleSimulateSpike = (type?: 'tachycardia' | 'hypoxia' | 'fever') => {
    setHapticTriggerToken((prev) => prev + 1);
    if (type === 'hypoxia') {
      handleUpdateVitals({ spo2: 89, bodyEnergy: 32 });
      triggerSpeech(
        isAr
          ? `تحذير طارئ لـ ${patientProfile.name}. انخفاض حاد في أكسجين الدم لـ تسعة وثمانين بالمئة!`
          : `Emergency Alert for ${patientProfile.name}. Acute oxygen drop to 89 percent!`
      );
    } else if (type === 'fever') {
      handleUpdateVitals({ temperature: 38.9, bodyEnergy: 45 });
      triggerSpeech(
        isAr
          ? `تنبيه صحي لـ ${patientProfile.name}. ارتفاع في حرارة الجسم إلى ثمانية وثلاثين وثمانية أعشار.`
          : `Health alert for ${patientProfile.name}. Body temperature elevated to 38.9°C.`
      );
    } else {
      handleUpdateVitals({ heartRate: 138, bodyEnergy: 28 });
      triggerSpeech(
        isAr
          ? `تحذير طارئ لـ ${patientProfile.name}. تسارع حاد في النبض إلى مائة وثمانية وثلاثين نبضة!`
          : `Emergency alert for ${patientProfile.name}. Acute pulse spike to 138 BPM!`
      );
    }
  };

  return (
    <div
      id="app-root-container"
      dir={isAr ? 'rtl' : 'ltr'}
      style={{
        filter: isLowBlueLightActive
          ? 'sepia(0.35) saturate(0.65) contrast(1.18) brightness(0.93)'
          : 'none',
        transition: 'filter 0.5s ease-in-out',
      }}
      className={`min-h-screen flex flex-col font-sans selection:bg-cyan-500 selection:text-black transition-colors ${
        ultraBatterySaver ? 'bg-black text-emerald-300' : 'bg-[#080d1a] text-slate-100'
      }`}
    >
      {/* Low Blue Light Night Mode Auto-Sunset Notification Banner */}
      {isLowBlueLightActive && (
        <div className="bg-amber-950/90 border-b border-amber-500/50 py-1.5 px-4 text-center text-xs text-amber-200 font-bold flex items-center justify-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          <span>
            {isAr
              ? '🌙 الوضع الليلي التلقائي (Low Blue Light Filter) نشط لمنع إجهاد العين وحماية الميلاتونين'
              : '🌙 Automatic Sunset Night Mode Active (Low Blue Light Monochrome Filter for Melatonin Protection)'}
          </span>
          <button
            onClick={toggleNightModeOverride}
            className="mr-3 underline text-amber-300 hover:text-white"
          >
            {isAr ? 'إيقاف الفلتر' : 'Turn Off'}
          </button>
        </div>
      )}

      {/* Ultra Battery Saver Banner */}
      {ultraBatterySaver && (
        <div className="bg-emerald-950 border-b border-emerald-500/50 py-2 px-4 text-center text-xs text-emerald-300 font-bold flex items-center justify-center gap-2 animate-pulse">
          <BatteryCharging className="w-4 h-4 text-emerald-400" />
          <span>
            {isAr
              ? `⚡ وضع التوفير الفائق للبطارية نشط - تمديد بطارية السوار حتى 14 يوماً لـ (${patientProfile.name})`
              : `⚡ Ultra Battery Saver active - Extended watch runtime up to 14 days for ${patientProfile.name}`}
          </span>
          <button
            onClick={() => setUltraBatterySaver(false)}
            className="mr-3 underline hover:text-white"
          >
            {isAr ? 'إيقاف' : 'Disable'}
          </button>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        setLanguage={setLanguage}
        patientProfile={patientProfile}
        ultraBatterySaver={ultraBatterySaver}
        setUltraBatterySaver={setUltraBatterySaver}
        autoNightMode={autoNightMode}
        setAutoNightMode={setAutoNightMode}
        isLowBlueLightActive={isLowBlueLightActive}
        onToggleNightModeOverride={toggleNightModeOverride}
        onOpenSOS={() => setIsSOSOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenPatentModal={() => setIsPatentModalOpen(true)}
        onOpenWeeklyDigest={() => setIsWeeklyDigestOpen(true)}
      />

      {/* Main Screen Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6">
        
        {/* Screen 1: Readiness & Daily Effort */}
        {activeTab === 'readiness' && (
          <Screen1Readiness
            language={language}
            vitals={vitals}
            patientProfile={patientProfile}
            onUpdateVitals={handleUpdateVitals}
            onTriggerSpeech={triggerSpeech}
            onOpenSOSModal={() => setIsSOSOpen(true)}
            onOpenBreathingOverlay={handleOpenBreathingOverlay}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* Screen 2: Heart Rate & Vital Effort */}
        {activeTab === 'heartrate' && (
          <Screen2HeartRate
            language={language}
            vitals={vitals}
            patientProfile={patientProfile}
            onSimulateSpike={handleSimulateSpike}
            onTriggerSpeech={triggerSpeech}
            onOpenClinicPass={() => setIsClinicPassOpen(true)}
            onOpenBreathingOverlay={handleOpenBreathingOverlay}
          />
        )}

        {/* Screen 3: Safe-Med Medications */}
        {activeTab === 'safemed' && (
          <Screen3SafeMed
            language={language}
            vitals={vitals}
            medications={medications}
            patientProfile={patientProfile}
            onToggleMedication={handleToggleMedication}
            onTriggerSpeech={triggerSpeech}
            onUpdateVitals={handleUpdateVitals}
          />
        )}

        {/* Screen 4: Vision AI Fast Scanner */}
        {activeTab === 'scanner' && (
          <Screen4VisionScanner
            language={language}
            patientProfile={patientProfile}
            onTriggerSpeech={triggerSpeech}
          />
        )}

        {/* Screen 5: Driving Safety, Swimming, Climbing & Eco Weather */}
        {activeTab === 'ecosports' && (
          <Screen5EcoSportsRadar
            language={language}
            vitals={vitals}
            ecoWeather={ecoWeather}
            patientProfile={patientProfile}
            onTriggerSpeech={triggerSpeech}
          />
        )}

        {/* Screen 6: Subscription PRO ($00.00 Placeholder) */}
        {activeTab === 'subscription' && (
          <Screen6Subscription
            language={language}
            patientProfile={patientProfile}
            onTriggerSpeech={triggerSpeech}
          />
        )}

      </main>

      {/* Watch Ultra Signature Floating Orange Action Button (Audio-First Controller) */}
      <OrangeActionButton
        language={language}
        onNavigateTab={setActiveTab}
        vitals={vitals}
        patientProfile={patientProfile}
        medications={medications}
        onTriggerSpeech={triggerSpeech}
      />

      {/* Clinic Pass Modal (Patent Claim 13) */}
      <ClinicPassModal
        isOpen={isClinicPassOpen}
        onClose={() => setIsClinicPassOpen(false)}
        language={language}
        patientProfile={patientProfile}
        vitals={vitals}
        medications={medications}
      />

      {/* Patent Claims & Compliance Web Modal */}
      <PatentClaimsModal
        isOpen={isPatentModalOpen}
        onClose={() => setIsPatentModalOpen(false)}
        language={language}
        claims={patentClaims}
        ledger={legalLedger}
      />

      {/* Emergency SOS Modal */}
      <SOSModal
        isOpen={isSOSOpen}
        onClose={() => setIsSOSOpen(false)}
        patientProfile={patientProfile}
      />

      {/* Patient Profile Modal */}
      <PatientProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={patientProfile}
        onSaveProfile={setPatientProfile}
      />

      {/* Guided 4-7-8 Breathing Exercise Interactive Overlay */}
      <BreathingExerciseOverlay
        isOpen={isBreathingOverlayOpen}
        onClose={() => setIsBreathingOverlayOpen(false)}
        language={language}
        vitals={vitals}
        onUpdateVitals={handleUpdateVitals}
        onTriggerSpeech={triggerSpeech}
        initialReason={breathingTriggerReason}
      />

      {/* Visual Haptic Watch Vibration & Alert Pulsing Feedback */}
      <VisualHapticFeedback
        language={language}
        vitals={vitals}
        patientProfile={patientProfile}
        hapticTriggerToken={hapticTriggerToken}
        onTriggerSpeech={triggerSpeech}
      />

      {/* 15+ Minute Continuous Vitals Anomaly Toast System */}
      <PersistentVitalsToastSystem
        language={language}
        vitals={vitals}
        patientProfile={patientProfile}
        onOpenBreathingOverlay={handleOpenBreathingOverlay}
        onTriggerSpeech={triggerSpeech}
      />

      {/* Sunday Weekly Digest & Adherence Summary Overlay */}
      <WeeklyDigestOverlay
        isOpen={isWeeklyDigestOpen}
        onClose={() => setIsWeeklyDigestOpen(false)}
        language={language}
        patientProfile={patientProfile}
        medications={medications}
        vitals={vitals}
        onTriggerSpeech={triggerSpeech}
      />

      {/* Footer */}
      <footer
        className={`border-t py-4 px-4 text-center text-xs ${
          ultraBatterySaver
            ? 'border-emerald-950 bg-black text-emerald-600'
            : 'border-slate-900 bg-slate-950 text-slate-500'
        }`}
      >
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            {isAr
              ? `Shadow Care Medical System © ${new Date().getFullYear()} • متابعة صحة (${patientProfile.name})`
              : `Shadow Care Medical System © ${new Date().getFullYear()} • Monitoring ${patientProfile.name}`}
          </span>
          <span className="font-mono text-[11px] text-cyan-500/80">
            {isAr
              ? 'تشفير بياني محلي آمن 100% • متوافق مع بنود براءة الاختراع الـ 19'
              : '100% Local Encrypted Biometric Ledger • 19 Patent Claims Compliant'}
          </span>
        </div>
      </footer>
    </div>
  );
}
