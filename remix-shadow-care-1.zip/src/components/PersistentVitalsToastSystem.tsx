import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Clock, Wind, X, BellRing, ShieldAlert, Sparkles, Activity, CheckCircle2 } from 'lucide-react';
import { CurrentVitals, Language, PatientProfile } from '../types';

interface PersistentVitalsToastSystemProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  onOpenBreathingOverlay: (reason?: string) => void;
  onTriggerSpeech: (text: string) => void;
}

export const PersistentVitalsToastSystem: React.FC<PersistentVitalsToastSystemProps> = ({
  language,
  vitals,
  patientProfile,
  onOpenBreathingOverlay,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  const hrMin = patientProfile.targetHeartRateMin ?? 60;
  const hrMax = patientProfile.targetHeartRateMax ?? 100;
  const maxStress = 55; // Stress threshold target

  const isHrOutOfRange = vitals.heartRate < hrMin || vitals.heartRate > hrMax;
  const isStressOutOfRange = vitals.stressLevel > maxStress;
  const isCurrentlyOutOfRange = isHrOutOfRange || isStressOutOfRange;

  // Track seconds out of range
  const [secondsOutOfRange, setSecondsOutOfRange] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [simulatedOffsetSeconds, setSimulatedOffsetSeconds] = useState<number>(0);
  const hasSpokenAlertRef = useRef<boolean>(false);

  // Timer tick for real-time accumulation
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isCurrentlyOutOfRange) {
      interval = setInterval(() => {
        setSecondsOutOfRange((prev) => prev + 1);
      }, 1000);
    } else {
      setSecondsOutOfRange(0);
      setSimulatedOffsetSeconds(0);
      hasSpokenAlertRef.current = false;
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCurrentlyOutOfRange]);

  const totalEffectiveSeconds = secondsOutOfRange + simulatedOffsetSeconds;
  const effectiveMinutes = Math.floor(totalEffectiveSeconds / 60);

  // Trigger 15-minute continuous alert threshold
  const is15MinThresholdReached = isCurrentlyOutOfRange && effectiveMinutes >= 15;

  // Trigger speech once when 15 minute threshold is passed
  useEffect(() => {
    if (is15MinThresholdReached && !hasSpokenAlertRef.current && !isMuted) {
      hasSpokenAlertRef.current = true;
      const alertMsg = isAr
        ? `تحذير مستمر: القياسات الحيوية خارج النطاق المستهدف لأكثر من 15 دقيقة (${effectiveMinutes} دقيقة). يوصى ببدء تمرين التنفس.`
        : `Continuous warning: Vitals outside target range for over 15 minutes (${effectiveMinutes} mins). Breathing exercise recommended.`;
      onTriggerSpeech(alertMsg);
    }
  }, [is15MinThresholdReached, effectiveMinutes, isAr, isMuted, onTriggerSpeech]);

  // Fast demo simulation handlers
  const handleSimulate15MinSpike = () => {
    setSimulatedOffsetSeconds(15 * 60 + 20); // 15 mins 20 seconds
    hasSpokenAlertRef.current = false;
  };

  const handleResetTimer = () => {
    setSecondsOutOfRange(0);
    setSimulatedOffsetSeconds(0);
    setIsMuted(false);
  };

  return (
    <div className="fixed bottom-24 right-4 left-4 sm:left-auto sm:right-6 z-40 max-w-lg space-y-2 pointer-events-none">
      
      {/* Simulation Helper Tag for Reviewers */}
      {isCurrentlyOutOfRange && !is15MinThresholdReached && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="pointer-events-auto p-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-white text-xs backdrop-blur-md shadow-lg flex items-center justify-between gap-3"
        >
          <div className="flex items-center gap-2 text-[11px] text-slate-300">
            <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span>
              {isAr
                ? `مدة الخروج عن الهدف: ${Math.floor(totalEffectiveSeconds / 60)}د ${totalEffectiveSeconds % 60}ث`
                : `Out of range duration: ${Math.floor(totalEffectiveSeconds / 60)}m ${totalEffectiveSeconds % 60}s`}
            </span>
          </div>

          <button
            onClick={handleSimulate15MinSpike}
            className="px-2.5 py-1 rounded-xl bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-300 font-bold text-[10px] flex items-center gap-1 transition-all"
          >
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>{isAr ? 'محاكاة +15 دقيقة' : 'Simulate 15+ Mins'}</span>
          </button>
        </motion.div>
      )}

      {/* 15+ Minute Visual Warning Notification Toast */}
      <AnimatePresence>
        {is15MinThresholdReached && !isMuted && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.3 }}
            className="pointer-events-auto p-4 rounded-3xl bg-slate-900/95 border-2 border-amber-500 shadow-2xl backdrop-blur-xl text-white space-y-3 overflow-hidden relative"
          >
            {/* Top Amber Glow */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500 animate-pulse" />

            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center shrink-0 font-bold animate-pulse">
                  <AlertTriangle className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-mono font-bold">
                      CRITICAL DURATION ALERT (&gt;15 MINS)
                    </span>
                    <span className="text-[10px] font-mono font-bold text-amber-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      {effectiveMinutes} {isAr ? 'دقيقة متواصلة' : 'mins continuous'}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-white mt-1">
                    {isAr ? 'تنبيه استمرار عدم اتزان المؤشرات الحيوية' : 'Sustained Vitals Anomaly Warning'}
                  </h4>
                </div>
              </div>

              <button
                onClick={() => setIsMuted(true)}
                className="p-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
                title={isAr ? 'إغلاق التنبيه' : 'Dismiss Toast'}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
              {isAr
                ? `مؤشراتك الحيوية (${isHrOutOfRange ? `النبض: ${vitals.heartRate} BPM` : ''} ${isStressOutOfRange ? `التوتر: ${vitals.stressLevel}%` : ''}) مستمرة خارج النطاق المستهدف لأكثر من 15 دقيقة!`
                : `Your vital readings (${isHrOutOfRange ? `HR: ${vitals.heartRate} BPM` : ''} ${isStressOutOfRange ? `Stress: ${vitals.stressLevel}%` : ''}) have remained outside your target range for ${effectiveMinutes} consecutive minutes.`}
            </p>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  onOpenBreathingOverlay(
                    isAr
                      ? `تنبيه استمرار التوتر أكثر من 15 دقيقة (${effectiveMinutes} دقيقة) — خفّض النبض الآن`
                      : `Continuous 15+ Min Vitals Spike (${effectiveMinutes} mins) — Lower HR & Stress now`
                  );
                }}
                className="flex-1 py-2.5 px-3 rounded-2xl bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
              >
                <Wind className="w-4 h-4 text-white" />
                <span>{isAr ? 'بدء تمرين التنفس 4-7-8' : 'Start 4-7-8 Breathing'}</span>
              </button>

              <button
                onClick={() => {
                  onTriggerSpeech(
                    isAr
                      ? `تنبيه: قياساتك الحيوية خارج النطاق المستهدف منذ ${effectiveMinutes} دقيقة.`
                      : `Warning: Vitals outside target for ${effectiveMinutes} minutes.`
                  );
                }}
                className="p-2.5 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-400 transition-colors"
                title={isAr ? 'تشغيل التنبيه الصوتي' : 'Play Voice Warning'}
              >
                <BellRing className="w-4 h-4 text-cyan-400" />
              </button>

              <button
                onClick={handleResetTimer}
                className="py-2.5 px-3 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs font-bold transition-colors"
              >
                {isAr ? 'إعادة ضبط' : 'Reset'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
