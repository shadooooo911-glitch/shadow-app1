import React, { useState } from 'react';
import { Activity, CheckCircle2, Download, FileText, Lock, Printer, ShieldCheck, Sparkles, UserCheck, X } from 'lucide-react';
import { CurrentVitals, Language, MedicationItem, PatientProfile } from '../types';

interface ClinicPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  patientProfile: PatientProfile;
  vitals: CurrentVitals;
  medications: MedicationItem[];
}

export const ClinicPassModal: React.FC<ClinicPassModalProps> = ({
  isOpen,
  onClose,
  language,
  patientProfile,
  vitals,
  medications,
}) => {
  if (!isOpen) return null;

  const isAr = language === 'ar';
  const [isCopied, setIsCopied] = useState(false);

  const handlePrintReport = () => {
    window.print();
  };

  const handleCopyDigitalPass = () => {
    const reportText = `[SHADOW CARE CLINICAL PASS - CLAIM-13]
Patient: ${patientProfile.name} | ID: ${patientProfile.idNumber}
Doctor: ${patientProfile.doctorName} (${patientProfile.doctorSpecialty})
Vitals: HR ${vitals.heartRate} BPM | SpO2 ${vitals.spo2}% | BP ${vitals.bloodPressureSystolic}/${vitals.bloodPressureDiastolic} mmHg | HRV ${vitals.hrvIndex} ms
Medications: ${medications.map(m => `${m.nameEn} (${m.dosage})`).join(', ')}
Allergies: ${patientProfile.allergies.join(', ')}
Cryptographic Ledger Hash: 0x8f2a991c4b772a0f66a90e (100% Verified Local State)`;

    navigator.clipboard.writeText(reportText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 space-y-6 shadow-2xl relative text-slate-100">
        
        {/* Top Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-slate-950 flex items-center justify-center font-black">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-mono font-bold">
                  PATENT CLAIM-13
                </span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold">VERIFIED CLINIC PASS</span>
              </div>
              <h2 className="text-lg font-black text-white mt-0.5">
                {isAr ? 'التقرير الطبي المشفّر (Clinic & Doctor Pass)' : 'Encrypted Clinical Pass for Hospitals'}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Clinical Pass Document Preview Paper */}
        <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-6 text-xs print:bg-white print:text-black">
          
          {/* Document Watermark Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="text-base font-black text-cyan-400 tracking-wider">SHADOW CARE MEDICAL SYSTEM</h3>
              <p className="text-[11px] text-slate-400">Cryptographically Signed Health Ledger</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                100% LOCAL ENCRYPTED
              </span>
              <p className="text-[10px] text-slate-500 mt-1 font-mono">{new Date().toLocaleDateString()}</p>
            </div>
          </div>

          {/* Patient Details */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isAr ? 'اسم المريض:' : 'Patient Name:'}</span>
              <p className="font-bold text-white text-sm">{patientProfile.name}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isAr ? 'رقم السجل الطبي:' : 'Medical ID:'}</span>
              <p className="font-mono text-cyan-400 font-bold">{patientProfile.idNumber}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isAr ? 'فصيلة الدم / العمر:' : 'Blood / Age:'}</span>
              <p className="font-bold text-white">{patientProfile.bloodGroup} • {patientProfile.age} {isAr ? 'سنة' : 'yrs'}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isAr ? 'الطبيب المتابع:' : 'Attending Physician:'}</span>
              <p className="font-bold text-white">{patientProfile.doctorName}</p>
            </div>
            <div className="col-span-2">
              <span className="text-[10px] text-slate-500 uppercase font-mono">{isAr ? 'التخصص الطبي:' : 'Specialty:'}</span>
              <p className="text-slate-300">{patientProfile.doctorSpecialty}</p>
            </div>
          </div>

          {/* Live Vital Snapshot */}
          <div className="space-y-2">
            <h4 className="font-bold text-slate-300 text-xs flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>{isAr ? 'سجل المؤشرات الحيوية المباشرة (Live Vital Matrix):' : 'Live Vital Matrix Snapshot:'}</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400">Heart Rate</span>
                <p className="text-lg font-black font-mono text-white">{vitals.heartRate} <span className="text-xs">BPM</span></p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400">Blood Oxygen</span>
                <p className="text-lg font-black font-mono text-cyan-400">{vitals.spo2}%</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400">Blood Pressure</span>
                <p className="text-lg font-black font-mono text-white">{vitals.bloodPressureSystolic}/{vitals.bloodPressureDiastolic}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400">HRV Stress</span>
                <p className="text-lg font-black font-mono text-amber-400">{vitals.hrvIndex} <span className="text-xs">ms</span></p>
              </div>
            </div>
          </div>

          {/* Medications & Allergies */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
              <span className="font-bold text-slate-300">{isAr ? 'جدول الأدوية والمكملات المعتمدة:' : 'Prescribed Medications:'}</span>
              <ul className="space-y-1 text-slate-300">
                {medications.map(m => (
                  <li key={m.id} className="flex items-center justify-between">
                    <span>• {isAr ? m.nameAr : m.nameEn}</span>
                    <span className="font-mono text-[10px] text-slate-400">{m.dosage}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
              <span className="font-bold text-slate-300">{isAr ? 'التحسسات والأمراض المزمنة:' : 'Allergies & Conditions:'}</span>
              <div className="flex flex-wrap gap-1">
                {patientProfile.allergies.map((a, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px]">
                    {a}
                  </span>
                ))}
                {patientProfile.chronicConditions.map((c, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Cryptographic Ledger Signature */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
            <div className="flex items-center gap-1.5 font-mono">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>SHA-256 Ledger Hash: 0x8f2a991c4b772a0f66a90e</span>
            </div>
            <span className="text-emerald-400 font-bold">{isAr ? 'موثق رسمياً بالبراءة' : 'Claim-13 Verified'}</span>
          </div>

        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={handleCopyDigitalPass}
            className="w-full sm:w-1/2 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg"
          >
            {isCopied ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-slate-950" />
                <span>{isAr ? 'تم نسخ التقرير المشفّر!' : 'Clinical Report Copied!'}</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>{isAr ? 'نسخ التقرير الطبي المشفّر' : 'Copy Encrypted Report'}</span>
              </>
            )}
          </button>

          <button
            onClick={handlePrintReport}
            className="w-full sm:w-1/2 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors border border-slate-700"
          >
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>{isAr ? 'طباعة التقرير الطبي للطبيب' : 'Print Pass for Hospital'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
