import React, { useEffect, useState } from 'react';
import { 
  Activity,
  AlertCircle, 
  Check, 
  Droplets,
  Edit2, 
  FileText, 
  HeartPulse,
  Home, 
  Phone, 
  Plus, 
  Save, 
  ShieldAlert, 
  Stethoscope, 
  Target,
  Trash2, 
  User, 
  UserCheck, 
  Users, 
  X 
} from 'lucide-react';
import { FamilyContact, PatientProfile } from '../types';

interface PatientProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: PatientProfile;
  onSaveProfile: (updated: PatientProfile) => void;
}

export const PatientProfileModal: React.FC<PatientProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSaveProfile,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState<PatientProfile>(profile);

  // New Contact local form states
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactRelation, setNewContactRelation] = useState('');
  const [newIsHouseResident, setNewIsHouseResident] = useState(true);

  useEffect(() => {
    setEditedProfile(profile);
  }, [profile, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveProfile(editedProfile);
    setIsEditing(false);
  };

  const handleAddFamilyContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName || !newContactPhone) return;

    const newContact: FamilyContact = {
      id: `fc-${Date.now()}`,
      name: newContactName,
      phone: newContactPhone,
      relation: newContactRelation || (newIsHouseResident ? 'مقيم/مقيمة بالمنزل' : 'قريب'),
      isHouseResident: newIsHouseResident,
      notifyPriority: newIsHouseResident ? 1 : 2,
    };

    const updated = {
      ...editedProfile,
      familyContacts: [...(editedProfile.familyContacts || []), newContact],
    };

    setEditedProfile(updated);
    onSaveProfile(updated);

    setNewContactName('');
    setNewContactPhone('');
    setNewContactRelation('');
  };

  const handleDeleteFamilyContact = (id: string) => {
    const updated = {
      ...editedProfile,
      familyContacts: (editedProfile.familyContacts || []).filter((c) => c.id !== id),
    };
    setEditedProfile(updated);
    onSaveProfile(updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto space-y-6">
        
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xl shadow-lg border border-cyan-400/30">
              <UserCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                {isEditing ? (
                  <input
                    type="text"
                    value={editedProfile.name}
                    onChange={(e) => setEditedProfile({ ...editedProfile, name: e.target.value })}
                    className="bg-slate-950 border border-cyan-500 rounded-xl px-3 py-1 text-base font-bold text-white focus:outline-none"
                    placeholder="اسم المستخدم (مثال: ريان)"
                  />
                ) : (
                  <h3 className="text-xl font-bold text-slate-100">{profile.name}</h3>
                )}
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40">
                  الملف الشامل
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">كود مستخدم Shadow Care #{profile.idNumber}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isEditing ? (
              <button
                onClick={handleSave}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-md"
              >
                <Save className="w-4 h-4" />
                <span>حفظ الملف</span>
              </button>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold text-xs border border-slate-700 transition-all"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>تعديل معلومات الاسم والبيانات</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Basic Vitals Grid (Editable or Viewable) */}
        <div className="space-y-4 text-xs">
          <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <User className="w-4 h-4 text-cyan-400" />
            <span>المعلومات الشخصية والجسدية الأساسية:</span>
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-500 block">العمر</span>
              {isEditing ? (
                <input
                  type="number"
                  value={editedProfile.age}
                  onChange={(e) => setEditedProfile({ ...editedProfile, age: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1 text-slate-100 font-bold font-mono mt-1"
                />
              ) : (
                <span className="text-slate-200 font-bold font-mono text-sm mt-0.5 block">{profile.age} سنة</span>
              )}
            </div>

            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-500 block">فصيلة الدم</span>
              {isEditing ? (
                <input
                  type="text"
                  value={editedProfile.bloodGroup}
                  onChange={(e) => setEditedProfile({ ...editedProfile, bloodGroup: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1 text-cyan-400 font-bold font-mono mt-1"
                />
              ) : (
                <span className="text-cyan-400 font-bold font-mono text-sm mt-0.5 block">{profile.bloodGroup}</span>
              )}
            </div>

            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-500 block">الطول</span>
              {isEditing ? (
                <input
                  type="number"
                  value={editedProfile.heightCm}
                  onChange={(e) => setEditedProfile({ ...editedProfile, heightCm: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1 text-slate-100 font-bold font-mono mt-1"
                />
              ) : (
                <span className="text-slate-200 font-bold font-mono text-sm mt-0.5 block">{profile.heightCm} سم</span>
              )}
            </div>

            <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
              <span className="text-slate-500 block">الوزن</span>
              {isEditing ? (
                <input
                  type="number"
                  value={editedProfile.weightKg}
                  onChange={(e) => setEditedProfile({ ...editedProfile, weightKg: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1 text-slate-100 font-bold font-mono mt-1"
                />
              ) : (
                <span className="text-slate-200 font-bold font-mono text-sm mt-0.5 block">{profile.weightKg} كجم</span>
              )}
            </div>
          </div>
        </div>

        {/* SECTION: Personalized Vital & Hydration Target Ranges (أهداف ونطاقات الرصد الحيوية المخصصة) */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-900/50 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
              <Target className="w-4 h-4 text-cyan-400" />
              <span>أهداف ونطاقات الرصد الحيوية المخصصة (Personalized Target Ranges & Goals)</span>
            </div>
            <span className="text-[10px] text-cyan-300 font-mono font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
              CUSTOM TARGETS
            </span>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            قم بتعيين النطاقات المستهدفة الخاصة بك لمعدل النبض وضغط الدم وشرب الماء لتفعيل الشارات والمؤشرات الملونة التفاعلية عبر التطبيق.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            
            {/* Target HR Range */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                <HeartPulse className="w-4 h-4 text-rose-400" />
                <span>نطاق النبض المستهدف</span>
              </div>
              {isEditing ? (
                <div className="flex items-center gap-1.5 font-mono text-xs">
                  <input
                    type="number"
                    value={editedProfile.targetHeartRateMin ?? 60}
                    onChange={(e) => setEditedProfile({ ...editedProfile, targetHeartRateMin: Number(e.target.value) })}
                    className="w-16 bg-slate-950 border border-slate-700 rounded p-1 text-slate-100 text-center font-bold"
                    placeholder="Min"
                  />
                  <span className="text-slate-500">-</span>
                  <input
                    type="number"
                    value={editedProfile.targetHeartRateMax ?? 100}
                    onChange={(e) => setEditedProfile({ ...editedProfile, targetHeartRateMax: Number(e.target.value) })}
                    className="w-16 bg-slate-950 border border-slate-700 rounded p-1 text-slate-100 text-center font-bold"
                    placeholder="Max"
                  />
                  <span className="text-slate-400">BPM</span>
                </div>
              ) : (
                <div className="text-sm font-mono font-bold text-emerald-400 pt-1">
                  {(profile.targetHeartRateMin ?? 60)} - {(profile.targetHeartRateMax ?? 100)} <span className="text-xs text-slate-400">BPM</span>
                </div>
              )}
            </div>

            {/* Target Blood Pressure Max */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                <Activity className="w-4 h-4 text-amber-400" />
                <span>الحد الأقصى لضغط الدم</span>
              </div>
              {isEditing ? (
                <div className="flex items-center gap-1 font-mono text-xs">
                  <input
                    type="number"
                    value={editedProfile.targetBpSystolicMax ?? 130}
                    onChange={(e) => setEditedProfile({ ...editedProfile, targetBpSystolicMax: Number(e.target.value) })}
                    className="w-14 bg-slate-950 border border-slate-700 rounded p-1 text-slate-100 text-center font-bold"
                    placeholder="Sys"
                  />
                  <span className="text-slate-500">/</span>
                  <input
                    type="number"
                    value={editedProfile.targetBpDiastolicMax ?? 85}
                    onChange={(e) => setEditedProfile({ ...editedProfile, targetBpDiastolicMax: Number(e.target.value) })}
                    className="w-14 bg-slate-950 border border-slate-700 rounded p-1 text-slate-100 text-center font-bold"
                    placeholder="Dia"
                  />
                  <span className="text-slate-400">mmHg</span>
                </div>
              ) : (
                <div className="text-sm font-mono font-bold text-amber-300 pt-1">
                  &le; {(profile.targetBpSystolicMax ?? 130)} / {(profile.targetBpDiastolicMax ?? 85)} <span className="text-xs text-slate-400">mmHg</span>
                </div>
              )}
            </div>

            {/* Target Water Intake Goal */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-xs">
                <Droplets className="w-4 h-4 text-cyan-400" />
                <span>هدف شرب الماء اليومي</span>
              </div>
              {isEditing ? (
                <div className="flex items-center gap-1.5 font-mono text-xs">
                  <input
                    type="number"
                    step="50"
                    value={editedProfile.targetWaterIntakeMl ?? 2500}
                    onChange={(e) => setEditedProfile({ ...editedProfile, targetWaterIntakeMl: Number(e.target.value) })}
                    className="w-24 bg-slate-950 border border-slate-700 rounded p-1 text-slate-100 text-center font-bold"
                  />
                  <span className="text-slate-400">ml</span>
                </div>
              ) : (
                <div className="text-sm font-mono font-bold text-cyan-300 pt-1">
                  {(profile.targetWaterIntakeMl ?? 2500)} <span className="text-xs text-slate-400">ml / day</span>
                </div>
              )}
            </div>

          </div>
        </div>

        {/* SECTION: Family & House Emergency Contacts (أرقام الأقارب والمقيمين بنفس المنزل) */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
              <Phone className="w-4 h-4" />
              <span>أرقام هواتف الأقارب والأشخاص المقيمين بنفس المنزل (Family & House Contacts)</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">
              {(editedProfile.familyContacts || []).length} جهات اتصال
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(editedProfile.familyContacts || []).map((contact) => (
              <div
                key={contact.id}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-200">{contact.name}</span>
                    {contact.isHouseResident && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        مقيم بالمنزل
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400">{contact.relation}</p>
                  <p className="text-xs font-mono text-cyan-400 font-bold dir-ltr mt-0.5">{contact.phone}</p>
                </div>

                <button
                  onClick={() => handleDeleteFamilyContact(contact.id)}
                  className="p-1.5 rounded-lg bg-slate-800 text-slate-500 hover:text-rose-400"
                  title="حذف الرقم"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Quick Add Form */}
          <form onSubmit={handleAddFamilyContact} className="pt-2 border-t border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-slate-300 block">إضافة رقم قريب / ساكن في المنزل جديد:</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="الاسم الكامل"
                value={newContactName}
                onChange={(e) => setNewContactName(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-500"
                required
              />
              <input
                type="tel"
                placeholder="رقم الهاتف"
                value={newContactPhone}
                onChange={(e) => setNewContactPhone(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-500 dir-ltr"
                required
              />
              <input
                type="text"
                placeholder="صلة القرابة"
                value={newContactRelation}
                onChange={(e) => setNewContactRelation(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-500"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newIsHouseResident}
                  onChange={(e) => setNewIsHouseResident(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-800 text-cyan-500 w-3.5 h-3.5"
                />
                <span>شخص مقيم في نفس المنزل</span>
              </label>

              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs"
              >
                إضافة الرقم
              </button>
            </div>
          </form>
        </div>

        {/* SECTION: Auto Escalation Setting (التصعيد التلقائي للطوارئ) */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
              <ShieldAlert className="w-4 h-4" />
              <span>التصعيد التلقائي للطوارئ الرسمية (Official Emergency Auto-Escalation)</span>
            </div>

            <button
              onClick={() => {
                const updated = { ...editedProfile, autoEscalateOfficial: !editedProfile.autoEscalateOfficial };
                setEditedProfile(updated);
                onSaveProfile(updated);
              }}
              className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                editedProfile.autoEscalateOfficial ? 'bg-rose-600' : 'bg-slate-800'
              }`}
            >
              <span
                className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform ${
                  editedProfile.autoEscalateOfficial ? '-translate-x-5' : '-translate-x-1'
                }`}
              />
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            عند التفعيل، يرسل النظام تنبيهاً للأقارب أولاً، وفي حال عدم الرد أو عدم إيقاف التنبيه بضغط زر "أنا بخير"، يتم التصعيد تلقائياً للجهات المعنية والطوارئ (997/911).
          </p>
        </div>

        {/* Primary Doctor & Medical Conditions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 text-indigo-400 font-bold">
              <Stethoscope className="w-3.5 h-3.5" />
              <span>الطبيب المعالج</span>
            </div>
            <p className="text-slate-200 font-semibold">{profile.doctorName}</p>
            <p className="text-slate-400">{profile.doctorSpecialty}</p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>الحساسية والحالات المتابعة</span>
            </div>
            <p className="text-slate-300">{profile.allergies.join(' ، ')}</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          <p className="text-[10px] text-slate-500">تم التحديث والتأمين بواسطة بروتوكول Shadow Care HD</p>
          <button
            onClick={onClose}
            className="py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-all"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
