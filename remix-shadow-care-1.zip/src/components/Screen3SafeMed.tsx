import React, { useState } from 'react';
import { AlertCircle, Check, CheckCircle2, Clock, Coffee, Lock, Moon, Pill, Plus, ShieldCheck, Sparkles } from 'lucide-react';
import { CaffeineTracker } from './CaffeineTracker';
import { SleepGuardAndRecoveryDashboard } from './SleepGuardAndRecoveryDashboard';
import { VitaminsSupplementsLog } from './VitaminsSupplementsLog';
import { CurrentVitals, Language, MedicationItem, PatientProfile } from '../types';

interface Screen3SafeMedProps {
  language: Language;
  vitals?: CurrentVitals;
  medications: MedicationItem[];
  patientProfile: PatientProfile;
  onToggleMedication: (id: string) => void;
  onTriggerSpeech: (text: string) => void;
  onUpdateVitals?: (vitals: Partial<CurrentVitals>) => void;
}

export const Screen3SafeMed: React.FC<Screen3SafeMedProps> = ({
  language,
  vitals,
  medications,
  patientProfile,
  onToggleMedication,
  onTriggerSpeech,
  onUpdateVitals,
}) => {
  const isAr = language === 'ar';
  const [subTab, setSubTab] = useState<'meds' | 'vitamins' | 'caffeine' | 'sleepguard'>('meds');

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-mono font-bold">
              PATENT CLAIM-03 & 09 (Safe-Med & Bio-Cocktail)
            </span>
            <span className="text-xs text-slate-400">الشاشة 3 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1 flex items-center gap-2">
            <Pill className="w-6 h-6 text-indigo-400" />
            <span>{isAr ? 'الأدوية المشفّرة، الفيتامينات وحاسبة الكافيين' : 'Encrypted Safe-Med, Vitamins & Caffeine Tracker'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `إدارة شاملة ومستقلة لأدوية القلب، الفيتامينات والمكملات، وتوازن الكافيين لـ (${patientProfile.name})`
              : `Comprehensive control for prescribed meds, vitamins/supplements, and caffeine tracker for ${patientProfile.name}`}
          </p>
        </div>

        {/* Doctor Info */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-right space-y-0.5">
          <div className="text-slate-400 font-bold">{patientProfile.doctorName}</div>
          <div className="text-[10px] text-cyan-400 font-mono">{patientProfile.doctorSpecialty}</div>
        </div>
      </div>

      {/* Sub-Tabs Switcher Bar */}
      <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-bold">
        <button
          onClick={() => setSubTab('meds')}
          className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
            subTab === 'meds'
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Pill className="w-4 h-4 text-indigo-300" />
          <span>{isAr ? '1. جدول الأدوية المزمنة' : '1. Chronic Prescribed Meds'}</span>
        </button>

        <button
          onClick={() => setSubTab('vitamins')}
          className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
            subTab === 'vitamins'
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{isAr ? '2. سجل الفيتامينات والمكملات' : '2. Vitamins & Supplements Log'}</span>
        </button>

        <button
          onClick={() => setSubTab('caffeine')}
          className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
            subTab === 'caffeine'
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Coffee className="w-4 h-4 text-amber-400" />
          <span>{isAr ? '3. حاسبة وتتبع الكافيين' : '3. Caffeine Tracker'}</span>
        </button>

        <button
          onClick={() => setSubTab('sleepguard')}
          className={`flex-1 py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all ${
            subTab === 'sleepguard'
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-black shadow-lg'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Moon className="w-4 h-4 text-indigo-400" />
          <span>{isAr ? '4. حامي النوم ومؤشر الطاقة' : '4. Sleep Guard & Body Battery'}</span>
        </button>
      </div>

      {/* Sub-Tab 1: Meds */}
      {subTab === 'meds' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Claim 3 Security Callout Banner */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-indigo-500/30 flex items-center gap-3">
            <Lock className="w-6 h-6 text-indigo-400 shrink-0" />
            <div className="text-xs text-slate-300 leading-relaxed">
              {isAr
                ? 'بروتوكول Claim-03 يعزل تأثيرات أدوية ضغط الدم والقلب والفيتامينات والقهوة عن المجهود البدني، لمنع القراءات المضللة، مع ضمان التشفير المحلي الكامل وتصفير تسريب البيانات.'
                : 'Claim-03 protocol isolates blood pressure, vitamins, and caffeine effects from physical exertion to prevent false spikes.'}
            </div>
          </div>

          {/* Medication Items List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white">
                {isAr ? 'جدول جرعات الأدوية والمكملات اليومية:' : 'Daily Prescribed Medication Doses:'}
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                {medications.filter((m) => m.takenToday).length} / {medications.length} {isAr ? 'تم أخذها' : 'Taken'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {medications.map((med) => (
                <div
                  key={med.id}
                  className={`p-5 rounded-2xl border transition-all space-y-4 ${
                    med.takenToday
                      ? 'bg-slate-950/80 border-emerald-500/50'
                      : 'bg-slate-900 border-slate-800 hover:border-indigo-500/50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        med.type === 'chronic' ? 'bg-rose-950 text-rose-300 border border-rose-800' :
                        med.type === 'vitamin' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                        'bg-indigo-950 text-indigo-300 border border-indigo-800'
                      }`}>
                        {med.type === 'chronic' ? (isAr ? 'علاج مزمن' : 'Chronic') :
                         med.type === 'vitamin' ? (isAr ? 'فيتامين' : 'Vitamin') : (isAr ? 'مكمل غذائي' : 'Supplement')}
                      </span>
                      <h4 className="text-base font-black text-white mt-2">
                        {isAr ? med.nameAr : med.nameEn}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">{med.dosage}</p>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">
                      <Clock className="w-3 h-3 text-cyan-400" />
                      <span>{med.timeSlot}</span>
                    </div>
                  </div>

                  {med.crossInteractionWarningAr && (
                    <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-800/60 text-[11px] text-indigo-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span>{isAr ? med.crossInteractionWarningAr : med.crossInteractionWarningEn}</span>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      onToggleMedication(med.id);
                      if (!med.takenToday) {
                        onTriggerSpeech(
                          isAr
                            ? `تم تسجيل أخذ جرعة ${med.nameAr} بنجاح وتوثيقها في السجل المشفّر.`
                            : `Logged intake of ${med.nameEn}.`
                        );
                      }
                    }}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                      med.takenToday
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/60'
                        : 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white hover:opacity-90 shadow-md'
                    }`}
                  >
                    {med.takenToday ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{isAr ? 'تم تناول الجرعة اليوم (تأكيد محلي)' : 'Dose Taken Today'}</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>{isAr ? 'تسجيل أخذ الجرعة الآن' : 'Log Dose Intake'}</span>
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Doctor Allergies & Chronic Notes */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-400">
              {isAr ? 'التاريخ الطبي والتحسسات الخاصة بـ ' + patientProfile.name + ':' : 'Medical History & Allergies:'}
            </h3>
            <div className="flex flex-wrap gap-2 text-xs">
              {patientProfile.allergies.map((alg, idx) => (
                <span key={idx} className="px-3 py-1 rounded-full bg-rose-950 text-rose-300 border border-rose-800 font-bold flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 text-rose-400" />
                  <span>{alg}</span>
                </span>
              ))}
              {patientProfile.chronicConditions.map((cond, idx) => (
                <span key={idx} className="px-3 py-1 rounded-full bg-slate-950 text-slate-300 border border-slate-800 font-bold">
                  {cond}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Vitamins & Supplements */}
      {subTab === 'vitamins' && (
        <VitaminsSupplementsLog
          language={language}
          patientProfile={patientProfile}
          onTriggerSpeech={onTriggerSpeech}
        />
      )}

      {/* Sub-Tab 3: Caffeine Tracker */}
      {subTab === 'caffeine' && (
        <CaffeineTracker
          language={language}
          patientProfile={patientProfile}
          onTriggerSpeech={onTriggerSpeech}
        />
      )}

      {/* Sub-Tab 4: Sleep Guard & Body Battery Drain */}
      {subTab === 'sleepguard' && vitals && onUpdateVitals && (
        <SleepGuardAndRecoveryDashboard
          language={language}
          vitals={vitals}
          patientProfile={patientProfile}
          onTriggerSpeech={onTriggerSpeech}
          onUpdateVitals={onUpdateVitals}
        />
      )}

    </div>
  );
};

