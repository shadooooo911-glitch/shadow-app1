import React, { useEffect, useState } from 'react';
import { Watch, Volume2, BellRing, Sparkles, AlertTriangle, ShieldAlert } from 'lucide-react';
import { CurrentVitals, Language, PatientProfile } from '../types';

interface VisualHapticFeedbackProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  hapticTriggerToken: number; // Incrementing counter to force trigger haptic
  onTriggerSpeech?: (text: string) => void;
}

export const VisualHapticFeedback: React.FC<VisualHapticFeedbackProps> = ({
  language,
  vitals,
  patientProfile,
  hapticTriggerToken,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  const [isHapticActive, setIsHapticActive] = useState<boolean>(false);
  const [hapticReason, setHapticReason] = useState<string>('');
  const [lastProcessedToken, setLastProcessedToken] = useState<number>(0);

  const hrMax = patientProfile.targetHeartRateMax ?? 100;
  const isAlertCondition = vitals.heartRate > hrMax || vitals.spo2 < 92 || vitals.temperature > 38.3;

  const triggerHapticVibration = (reasonText: string) => {
    setHapticReason(reasonText);
    setIsHapticActive(true);

    // Physical Device Haptic Vibration API
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([150, 80, 150, 80, 250]);
      } catch {
        // Fallback if blocked
      }
    }

    // Apply shake animation to document root element
    const appEl = document.getElementById('app-root-container');
    if (appEl) {
      appEl.classList.remove('animate-haptic-shake');
      // Trigger reflow
      void appEl.offsetWidth;
      appEl.classList.add('animate-haptic-shake');
      setTimeout(() => {
        appEl.classList.remove('animate-haptic-shake');
      }, 500);
    }

    // Auto dismiss glow/toast after 3.5 seconds
    setTimeout(() => {
      setIsHapticActive(false);
    }, 3500);
  };

  // Monitor explicit trigger token (e.g. user clicked test haptic or spike simulation)
  useEffect(() => {
    if (hapticTriggerToken > 0 && hapticTriggerToken !== lastProcessedToken) {
      setLastProcessedToken(hapticTriggerToken);
      const text = isAr
        ? 'تم تفعيل التنبيه النبضي اللمسي للساعة الذكية (Haptic Watch Vibration).'
        : 'Smartwatch Haptic Vibration Alert Triggered.';
      triggerHapticVibration(text);
    }
  }, [hapticTriggerToken, lastProcessedToken, isAr]);

  // Auto trigger haptic feedback on severe vital threshold breach
  useEffect(() => {
    if (isAlertCondition) {
      let reason = '';
      if (vitals.heartRate > hrMax) {
        reason = isAr
          ? `ارتفاع النبض (${vitals.heartRate} BPM) فوق الحد المستهدف (${hrMax} BPM)`
          : `High HR (${vitals.heartRate} BPM) exceeds target (${hrMax} BPM)`;
      } else if (vitals.spo2 < 92) {
        reason = isAr
          ? `انخفاض أكسجين الدم (${vitals.spo2}%)`
          : `Low SpO2 level (${vitals.spo2}%)`;
      } else if (vitals.temperature > 38.3) {
        reason = isAr
          ? `ارتفاع درجة الحرارة (${vitals.temperature}°C)`
          : `Elevated Body Temp (${vitals.temperature}°C)`;
      }
      triggerHapticVibration(reason);
    }
  }, [vitals.heartRate, vitals.spo2, vitals.temperature, hrMax, isAlertCondition]);

  if (!isHapticActive && !isAlertCondition) return null;

  return (
    <>
      {/* Viewport Edge Haptic Glow Pulse Border */}
      <div className="fixed inset-0 pointer-events-none z-40 border-4 border-rose-500/80 animate-haptic-border rounded-none shadow-[inset_0_0_50px_rgba(244,63,94,0.4)]" />

      {/* Smartwatch Wrist Vibration Floating Toast HUD */}
      <div className="fixed top-20 right-4 left-4 sm:left-auto sm:right-6 z-50 max-w-md animate-bounce">
        <div className="p-3.5 rounded-2xl bg-slate-900/95 border-2 border-rose-500 text-white shadow-2xl backdrop-blur-md flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-950 text-rose-400 border border-rose-800 flex items-center justify-center font-bold shrink-0 animate-pulse">
              <Watch className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800">
                  SMARTWATCH HAPTIC FEEDBACK
                </span>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              </div>
              <p className="text-xs font-black text-white mt-0.5">
                {hapticReason || (isAr ? 'اهتزاز لمسي لمعصم اليد تنبيه لارتفاع القياسات' : 'Smartwatch Wrist Vibration Active')}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (onTriggerSpeech) {
                onTriggerSpeech(
                  isAr
                    ? `محاكاة الاهتزاز اللمسي لمعصم اليد: ${hapticReason}`
                    : `Haptic vibration feedback active: ${hapticReason}`
                );
              }
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 shrink-0 transition-colors"
            title={isAr ? 'إعادة التنبيه الصوتي' : 'Replay Speech'}
          >
            <BellRing className="w-4 h-4" />
          </button>
        </div>
      </div>
    </>
  );
};
