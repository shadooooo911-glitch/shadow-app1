import React, { useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  Battery,
  BatteryCharging,
  Brain,
  CheckCircle2,
  Clock,
  Flame,
  Heart,
  Info,
  Moon,
  Plus,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { CurrentVitals, Language, PatientProfile } from '../types';

interface SleepGuardAndRecoveryDashboardProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
  onUpdateVitals: (newVitals: Partial<CurrentVitals>) => void;
}

interface ConsumptionLog {
  id: string;
  itemAr: string;
  itemEn: string;
  time: string;
  type: 'nicotine' | 'caffeine' | 'workout' | 'nap';
  energyDrain: number; // positive or negative
  hrvImpactMs: number;
}

export const SleepGuardAndRecoveryDashboard: React.FC<SleepGuardAndRecoveryDashboardProps> = ({
  language,
  vitals,
  patientProfile,
  onTriggerSpeech,
  onUpdateVitals,
}) => {
  const isAr = language === 'ar';

  // Bedtime & 8-Hour Cut-off state
  const [bedtime, setBedtime] = useState('11:00 PM');
  const cutoffTime = '03:00 PM'; // 8 hours before 11:00 PM

  // Nicotine & Stimulant Consumption Logs for Dynamic Drain
  const [sessionLogs, setSessionLogs] = useState<ConsumptionLog[]>([
    {
      id: 'log-1',
      itemAr: 'كوب قهوة أمريكانو (Americano)',
      itemEn: 'Americano Coffee',
      time: '10:15 AM',
      type: 'caffeine',
      energyDrain: -5,
      hrvImpactMs: -3,
    },
    {
      id: 'log-2',
      itemAr: 'أخذ كبسولة فيتامين (Vitamin D3)',
      itemEn: 'Vitamin D3 Capsule',
      time: '01:00 PM',
      type: 'nap',
      energyDrain: +5,
      hrvImpactMs: +2,
    },
  ]);

  // Selected Weekly View metric
  const [selectedMetric, setSelectedMetric] = useState<'hrv' | 'sleep' | 'stress'>('hrv');

  // Calculate Net Energy Drain / Charge from logs
  const totalDrain = sessionLogs.reduce((acc, log) => acc + log.energyDrain, 0);

  // Weekly Trend Mock Data (Comparison of Consumption vs Recovery)
  const weeklyTrendData = [
    { dayAr: 'الأحد', dayEn: 'Sun', caffeineMg: 120, nicotineUnits: 0, sleepScore: 88, hrvMs: 68, lateConsumption: false },
    { dayAr: 'الإثنين', dayEn: 'Mon', caffeineMg: 240, nicotineUnits: 1, sleepScore: 76, hrvMs: 58, lateConsumption: false },
    { dayAr: 'الثلاثاء', dayEn: 'Tue', caffeineMg: 310, nicotineUnits: 2, sleepScore: 61, hrvMs: 44, lateConsumption: true },
    { dayAr: 'الأربعاء', dayEn: 'Wed', caffeineMg: 170, nicotineUnits: 0, sleepScore: 84, hrvMs: 65, lateConsumption: false },
    { dayAr: 'الخميس', dayEn: 'Thu', caffeineMg: 280, nicotineUnits: 2, sleepScore: 59, hrvMs: 41, lateConsumption: true },
    { dayAr: 'الجمعة', dayEn: 'Fri', caffeineMg: 150, nicotineUnits: 0, sleepScore: 92, hrvMs: 72, lateConsumption: false },
    { dayAr: 'السبت (اليوم)', dayEn: 'Sat (Today)', caffeineMg: 170, nicotineUnits: 1, sleepScore: 81, hrvMs: vitals.hrvIndex, lateConsumption: true },
  ];

  // Helper to log consumption & drain battery dynamically
  const handleLogConsumption = (
    itemAr: string,
    itemEn: string,
    type: ConsumptionLog['type'],
    drain: number,
    hrvImpact: number,
    isLate: boolean = false
  ) => {
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newLog: ConsumptionLog = {
      id: 'log-' + Date.now(),
      itemAr,
      itemEn,
      time: nowTime,
      type,
      energyDrain: drain,
      hrvImpactMs: hrvImpact,
    };

    setSessionLogs((prev) => [newLog, ...prev]);

    // Dynamically update body battery & vitals
    const newEnergy = Math.min(100, Math.max(10, vitals.bodyEnergy + drain));
    const newHrv = Math.max(25, vitals.hrvIndex + hrvImpact);
    const newStress = Math.min(95, Math.max(15, vitals.stressLevel + (drain < 0 ? Math.abs(drain) : -5)));

    onUpdateVitals({
      bodyEnergy: newEnergy,
      hrvIndex: newHrv,
      stressLevel: newStress,
    });

    // Voice response logic
    if (isLate) {
      const msg = isAr
        ? `تحذير Sleep Guard! تم تسجيل ${itemAr} في حظر الـ 8 ساعات قبل النوم. تم خفض شحن البطارية إلى ${newEnergy}% وتنبيه انخفاض HRV!`
        : `Sleep Guard Alert! Logged ${itemEn} inside the 8h pre-bedtime cutoff. Energy battery reduced to ${newEnergy}%.`;
      onTriggerSpeech(msg);
    } else if (drain < 0) {
      const msg = isAr
        ? `تم تسجيل ${itemAr}. استهلاك طاقة البطارية الحيوية -${Math.abs(drain)}% (المتبقي ${newEnergy}%).`
        : `Logged ${itemEn}. Body battery drained by ${Math.abs(drain)}% (Remaining ${newEnergy}%).`;
      onTriggerSpeech(msg);
    } else {
      const msg = isAr
        ? `تم تسجيل ${itemAr}. شحن طاقة البطارية الحيوية +${drain}% (المستوى الحالي ${newEnergy}%).`
        : `Logged ${itemEn}. Body battery charged by +${drain}% (Now ${newEnergy}%).`;
      onTriggerSpeech(msg);
    }
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
      
      {/* Module Title Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold">
            <Moon className="w-6 h-6 animate-pulse text-indigo-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-mono font-bold">
                PATENT CLAIM-09 & 17
              </span>
              <span className="text-[10px] text-indigo-400 font-mono font-bold">SLEEP GUARD & RECOVERY ENGINE</span>
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              {isAr ? 'حامي النوم (Sleep Guard)، استهلاك البطارية والتحليل التراكمي' : 'Sleep Guard Cut-Off, Body Battery Drain & Recovery AI'}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-slate-950 text-indigo-400 border border-slate-800 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{isAr ? 'حظر الـ 8 ساعات مفعّل' : '8h Cut-off Guard Active'}</span>
          </span>
        </div>
      </div>

      {/* FEATURE 1: SLEEP GUARD & CUT-OFF ALERTS (8 Hours Pre-Bedtime) */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-indigo-900/60 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-indigo-400 shrink-0" />
            <div>
              <h4 className="text-sm font-black text-white">
                {isAr ? '1. حظر النيكوتين والمستحثات قبل النوم بـ 8 ساعات (Sleep Guard Cut-off)' : '1. Sleep Guard 8-Hour Stimulant & Nicotine Cut-off'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? `يحظر تناول النيكوتين والتبغ والكافيين بعد الساعة ${cutoffTime} لحماية كفاءة HRV والنوم العميق (موعد النوم ${bedtime}).`
                  : `Restricts nicotine and caffeine past ${cutoffTime} to protect HRV index and deep sleep quality (Target bedtime: ${bedtime}).`}
              </p>
            </div>
          </div>

          {/* Bedtime selector */}
          <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400">{isAr ? 'موعد النوم:' : 'Bedtime:'}</span>
            <select
              value={bedtime}
              onChange={(e) => setBedtime(e.target.value)}
              className="bg-transparent text-white font-bold focus:outline-none"
            >
              <option value="10:00 PM">10:00 PM (Cut-off 02:00 PM)</option>
              <option value="11:00 PM">11:00 PM (Cut-off 03:00 PM)</option>
              <option value="12:00 AM">12:00 AM (Cut-off 04:00 PM)</option>
            </select>
          </div>
        </div>

        {/* Live Status Warning Banner */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/60 border border-amber-800/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold text-amber-300 block">
                {isAr ? `تنبيه حماية النوم (نافذة الحظر مفعّلة حالياً - بعد ${cutoffTime})` : `Sleep Guard Enforcement Active (Post-${cutoffTime} Cut-off Window)`}
              </span>
              <p className="text-[11px] text-slate-300">
                {isAr
                  ? 'أي استهلاك للنيكوتين أو الكافيين الآن يزيد من هرمون الكورتيزول ويخفض مؤشر HRV بنسبة 20-30% أثناء الليل.'
                  : 'Consuming nicotine or caffeine right now elevates nocturnal cortisol and degrades HRV by 20-30%.'}
              </p>
            </div>
          </div>

          <button
            onClick={() =>
              handleLogConsumption(
                isAr ? 'جلسة نيكوتين/تبغ متأخرة (تحذير Sleep Guard!)' : 'Late Nicotine Session (Sleep Guard Alert!)',
                'Late Nicotine Session (Sleep Guard Alert!)',
                'nicotine',
                -12,
                -8,
                true
              )
            }
            className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shrink-0 flex items-center gap-1.5 transition-colors shadow-md"
          >
            <Flame className="w-4 h-4 text-amber-300" />
            <span>{isAr ? 'اختبار تنبيه حظر النيكوتين المتأخر' : 'Test Late Nicotine Alert'}</span>
          </button>
        </div>
      </div>

      {/* FEATURE 2: BODY BATTERY DYNAMIC DRAIN METER */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BatteryCharging className="w-5 h-5 text-emerald-400" />
            <div>
              <h4 className="text-sm font-black text-white">
                {isAr ? '2. مؤشر شحن واستهلاك طاقة الجسم الفوري (Body Battery Dynamic Drain)' : '2. Real-Time Body Battery Dynamic Drain & Charge Meter'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'رصد محاكاة استهلاك طاقة الجسم فوراً عند تسعير النيكوتين، القهوة أو الجهد البدني.'
                  : 'Live energy charge/drain updates based on logged nicotine, caffeine, exercise, or recovery events.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs font-bold px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-emerald-400">
            <span>{isAr ? 'التأثير الإجمالي:' : 'Net Drain Today:'}</span>
            <span className={totalDrain <= 0 ? 'text-amber-400' : 'text-emerald-400'}>
              {totalDrain > 0 ? `+${totalDrain}%` : `${totalDrain}%`}
            </span>
          </div>
        </div>

        {/* Big Interactive Energy Gauge */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-bold">{isAr ? 'رصيد طاقة الجسم الحالية (Ready Index):' : 'Current Body Battery Level:'}</span>
            <span className="font-mono font-black text-emerald-400 text-base">{vitals.bodyEnergy}%</span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-4 overflow-hidden border border-slate-800 p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-500 flex items-center justify-end pr-2 text-[10px] font-mono font-black ${
                vitals.bodyEnergy > 60
                  ? 'bg-gradient-to-r from-emerald-600 to-cyan-400 text-slate-950'
                  : vitals.bodyEnergy > 35
                  ? 'bg-gradient-to-r from-amber-600 to-yellow-400 text-slate-950'
                  : 'bg-gradient-to-r from-rose-700 to-rose-500 text-white animate-pulse'
              }`}
              style={{ width: `${vitals.bodyEnergy}%` }}
            >
              {vitals.bodyEnergy}%
            </div>
          </div>

          {/* Quick Dynamic Drain Log Buttons */}
          <div className="pt-2">
            <span className="text-[11px] font-bold text-slate-400 block mb-2">
              {isAr ? 'أزرار التسجيل السريع لاستهلاك / شحن الطاقة المباشر:' : 'Quick Log Buttons for Instant Body Battery Drain:'}
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() =>
                  handleLogConsumption(
                    isAr ? 'كبسولة نيكوتين (Nicotine Pouch)' : 'Nicotine Pouch',
                    'Nicotine Pouch',
                    'nicotine',
                    -8,
                    -5
                  )
                }
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-right space-y-1 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <Flame className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[10px] text-amber-400 font-bold bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-800">-8% Energy</span>
                </div>
                <div className="font-bold text-white text-[11px]">{isAr ? 'كبسولة نيكوتين' : 'Nicotine Pouch'}</div>
              </button>

              <button
                onClick={() =>
                  handleLogConsumption(
                    isAr ? 'جلسة تبغ / سحب (Tobacco Session)' : 'Tobacco / Vape Session',
                    'Tobacco / Vape Session',
                    'nicotine',
                    -14,
                    -9
                  )
                }
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-right space-y-1 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <ShieldAlert className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[10px] text-rose-400 font-bold bg-rose-950/80 px-1.5 py-0.5 rounded border border-rose-800">-14% Energy</span>
                </div>
                <div className="font-bold text-white text-[11px]">{isAr ? 'جلسة تبغ/تدخين' : 'Tobacco Session'}</div>
              </button>

              <button
                onClick={() =>
                  handleLogConsumption(
                    isAr ? 'تمرين رياض حاد (Workout)' : 'Intense Workout Session',
                    'Intense Workout Session',
                    'workout',
                    -18,
                    -4
                  )
                }
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-right space-y-1 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <Activity className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[10px] text-cyan-400 font-bold bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800">-18% Energy</span>
                </div>
                <div className="font-bold text-white text-[11px]">{isAr ? 'تمرين جهد رياضي' : 'Intense Workout'}</div>
              </button>

              <button
                onClick={() =>
                  handleLogConsumption(
                    isAr ? 'قيلولة تأمل وشحن (20-min Nap)' : '20-min Nap / Power Recovery',
                    '20-min Nap / Power Recovery',
                    'nap',
                    +15,
                    +6
                  )
                }
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-right space-y-1 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <Zap className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">+15% Charge</span>
                </div>
                <div className="font-bold text-white text-[11px]">{isAr ? 'قيلولة واستغراق' : '20-min Nap Recovery'}</div>
              </button>
            </div>
          </div>
        </div>

        {/* Live Session Activity History */}
        {sessionLogs.length > 0 && (
          <div className="space-y-2 text-xs">
            <span className="text-slate-400 font-bold">{isAr ? 'سجل الأحداث والاستهلاك الموثق اليوم:' : 'Recorded Drain & Charge Events Today:'}</span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {sessionLogs.slice(0, 4).map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    {log.energyDrain < 0 ? (
                      <TrendingDown className="w-4 h-4 text-amber-400" />
                    ) : (
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                    )}
                    <div>
                      <span className="font-bold text-white block">{isAr ? log.itemAr : log.itemEn}</span>
                      <span className="text-[10px] text-slate-500 font-mono">{log.time}</span>
                    </div>
                  </div>

                  <span className={`font-mono font-black ${log.energyDrain < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {log.energyDrain > 0 ? `+${log.energyDrain}%` : `${log.energyDrain}%`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* FEATURE 3: RECOVERY TREND AI INSIGHT DASHBOARD */}
      <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-cyan-400" />
            <div>
              <h4 className="text-sm font-black text-white">
                {isAr ? '3. لوحة التحليلات التراكمية والتنبؤ بالتعافي (Recovery Trend AI Dashboard)' : '3. Recovery Trend AI Insight Dashboard'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'مقارنة العلاقة بين استهلاك النيكوتين والكافيين المتأخر مع كفاءة الاستشفاء ومؤشر HRV الأسبوعي.'
                  : 'Correlates late consumption patterns with weekly HRV recovery and sleep efficiency metrics.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-bold">
            <button
              onClick={() => setSelectedMetric('hrv')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                selectedMetric === 'hrv' ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
              }`}
            >
              HRV (ms)
            </button>
            <button
              onClick={() => setSelectedMetric('sleep')}
              className={`px-3 py-1 rounded-lg transition-colors ${
                selectedMetric === 'sleep' ? 'bg-indigo-500 text-white font-black' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'جودة النوم %' : 'Sleep %'}
            </button>
          </div>
        </div>

        {/* Weekly Comparative Bar Chart Grid */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 font-bold border-b border-slate-800 pb-2">
            <span>{isAr ? 'مقارنة الأيام السبعة الأخير (استهلاك متأخر مقابل الاستشفاء):' : '7-Day History: Late Intake vs Recovery Index'}</span>
            <span className="text-[10px] font-mono text-cyan-400">PATENT CLAIM-17 AI ANALYSIS</span>
          </div>

          <div className="grid grid-cols-7 gap-2 pt-2 items-end h-36">
            {weeklyTrendData.map((d, idx) => {
              const heightPercent = selectedMetric === 'hrv' ? (d.hrvMs / 90) * 100 : d.sleepScore;
              return (
                <div key={idx} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                  <span className="text-[9px] font-mono font-bold text-slate-400 group-hover:text-white">
                    {selectedMetric === 'hrv' ? `${d.hrvMs}ms` : `${d.sleepScore}%`}
                  </span>

                  <div className="w-full bg-slate-950 rounded-lg h-24 flex items-end p-1 border border-slate-800">
                    <div
                      className={`w-full rounded-md transition-all duration-300 ${
                        d.lateConsumption
                          ? 'bg-gradient-to-t from-rose-950 to-amber-500'
                          : 'bg-gradient-to-t from-emerald-950 via-emerald-600 to-cyan-400'
                      }`}
                      style={{ height: `${Math.min(100, Math.max(15, heightPercent))}%` }}
                    ></div>
                  </div>

                  <span className="text-[10px] font-bold text-slate-300 truncate max-w-full">
                    {isAr ? d.dayAr : d.dayEn}
                  </span>

                  {d.lateConsumption && (
                    <span className="text-[8px] font-mono text-rose-400 bg-rose-950/80 px-1 rounded border border-rose-800 font-bold">
                      {isAr ? 'متأخر' : 'Late'}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* AI Insight Correlation Box */}
        <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-800/80 flex items-start gap-3 text-xs">
          <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-slate-300 leading-relaxed">
            <span className="font-bold text-cyan-300 block">
              {isAr ? 'استنتاج الذكاء الاصطناعي (AI Correlation Insight):' : 'AI Correlation Recovery Analysis:'}
            </span>
            <p className="text-[11px] text-slate-300">
              {isAr
                ? 'تحليل الأيام الثلاثة الماضية يظهر أن تناول النيكوتين أو القهوة بعد الساعة 03:00 PM يخفض كفاءة النوم بـ 24% وينقص مؤشر استشفاء القلب HRV بمقدار 18ms. الالتزام ببروتوكول Sleep Guard يضمن إعادة شحن البطارية لـ 90%+ صباحاً.'
                : 'Correlations over the past 3 days show nicotine/caffeine intake post 03:00 PM reduced sleep efficiency by 24% and dropped nocturnal HRV by 18ms. Adhering to the 8h Sleep Guard cutoff restores morning readiness to 90%+.'}
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
