import React, { useEffect, useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle, 
  CheckCircle2, 
  Heart, 
  Home, 
  MapPin, 
  PhoneCall, 
  ShieldAlert, 
  Users, 
  X 
} from 'lucide-react';
import { PatientProfile } from '../types';

interface SOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientProfile: PatientProfile;
}

export const SOSModal: React.FC<SOSModalProps> = ({ isOpen, onClose, patientProfile }) => {
  const [countdown, setCountdown] = useState(20);
  const [sosStatus, setSosStatus] = useState<'counting' | 'dispatched' | 'fine'>('counting');

  useEffect(() => {
    if (!isOpen) {
      setCountdown(20);
      setSosStatus('counting');
      return;
    }

    if (sosStatus !== 'counting') return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setSosStatus('dispatched');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, sosStatus]);

  if (!isOpen) return null;

  const handleImFine = () => {
    setSosStatus('fine');
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(`تم تأكيد سلامتك يا ${patientProfile.name}، وتوقف إنذار الطوارئ بنجاح.`);
      u.lang = 'ar-SA';
      window.speechSynthesis.speak(u);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-rose-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-950 border-2 border-rose-500 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-[0_0_60px_rgba(244,63,94,0.6)] relative overflow-hidden text-center space-y-6">
        
        {/* Pulsing Alert Light effect */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-rose-600/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-red-600/30 rounded-full blur-3xl animate-pulse"></div>

        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {sosStatus === 'counting' && (
          <div className="space-y-6 relative z-10">
            <div className="w-20 h-20 rounded-full bg-rose-600/20 border-2 border-rose-500 mx-auto flex items-center justify-center text-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.5)] animate-bounce">
              <ShieldAlert className="w-10 h-10" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-600 text-white uppercase tracking-wider animate-pulse">
                بروتوكول الطوارئ والتصعيد المتدرج لـ ({patientProfile.name})
              </span>
              <h2 className="text-2xl font-black text-white mt-3">سيتم التصعيد للطوارئ الرسمية خلال</h2>
              <div className="text-6xl font-black font-mono text-rose-400 my-3 animate-pulse">
                00:{countdown.toString().padStart(2, '0')}
              </div>
            </div>

            {/* Escalation Progress Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-right">
              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-amber-500/50 space-y-1">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                  <Home className="w-4 h-4" />
                  <span>1. إشعار الأقارب والساكنين بالمنزل</span>
                </div>
                <p className="text-[11px] text-slate-300">جاري إطلاق الإنذار لهواتف المقيمين بنفس المنزل أولاً.</p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-rose-500/50 space-y-1">
                <div className="flex items-center gap-1.5 text-rose-400 font-bold text-xs">
                  <PhoneCall className="w-4 h-4 animate-ping" />
                  <span>2. التصعيد المباشر 997</span>
                </div>
                <p className="text-[11px] text-slate-300">يتم التصعيد فور انتهاء مهلة الـ {countdown} ثوانٍ.</p>
              </div>
            </div>

            {/* GPS Location Snippet */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center gap-2 text-xs text-slate-300 font-mono">
              <MapPin className="w-4 h-4 text-rose-400 animate-ping" />
              <span>موقع {patientProfile.name} الحركي: 24.7136° N, 46.6753° E (الرياض)</span>
            </div>

            {/* Prominent "I'm Fine" ("أنا بخير") Green Button */}
            <div className="space-y-3 pt-2">
              <button
                onClick={handleImFine}
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-lg shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all flex items-center justify-center gap-3 transform hover:scale-[1.02]"
              >
                <CheckCircle2 className="w-7 h-7 text-slate-950" />
                <span>أنا بخير (إيقاف وإلغاء الإنذار)</span>
              </button>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSosStatus('dispatched')}
                  className="flex-1 py-3 px-4 rounded-xl bg-rose-600/30 border border-rose-500/50 hover:bg-rose-600/50 text-rose-200 font-bold text-xs transition-all"
                >
                  التصعيد الفوري الآن دون انتظار
                </button>
                <button
                  onClick={onClose}
                  className="py-3 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
                >
                  إغلاق الشاشة
                </button>
              </div>
            </div>

          </div>
        )}

        {/* STATE: "I'm Fine" Confirmed */}
        {sosStatus === 'fine' && (
          <div className="space-y-6 relative z-10 py-4">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-2 border-emerald-500 mx-auto flex items-center justify-center text-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.5)]">
              <CheckCircle className="w-10 h-10" />
            </div>

            <div>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                الحمد لله على سلامتك يا ({patientProfile.name})!
              </span>
              <h2 className="text-2xl font-black text-white mt-2">تم تأكيد الأمان وإلغاء التصعيد</h2>
              <p className="text-xs text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
                تم إيقاف العد التنازلي بنجاح، وتعميم رسالة اطمئنان على هواتف المقيمين بالمنزل والأقارب لإبلاغهم بأنك بخير وتقوم بالنشاط الطبيعي.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-right space-y-2 text-xs text-slate-300">
              <div className="flex items-center justify-between">
                <span>حالة الإنذار:</span>
                <span className="text-emerald-400 font-bold">ملغى بواسطة المستخدم (أنا بخير)</span>
              </div>
              <div className="flex items-center justify-between">
                <span>إشعار الأقارب:</span>
                <span className="text-cyan-400 font-bold">تم إرسال طمأنة (SMS & Push)</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-all"
            >
              العودة للوحة التحكم الرئيسية
            </button>
          </div>
        )}

        {/* STATE: Dispatched */}
        {sosStatus === 'dispatched' && (
          <div className="space-y-6 relative z-10 py-4">
            <div className="w-20 h-20 rounded-full bg-rose-600/20 border-2 border-rose-500 mx-auto flex items-center justify-center text-rose-400 shadow-[0_0_30px_rgba(244,63,94,0.5)]">
              <PhoneCall className="w-10 h-10 animate-pulse" />
            </div>

            <div>
              <h2 className="text-2xl font-black text-white">تم تصعيد طلب الطوارئ بنجاح!</h2>
              <p className="text-xs text-rose-300 font-medium mt-2">
                تم إرسال التنبيه لهواتف المقيمين بالمنزل ولفرق الإسعاف (997) مع إحداثيات الموقع الحالي لـ {patientProfile.name}.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-right space-y-2 text-xs text-slate-300">
              <div className="flex items-center justify-between">
                <span>جهة الاتصال الرئيسية:</span>
                <span className="text-cyan-400 font-bold">{patientProfile.emergencyContactName} ({patientProfile.emergencyContactPhone})</span>
              </div>
              <div className="flex items-center justify-between">
                <span>الرمز المرجعي للطوارئ:</span>
                <span className="text-rose-400 font-bold font-mono">SC-EMERGENCY-997</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleImFine}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition-all"
              >
                أنا بخير (إلغاء البث)
              </button>
              <button
                onClick={onClose}
                className="py-3.5 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
              >
                إغلاق
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
