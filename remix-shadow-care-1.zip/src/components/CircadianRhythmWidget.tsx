import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Sun, Moon, Compass, MapPin, Eye, Clock, Sparkles, CheckCircle2, AlertCircle, RefreshCw, Volume2 } from 'lucide-react';
import { Language } from '../types';

interface CircadianRhythmWidgetProps {
  language: Language;
  onTriggerSpeech: (text: string) => void;
}

interface LocationPreset {
  id: string;
  nameAr: string;
  nameEn: string;
  lat: number;
  lng: number;
  tzOffset: number;
  sunrise: string;
  solarNoon: string;
  sunset: string;
  goldenHour: string;
}

const LOCATION_PRESETS: LocationPreset[] = [
  {
    id: 'riyadh',
    nameAr: 'الرياض (المملكة العربية السعودية)',
    nameEn: 'Riyadh, Saudi Arabia',
    lat: 24.7136,
    lng: 46.6753,
    tzOffset: 3,
    sunrise: '05:22',
    solarNoon: '11:58',
    sunset: '18:34',
    goldenHour: '18:02',
  },
  {
    id: 'makkah',
    nameAr: 'مكة المكرمة (المملكة العربية السعودية)',
    nameEn: 'Makkah, Saudi Arabia',
    lat: 21.3891,
    lng: 39.8579,
    tzOffset: 3,
    sunrise: '05:40',
    solarNoon: '12:12',
    sunset: '18:45',
    goldenHour: '18:15',
  },
  {
    id: 'dubai',
    nameAr: 'دبي (الإمارات العربية المتحدة)',
    nameEn: 'Dubai, UAE',
    lat: 25.2048,
    lng: 55.2708,
    tzOffset: 4,
    sunrise: '05:42',
    solarNoon: '12:20',
    sunset: '18:58',
    goldenHour: '18:28',
  },
  {
    id: 'london',
    nameAr: 'لندن (المملكة المتحدة)',
    nameEn: 'London, UK',
    lat: 51.5074,
    lng: -0.1278,
    tzOffset: 1,
    sunrise: '05:28',
    solarNoon: '13:02',
    sunset: '20:36',
    goldenHour: '19:55',
  },
  {
    id: 'newyork',
    nameAr: 'نيويورك (الولايات المتحدة)',
    nameEn: 'New York, USA',
    lat: 40.7128,
    lng: -74.006,
    tzOffset: -4,
    sunrise: '05:58',
    solarNoon: '13:01',
    sunset: '20:05',
    goldenHour: '19:28',
  },
];

export const CircadianRhythmWidget: React.FC<CircadianRhythmWidgetProps> = ({
  language,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  const [selectedLoc, setSelectedLoc] = useState<LocationPreset>(LOCATION_PRESETS[0]);
  const [useGps, setUseGps] = useState<boolean>(false);
  const [gpsCoords, setGpsCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [sunExposureLogged, setSunExposureLogged] = useState<boolean>(false);
  const [loggedMinutes, setLoggedMinutes] = useState<number>(0);

  // Get current local hour
  const [currentHour, setCurrentHour] = useState<number>(() => new Date().getHours());
  const [currentMin, setCurrentMin] = useState<number>(() => new Date().getMinutes());

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentHour(now.getHours());
      setCurrentMin(now.getMinutes());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const decimalHour = currentHour + currentMin / 60;

  // Request real GPS coordinates
  const handleDetectGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setGpsCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
          setUseGps(true);
          const text = isAr
            ? `تم رصد موقعك الجغرافي (${pos.coords.latitude.toFixed(2)}°, ${pos.coords.longitude.toFixed(2)}°). تم ضبط منحنى الإيقاع اليومي والتعرض للضوء الطبيعي.`
            : `Detected coordinates (${pos.coords.latitude.toFixed(2)}°, ${pos.coords.longitude.toFixed(2)}°). Circadian Rhythm light curve calibrated.`;
          onTriggerSpeech(text);
        },
        () => {
          const text = isAr
            ? 'تعذر الوصول للإحداثيات الحالية. تم استخدام الرياض كموقع افتراضي.'
            : 'GPS location access unavailable. Defaulted to Riyadh location.';
          onTriggerSpeech(text);
        }
      );
    }
  };

  // Log Sun Exposure Action
  const handleLogSunExposure = (mins: number) => {
    setSunExposureLogged(true);
    setLoggedMinutes((prev) => prev + mins);
    const msg = isAr
      ? `تم تسجيل ${mins} دقيقة من التعرض للضوء الطبيعي الشمسي! تم تحفيز إنتاج السيروتونين وتثبيط الميلاتونين.`
      : `Logged ${mins} mins of natural sunlight exposure! Serotonin boosted and melatonin suppressed.`;
    onTriggerSpeech(msg);
  };

  // Determine current phase
  let phaseNameAr = 'النشاط والإدراك المرتفع';
  let phaseNameEn = 'High Cognitive Alertness';
  let targetLux = '10,000+ Lux (Natural Sunlight)';
  let phaseAdviceAr = 'الوقت الأمثل للتعرض لضوء الشمس لرفع التركيز وتثبيت الساعة البيولوجية.';
  let phaseAdviceEn = 'Ideal window for morning sunlight exposure to boost focus and anchor circadian baseline.';

  if (decimalHour >= 5 && decimalHour < 9) {
    phaseNameAr = 'نافذة التعرض لضوء الشروق (Cortisol Anchor)';
    phaseNameEn = 'Morning Sunrise Light Window';
    targetLux = '10,000 Lux';
    phaseAdviceAr = 'احرص على التعرض لضوء الشمس المباشر بدون نظارة شمسية لمدة 20 دقيقة لإيقاف الميلاتونين.';
    phaseAdviceEn = 'Get 20 mins of outdoor sunlight without sunglasses to suppress melatonin and raise cortisol.';
  } else if (decimalHour >= 9 && decimalHour < 14) {
    phaseNameAr = 'قمة النشاط الإدراكي وضبط فيتامين D';
    phaseNameEn = 'Peak Alertness & Vitamin D Window';
    targetLux = '15,000+ Lux';
    phaseAdviceAr = 'التعرض للضوء الساطع في منتصف النهار يعزز الأداء البدني ومستويات الطاقة.';
    phaseAdviceEn = 'Midday bright natural light optimizes physical stamina and aligns body clock.';
  } else if (decimalHour >= 14 && decimalHour < 18) {
    phaseNameAr = 'نافذة ضوء الأصيل وتنسيق الحركة';
    phaseNameEn = 'Afternoon Natural Light Window';
    targetLux = '5,000 - 8,000 Lux';
    phaseAdviceAr = 'ضوء النهار المتأخر يساعد على منع انخفاض الطاقة في بعد الظهيرة.';
    phaseAdviceEn = 'Late afternoon sunlight helps avoid mid-day energy dips.';
  } else if (decimalHour >= 18 && decimalHour < 21) {
    phaseNameAr = 'مرحلة ضوء الغروب الدافئ (Sunset Melatonin Signal)';
    phaseNameEn = 'Warm Sunset Light Phase';
    targetLux = '< 500 Lux (Warm Light)';
    phaseAdviceAr = 'التعرض لأشعة الغروب البرتقالية يرسل إشارة للمخ ببدء تحضير الميلاتونين للنوم.';
    phaseAdviceEn = 'Orange sunset wavelengths signal the pineal gland to initiate melatonin synthesis.';
  } else {
    phaseNameAr = 'حماية الظلام والراحة الليلية (Dark Shield)';
    phaseNameEn = 'Night Dark Shield Phase';
    targetLux = '< 50 Lux (Blue Light Filter)';
    phaseAdviceAr = 'تجنب الأجهزة والشاشات الزرقاء لحماية بنية النوم واستشفاء الجسم.';
    phaseAdviceEn = 'Avoid bright screen lights to protect sleep architecture and deep recovery.';
  }

  // Calculate position percentage along 24h timeline
  const timelinePercent = (decimalHour / 24) * 100;

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 shadow-2xl relative overflow-hidden">
      {/* Background Solar Wave Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold shrink-0">
            <Sun className="w-5 h-5 text-amber-400 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black text-white">
                {isAr ? 'الإيقاع اليومي والتعرض للضوء الطبيعي' : 'Circadian Rhythm & Sunlight Tracker'}
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold">
                CLAIM-07 SOLAR
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isAr ? 'مواعيد التعرض للضوء الشمسي حسب موقعك الجغرافي لإيقاف الإجهاد وضبط النوم' : 'Optimal natural light windows based on location for sleep architecture'}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            const text = isAr
              ? `المرحلة الحالية للإيقاع اليومي: ${phaseNameAr}. النصيحة: ${phaseAdviceAr}`
              : `Current circadian phase: ${phaseNameEn}. Recommendation: ${phaseAdviceEn}`;
            onTriggerSpeech(text);
          }}
          className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-400 transition-colors"
          title={isAr ? 'استماع للنصيحة الضوئية' : 'Listen to light recommendation'}
        >
          <Volume2 className="w-4 h-4" />
        </button>
      </div>

      {/* Location Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-950 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
          <MapPin className="w-4 h-4 text-cyan-400" />
          <span>{isAr ? 'الموقع الجغرافي:' : 'Location Baseline:'}</span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {!useGps ? (
            <select
              value={selectedLoc.id}
              onChange={(e) => {
                const loc = LOCATION_PRESETS.find((p) => p.id === e.target.value);
                if (loc) setSelectedLoc(loc);
              }}
              className="bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold focus:outline-none focus:border-amber-500"
            >
              {LOCATION_PRESETS.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {isAr ? loc.nameAr : loc.nameEn}
                </option>
              ))}
            </select>
          ) : (
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-3 py-1 rounded-xl border border-emerald-800 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                GPS ({gpsCoords?.lat.toFixed(2)}°, {gpsCoords?.lng.toFixed(2)}°)
              </span>
            </span>
          )}

          <button
            onClick={handleDetectGps}
            className="px-3 py-1.5 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 font-bold text-xs flex items-center gap-1.5 transition-all"
          >
            <Compass className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isAr ? 'تحديد الموقع تلقائياً GPS' : 'Auto GPS Detect'}</span>
          </button>
        </div>
      </div>

      {/* Solar Arc / 24-Hour Timeline Bar */}
      <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-300">
          <span className="flex items-center gap-1 text-amber-400">
            <Sun className="w-4 h-4 text-amber-400" />
            {isAr ? `الشروق ${selectedLoc.sunrise}` : `Sunrise ${selectedLoc.sunrise}`}
          </span>

          <span className="flex items-center gap-1 text-amber-300 font-mono text-sm">
            <Clock className="w-4 h-4 text-cyan-400" />
            {currentHour.toString().padStart(2, '0')}:{currentMin.toString().padStart(2, '0')} (Now)
          </span>

          <span className="flex items-center gap-1 text-indigo-400">
            <Moon className="w-4 h-4 text-indigo-400" />
            {isAr ? `الغروب ${selectedLoc.sunset}` : `Sunset ${selectedLoc.sunset}`}
          </span>
        </div>

        {/* Dynamic 24h Bar */}
        <div className="relative h-6 rounded-full bg-gradient-to-r from-indigo-950 via-amber-500/40 via-sky-400/50 via-amber-600/40 to-indigo-950 p-1 border border-slate-700/80">
          {/* Current Time Pin */}
          <motion.div
            className="absolute top-0 bottom-0 -ml-2.5 w-5 bg-white border-2 border-amber-500 rounded-full shadow-[0_0_12px_rgba(245,158,11,0.9)] flex items-center justify-center z-10"
            style={{ left: `${timelinePercent}%` }}
            animate={{ scale: [1, 1.15, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-2 h-2 rounded-full bg-amber-500" />
          </motion.div>
        </div>

        {/* Key Circadian Markers */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
            <p className="text-[10px] text-slate-400">{isAr ? 'الشروق' : 'Sunrise'}</p>
            <p className="text-xs font-bold text-amber-400 font-mono">{selectedLoc.sunrise}</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
            <p className="text-[10px] text-slate-400">{isAr ? 'منتصف النهار' : 'Solar Noon'}</p>
            <p className="text-xs font-bold text-sky-400 font-mono">{selectedLoc.solarNoon}</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
            <p className="text-[10px] text-slate-400">{isAr ? 'الساعة الذهبية' : 'Golden Hour'}</p>
            <p className="text-xs font-bold text-amber-300 font-mono">{selectedLoc.goldenHour}</p>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800/80">
            <p className="text-[10px] text-slate-400">{isAr ? 'الغروب' : 'Sunset'}</p>
            <p className="text-xs font-bold text-indigo-400 font-mono">{selectedLoc.sunset}</p>
          </div>
        </div>
      </div>

      {/* Current Circadian Phase Recommendation Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-amber-800/40 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-amber-300">
              {isAr ? phaseNameAr : phaseNameEn}
            </span>
          </div>

          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
            Target: {targetLux}
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          {isAr ? phaseAdviceAr : phaseAdviceEn}
        </p>

        {/* Sun Exposure Tracker Action */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800">
          <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>
              {isAr
                ? `التعرض المسجل اليوم: ${loggedMinutes} دقيقة ضوء طبيعي`
                : `Logged Sun Exposure Today: ${loggedMinutes} mins`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleLogSunExposure(15)}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs flex items-center gap-1 transition-all shadow-md"
            >
              <Sun className="w-3.5 h-3.5 text-black" />
              <span>{isAr ? 'تسجيل +15 دقيقة شمس' : 'Log +15m Sun'}</span>
            </button>
            <button
              onClick={() => handleLogSunExposure(30)}
              className="px-3 py-1.5 rounded-xl bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-300 font-bold text-xs transition-all"
            >
              <span>+30m</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
