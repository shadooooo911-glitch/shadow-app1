import React, { useState } from 'react';
import { Activity, Flame, Heart, Mic, MicOff, Navigation, Pill, Radio, ShieldAlert, Sparkles, Volume2, X, Zap } from 'lucide-react';
import { CurrentVitals, Language, MedicationItem, PatientProfile } from '../types';

interface OrangeActionButtonProps {
  language: Language;
  onNavigateTab: (tab: string) => void;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  medications: MedicationItem[];
  onTriggerSpeech: (text: string) => void;
}

export const OrangeActionButton: React.FC<OrangeActionButtonProps> = ({
  language,
  onNavigateTab,
  vitals,
  patientProfile,
  medications,
  onTriggerSpeech,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [lastSpeechResponse, setLastSpeechResponse] = useState<string>('');
  const [customQuery, setCustomQuery] = useState<string>('');

  const isAr = language === 'ar';

  const handleVoiceCommand = (cmdText: string) => {
    setCustomQuery(cmdText);

    // Navigation Commands ("فكي لي...")
    if (cmdText.includes('نبضات') || cmdText.includes('قلبي') || cmdText.includes('Heart Rate')) {
      onNavigateTab('heartrate');
      const msg = isAr ? `تم فتح شاشة نبضات القلب والجهد الحيوي لـ ${patientProfile.name}.` : `Opened Heart Rate screen for ${patientProfile.name}.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    if (cmdText.includes('الجهد') || cmdText.includes('الطاقة') || cmdText.includes('Readiness') || cmdText.includes('جسمي')) {
      onNavigateTab('readiness');
      const msg = isAr ? `تم فتح شاشة مؤشر الجاهزية والجهد اليومي.` : `Opened Readiness and Daily Energy screen.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    if (cmdText.includes('النوم') || cmdText.includes('نيكوتين') || cmdText.includes('بطارية') || cmdText.includes('Sleep Guard') || cmdText.includes('Recovery')) {
      onNavigateTab('readiness');
      const msg = isAr ? `تم تفعيل شاشة حامي النوم مجهّزة بـ 8 ساعات حظر ومؤشر استهلاك طاقة الجسم.` : `Opened Sleep Guard Cut-off & Body Battery Drain screen.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    if (cmdText.includes('الأدوية') || cmdText.includes('المواعيد') || cmdText.includes('الفيتامينات') || cmdText.includes('كافيين') || cmdText.includes('Medications')) {
      onNavigateTab('safemed');
      const msg = isAr ? `تم فتح شاشة الأدوية والفيتامينات وتتبع الكافيين المشفّرة.` : `Opened Safe-Med, Vitamins and Caffeine screen.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    if (cmdText.includes('الماسح') || cmdText.includes('كاميرا') || cmdText.includes('Scanner') || cmdText.includes('قهوة') || cmdText.includes('أكل')) {
      onNavigateTab('scanner');
      const msg = isAr ? `تم تشغيل الماسح الضوئي الذكي للأكل والقهوة والأدوية.` : `Opened Fast Vision AI Scanner.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    if (cmdText.includes('قيادة') || cmdText.includes('الرياضة') || cmdText.includes('الطقس') || cmdText.includes('Eco')) {
      onNavigateTab('ecosports');
      const msg = isAr ? `تم فتح رادار أمان القيادة والرياضات والطقس.` : `Opened Eco-Sports and Driving Safety Radar.`;
      setLastSpeechResponse(msg);
      onTriggerSpeech(msg);
      setIsOpen(false);
      return;
    }

    // Voice Query Questions ("كيف نبضات قلبي الحين؟" etc)
    if (cmdText.includes('كيف نبضات') || cmdText.includes('نبضات قلبي') || cmdText.includes('pulse')) {
      const resp = isAr
        ? `نبضات قلبك الآن ${vitals.heartRate} نبضة في الدقيقة، وتصنيف الأكسجين ${vitals.spo2} بالمئة وهي في النطاق المستقر والآمن يا ${patientProfile.name}.`
        : `Your current pulse is ${vitals.heartRate} BPM, SpO2 is ${vitals.spo2} percent. Stable and safe.`;
      setLastSpeechResponse(resp);
      onTriggerSpeech(resp);
      return;
    }

    if (cmdText.includes('نسبة طاقة') || cmdText.includes('طاقة جسمي') || cmdText.includes('body energy')) {
      const resp = isAr
        ? `طاقة جسمك الجاهزة اليوم هي ${vitals.bodyEnergy} بالمئة، ومعدل الإجهاد العضلي التراكمي ${vitals.stressLevel} بالمئة.`
        : `Your Body Energy readiness is ${vitals.bodyEnergy} percent, with stress level at ${vitals.stressLevel} percent.`;
      setLastSpeechResponse(resp);
      onTriggerSpeech(resp);
      return;
    }

    if (cmdText.includes('أخذت دواء') || cmdText.includes('الدواء اليوم') || cmdText.includes('took meds')) {
      const taken = medications.filter((m) => m.takenToday).map((m) => m.nameAr).join(' و ');
      const resp = isAr
        ? `نعم يا ${patientProfile.name}، تناولت اليوم: ${taken || 'لا يوجد أدوية أخذت بعد'}. ومتبقي بقية الجرعات حسب الجدول.`
        : `Yes ${patientProfile.name}, you took: ${taken || 'no medications taken yet today'}.`;
      setLastSpeechResponse(resp);
      onTriggerSpeech(resp);
      return;
    }

    if (cmdText.includes('مناسب للقيادة') || cmdText.includes('تركيزي') || cmdText.includes('driving focus')) {
      const resp = isAr
        ? `تركيزك وانحناء الرقبة ${vitals.postureNeckAngle} درجة ممتاز للقيادة الآمنة. مؤشر التنبيه الأخضر نشط.`
        : `Your driving focus and posture angle (${vitals.postureNeckAngle}°) are inside safe limits. Green indicator active.`;
      setLastSpeechResponse(resp);
      onTriggerSpeech(resp);
      return;
    }

    // Default response
    const defaultResp = isAr
      ? `أهلاً بك يا ${patientProfile.name}. أنظمة Shadow Care السمعية متأهبة. اطلب أي شاشة أو استفسار عن مؤشراتك الحيوية.`
      : `Welcome ${patientProfile.name}. Shadow Care Audio-First system is ready for voice queries and navigation.`;
    setLastSpeechResponse(defaultResp);
    onTriggerSpeech(defaultResp);
  };

  const startVoiceListen = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.lang = isAr ? 'ar-SA' : 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        setIsListening(true);

        recognition.onresult = (event: any) => {
          setIsListening(false);
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            handleVoiceCommand(transcript);
          }
        };

        recognition.onerror = () => {
          setIsListening(false);
          // Fallback simulation
          handleVoiceCommand(isAr ? 'كيف نبضات قلبي الحين؟' : 'How is my pulse now?');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
        return;
      } catch (err) {
        console.warn('SpeechRecognition error fallback:', err);
      }
    }

    // Fallback if browser Web Speech API is unavailable
    setIsListening(true);
    setTimeout(() => {
      setIsListening(false);
      handleVoiceCommand(isAr ? 'كيف نبضات قلبي الحين؟' : 'How is my pulse now?');
    }, 1800);
  };

  return (
    <>
      {/* Galaxy Watch Ultra Signature Orange Floating Action Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-40 flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 text-slate-950 font-black text-xs uppercase tracking-wider shadow-[0_0_30px_rgba(249,115,22,0.6)] border-2 border-amber-300 hover:scale-105 transition-all transform active:scale-95 cursor-pointer group"
        title={isAr ? 'الزر البرتقالي المخصص - الملاحة والاستعلام الصوتي (Galaxy Watch Ultra)' : 'Galaxy Watch Ultra Orange Button'}
      >
        <div className="w-7 h-7 rounded-full bg-slate-950 text-orange-400 flex items-center justify-center font-black text-sm border border-orange-400 group-hover:rotate-12 transition-transform">
          ⚡
        </div>
        <div className="flex flex-col items-start leading-tight">
          <span className="text-[10px] font-mono text-slate-900 opacity-90">Audio-First (Claim-06)</span>
          <span className="text-xs font-black text-slate-950">
            {isAr ? 'الزر البرتقالي المخصص' : 'Orange Action Button'}
          </span>
        </div>
      </button>

      {/* Audio-First Interactive Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-lg flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border-2 border-orange-500/80 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-[0_0_50px_rgba(249,115,22,0.3)] relative space-y-6">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-slate-950 font-black shadow-lg">
                  <Mic className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-black text-white">
                      {isAr ? 'القناة الصوتية التفاعلية (Claim-06 Audio-First)' : 'Audio-First Voice Navigation'}
                    </h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold">
                      GALAXY WATCH ULTRA
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isAr ? 'تحكم كامل وبث صوتي مباشر لتفادي التشتت البصري أثناء القيادة والحركة' : 'Hands-free voice query & screen switching while driving/moving'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Listening Mic Visualizer */}
            <div className="p-6 rounded-2xl bg-slate-950 border border-orange-500/30 text-center space-y-4 relative overflow-hidden">
              <div className="relative inline-flex items-center justify-center">
                {isListening && (
                  <span className="absolute w-24 h-24 rounded-full bg-orange-500/20 animate-ping"></span>
                )}
                <button
                  onClick={startVoiceListen}
                  className={`relative w-20 h-20 rounded-full flex items-center justify-center text-2xl transition-all ${
                    isListening
                      ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white shadow-[0_0_30px_rgba(249,115,22,0.8)] scale-110'
                      : 'bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 shadow-lg hover:scale-105'
                  }`}
                >
                  <Mic className="w-8 h-8" />
                </button>
              </div>

              <p className="text-xs font-bold text-orange-300">
                {isListening
                  ? (isAr ? 'جاري الاستماع لأمرك الصوتي الان...' : 'Listening for your command...')
                  : (isAr ? 'اضغط المايك للتحدث، أو أرسل استفساراً بصوتك/بالكتابة:' : 'Tap microphone or type your voice command below:')}
              </p>

              {/* Custom Voice Query Input Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (customQuery.trim()) {
                    handleVoiceCommand(customQuery);
                  }
                }}
                className="flex items-center gap-2 max-w-md mx-auto"
              >
                <input
                  type="text"
                  value={customQuery}
                  onChange={(e) => setCustomQuery(e.target.value)}
                  placeholder={isAr ? 'مثال: "فكي لي شاشة الأدوية" أو "كيف نبضات قلبي الحين؟"' : 'e.g. "How is my pulse now?" or "Open readiness"'}
                  className="flex-1 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 text-slate-950 font-black text-xs hover:opacity-90 transition-all shadow-md shrink-0"
                >
                  {isAr ? 'إرسال للأمر' : 'Send'}
                </button>
              </form>

              {lastSpeechResponse && (
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-emerald-300 font-medium flex items-center gap-2 text-right">
                  <Volume2 className="w-5 h-5 text-emerald-400 shrink-0 animate-pulse" />
                  <span>{lastSpeechResponse}</span>
                </div>
              )}
            </div>

            {/* Direct Voice Navigation Commands ("فكي لي...") */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                <Navigation className="w-4 h-4 text-orange-400" />
                <span>{isAr ? 'أوامر الفتح المباشر للشاشات بالصوت:' : 'Direct Screen Voice Commands:'}</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي شاشة نبضات القلب' : 'Heart Rate screen')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي شاشة نبضات القلب' : 'Open Heart Rate'}</span>
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي الجهد اليومي والطاقة' : 'Readiness screen')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي الجهد والطاقة' : 'Open Energy/Readiness'}</span>
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي شاشة الأدوية والمواعيد' : 'Medications screen')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي شاشة الأدوية' : 'Open Safe-Med'}</span>
                  <Pill className="w-3.5 h-3.5 text-indigo-400" />
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي الماسح الضوئي' : 'Vision Scanner')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي الماسح الضوئي' : 'Open Fast Scanner'}</span>
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي أمان القيادة' : 'Driving Safety')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي أمان القيادة' : 'Open Driving Safety'}</span>
                  <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'فكي لي الرياضة والطقس' : 'Eco Sports')}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-orange-300 font-bold text-right flex items-center justify-between gap-1 transition-all"
                >
                  <span>{isAr ? 'فكي لي الرياضة والطقس' : 'Open Eco-Sports'}</span>
                  <Flame className="w-3.5 h-3.5 text-orange-400" />
                </button>
              </div>
            </div>

            {/* Instant Voice Queries ("كيف نبضات قلبي الحين؟") */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>{isAr ? 'الاستعلام الصوتي اللحظي (إجابة ناطقة موثوقة):' : 'Real-Time Spoken Queries:'}</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => handleVoiceCommand(isAr ? 'كيف نبضات قلبي الحين؟' : 'How is my pulse now?')}
                  className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-emerald-300 font-bold text-right flex items-center justify-between transition-all"
                >
                  <span>{isAr ? 'كيف نبضات قلبي الحين؟' : 'How is my pulse now?'}</span>
                  <span className="text-[10px] text-cyan-400 font-mono">{vitals.heartRate} BPM</span>
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'كم نسبة طاقة جسمي؟' : 'What is my body energy?')}
                  className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-emerald-300 font-bold text-right flex items-center justify-between transition-all"
                >
                  <span>{isAr ? 'كم نسبة طاقة جسمي؟' : 'What is my body energy?'}</span>
                  <span className="text-[10px] text-amber-400 font-mono">{vitals.bodyEnergy}%</span>
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'هل أخذت دواء اليوم؟' : 'Did I take my meds today?')}
                  className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-emerald-300 font-bold text-right flex items-center justify-between transition-all"
                >
                  <span>{isAr ? 'هل أخذت دواء اليوم؟' : 'Did I take my meds today?'}</span>
                  <span className="text-[10px] text-indigo-400 font-mono">Concor 5mg</span>
                </button>

                <button
                  onClick={() => handleVoiceCommand(isAr ? 'هل تركيزي مناسب للقيادة؟' : 'Am I focused to drive?')}
                  className="p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-emerald-300 font-bold text-right flex items-center justify-between transition-all"
                >
                  <span>{isAr ? 'هل تركيزي مناسب للقيادة؟' : 'Am I focused to drive?'}</span>
                  <span className="text-[10px] text-emerald-400 font-mono">آمن (Safe)</span>
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 text-center text-[11px] text-slate-500">
              {isAr
                ? 'محقن صوتي عالي النقاء متوافق مع Galaxy Watch Ultra وسماعات التوصيل العظمي'
                : 'High-clarity audio channel tailored for Watch Ultra bone conduction headsets.'}
            </div>

          </div>
        </div>
      )}
    </>
  );
};
