import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wind, Heart, X, Play, Pause, RotateCcw, Volume2, VolumeX, CheckCircle2, Sparkles, Activity, ShieldAlert, Zap } from 'lucide-react';
import { CurrentVitals, Language } from '../types';

interface BreathingExerciseOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  vitals: CurrentVitals;
  onUpdateVitals: (vitals: Partial<CurrentVitals>) => void;
  onTriggerSpeech: (text: string) => void;
  initialReason?: string;
}

type Phase = 'idle' | 'inhale' | 'hold' | 'exhale' | 'completed';

export const BreathingExerciseOverlay: React.FC<BreathingExerciseOverlayProps> = ({
  isOpen,
  onClose,
  language,
  vitals,
  onUpdateVitals,
  onTriggerSpeech,
  initialReason,
}) => {
  const isAr = language === 'ar';

  const [phase, setPhase] = useState<Phase>('idle');
  const [phaseTimeLeft, setPhaseTimeLeft] = useState<number>(4);
  const [completedCycles, setCompletedCycles] = useState<number>(0);
  const totalTargetCycles = 4;
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [voiceGuidance, setVoiceGuidance] = useState<boolean>(true);
  const [initialHR] = useState<number>(vitals.heartRate);
  const [initialStress] = useState<number>(vitals.stressLevel);

  // Phase durations in seconds
  const INHALE_TIME = 4;
  const HOLD_TIME = 7;
  const EXHALE_TIME = 8;

  // Refs for timer logic
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Start breathing exercise
  const startExercise = () => {
    setIsPlaying(true);
    setPhase('inhale');
    setPhaseTimeLeft(INHALE_TIME);
    if (voiceGuidance) {
      onTriggerSpeech(
        isAr
          ? 'بدء تمرين التنفس 4-7-8. استنشق الهواء بهدوء عبر الأنف لمدة 4 ثوانٍ.'
          : 'Starting 4-7-8 breathing exercise. Inhale quietly through your nose for 4 seconds.'
      );
    }
  };

  const pauseExercise = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const resetExercise = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase('idle');
    setPhaseTimeLeft(INHALE_TIME);
    setCompletedCycles(0);
  };

  // Timer loop for 4-7-8 phases
  useEffect(() => {
    if (!isPlaying || phase === 'idle' || phase === 'completed') return;

    timerRef.current = setInterval(() => {
      setPhaseTimeLeft((prev) => {
        if (prev > 1) {
          return prev - 1;
        }

        // Phase Transition Logic
        if (phase === 'inhale') {
          setPhase('hold');
          if (voiceGuidance) {
            onTriggerSpeech(isAr ? 'احبس أنفاسك لمدة 7 ثوانٍ.' : 'Hold your breath for 7 seconds.');
          }
          return HOLD_TIME;
        } else if (phase === 'hold') {
          setPhase('exhale');
          if (voiceGuidance) {
            onTriggerSpeech(isAr ? 'زفير كامل عبر الفم ببطء لمدة 8 ثوانٍ.' : 'Exhale completely through your mouth for 8 seconds.');
          }
          return EXHALE_TIME;
        } else if (phase === 'exhale') {
          // Completed one full 4-7-8 cycle
          const nextCycleCount = completedCycles + 1;
          setCompletedCycles(nextCycleCount);

          // Physiologically lower heart rate & stress level after each cycle
          const newHR = Math.max(62, vitals.heartRate - 4);
          const newStress = Math.max(12, vitals.stressLevel - 8);
          const newEnergy = Math.min(100, vitals.bodyEnergy + 3);

          onUpdateVitals({
            heartRate: newHR,
            stressLevel: newStress,
            bodyEnergy: newEnergy,
          });

          if (nextCycleCount >= totalTargetCycles) {
            setPhase('completed');
            setIsPlaying(false);
            if (voiceGuidance) {
              onTriggerSpeech(
                isAr
                  ? `أحسنت! أكملت 4 دورات تنفس 4-7-8. انخفض نبضك إلى ${newHR} نبضة ومستوى التوتر إلى ${newStress}%.`
                  : `Well done! Completed 4 cycles of 4-7-8 breathwork. Heart rate lowered to ${newHR} BPM.`
              );
            }
            return 0;
          } else {
            setPhase('inhale');
            if (voiceGuidance) {
              onTriggerSpeech(isAr ? 'استنشق الهواء مجدداً لمدة 4 ثوانٍ.' : 'Inhale again for 4 seconds.');
            }
            return INHALE_TIME;
          }
        }

        return 0;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, phase, completedCycles, voiceGuidance, isAr, vitals]);

  if (!isOpen) return null;

  // Orb scale animation calculation
  let orbScale = 1;
  let phaseColorClass = 'from-cyan-500 to-blue-600';
  let phaseText = isAr ? 'جاهز للبدء' : 'Ready to Start';

  if (phase === 'inhale') {
    orbScale = 1.4;
    phaseColorClass = 'from-cyan-400 via-teal-400 to-emerald-500';
    phaseText = isAr ? '1. استنشاق (Inhale)' : '1. Inhale (Nose)';
  } else if (phase === 'hold') {
    orbScale = 1.4;
    phaseColorClass = 'from-indigo-500 via-purple-500 to-pink-500';
    phaseText = isAr ? '2. حبس النفس (Hold)' : '2. Hold Breath';
  } else if (phase === 'exhale') {
    orbScale = 0.85;
    phaseColorClass = 'from-emerald-400 via-blue-500 to-indigo-600';
    phaseText = isAr ? '3. زفير بطيء (Exhale)' : '3. Exhale (Mouth)';
  } else if (phase === 'completed') {
    orbScale = 1.1;
    phaseColorClass = 'from-emerald-500 to-teal-400';
    phaseText = isAr ? 'تم إكمال التمرين بنجاح!' : 'Exercise Completed!';
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.3 }}
          className="relative w-full max-w-xl bg-slate-900 border border-cyan-800/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-white overflow-hidden"
        >
          {/* Subtle Background Glow */}
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Modal Header */}
          <div className="flex items-start justify-between border-b border-slate-800 pb-4 relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold shrink-0">
                <Wind className="w-6 h-6 text-cyan-400 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-mono font-bold">
                    4-7-8 BREATHWORK THERAPY
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">PARASYMPATHETIC ACTIVATOR</span>
                </div>
                <h2 className="text-lg font-black text-white mt-0.5">
                  {isAr ? 'تمرين التنفس الموجه 4-7-8 لخفّض النبض' : 'Guided 4-7-8 Breathing Overlay'}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Trigger Context Banner */}
          {initialReason && (
            <div className="p-3 rounded-2xl bg-rose-950/70 border border-rose-800/80 text-rose-200 text-xs flex items-center gap-3 font-medium">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
              <span>{initialReason}</span>
            </div>
          )}

          {/* Vitals Reduction Tracker Bar */}
          <div className="grid grid-cols-3 gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
            <div className="space-y-0.5">
              <span className="text-[10px] font-mono text-slate-400 block">{isAr ? 'النبض الحالي' : 'Live Heart Rate'}</span>
              <div className="flex items-center justify-center gap-1 font-mono font-black text-rose-400 text-base">
                <Heart className="w-4 h-4 text-rose-500 animate-bounce" />
                <span>{vitals.heartRate} <span className="text-xs text-slate-400">bpm</span></span>
              </div>
              {initialHR > vitals.heartRate && (
                <span className="text-[10px] text-emerald-400 font-bold block">
                  -{initialHR - vitals.heartRate} bpm {isAr ? 'انخفاض' : 'lowered'}
                </span>
              )}
            </div>

            <div className="space-y-0.5 border-x border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 block">{isAr ? 'مستوى التوتر' : 'Stress Index'}</span>
              <div className="font-mono font-black text-amber-400 text-base">
                {vitals.stressLevel}%
              </div>
              {initialStress > vitals.stressLevel && (
                <span className="text-[10px] text-emerald-400 font-bold block">
                  -{initialStress - vitals.stressLevel}% {isAr ? 'تحسن' : 'reduced'}
                </span>
              )}
            </div>

            <div className="space-y-0.5">
              <span className="text-[10px] font-mono text-slate-400 block">{isAr ? 'الدورة الحالية' : 'Completed Cycles'}</span>
              <div className="font-mono font-black text-cyan-400 text-base">
                {completedCycles} / {totalTargetCycles}
              </div>
              <span className="text-[10px] text-slate-400 block">{isAr ? 'دورات مستهدفة' : 'Cycles'}</span>
            </div>
          </div>

          {/* Interactive Breathing Visualizer Centerpiece */}
          <div className="py-8 flex flex-col items-center justify-center relative min-h-[220px]">
            
            {/* Animated Pulsating Orb */}
            <motion.div
              animate={{
                scale: phase === 'idle' ? 1 : orbScale,
              }}
              transition={{
                duration: phase === 'inhale' ? INHALE_TIME : phase === 'exhale' ? EXHALE_TIME : 0.5,
                ease: phase === 'inhale' ? 'easeOut' : phase === 'exhale' ? 'easeInOut' : 'linear',
              }}
              className={`w-36 h-36 rounded-full bg-gradient-to-tr ${phaseColorClass} shadow-[0_0_50px_rgba(6,182,212,0.4)] flex flex-col items-center justify-center relative cursor-pointer border-4 border-white/20`}
            >
              <div className="absolute inset-0 rounded-full border border-white/40 animate-ping opacity-25 pointer-events-none" />
              
              <span className="text-3xl font-mono font-black text-white drop-shadow-md">
                {phase === 'idle' ? '4-7-8' : phase === 'completed' ? '✓' : `${phaseTimeLeft}s`}
              </span>
              <span className="text-[11px] font-bold text-white/90 uppercase tracking-widest mt-1">
                {phase === 'idle'
                  ? (isAr ? 'بدء' : 'Start')
                  : phase === 'inhale'
                  ? (isAr ? 'شهيق' : 'Inhale')
                  : phase === 'hold'
                  ? (isAr ? 'حبس' : 'Hold')
                  : phase === 'exhale'
                  ? (isAr ? 'زفير' : 'Exhale')
                  : (isAr ? 'مكتمل' : 'Done')}
              </span>
            </motion.div>

            {/* Current Phase Description */}
            <div className="mt-6 text-center space-y-1">
              <h4 className="text-base font-black text-white tracking-wide">{phaseText}</h4>
              <p className="text-xs text-slate-400 max-w-sm">
                {phase === 'idle'
                  ? (isAr ? 'تقنية التنفس 4-7-8 تساعد على إبطاء تسارع القلب وتنشيط العصب المبهم.' : 'The 4-7-8 technique stimulates the vagus nerve to slow rapid heart rate.')
                  : phase === 'inhale'
                  ? (isAr ? 'خذ نفساً عميقاً بهدوء من الأنف لمدة 4 ثوانٍ' : 'Inhale quietly through your nose for 4 seconds')
                  : phase === 'hold'
                  ? (isAr ? 'احبس أنفاسك وابقَ مسترخياً لمدة 7 ثوانٍ' : 'Hold your breath comfortably for 7 seconds')
                  : phase === 'exhale'
                  ? (isAr ? 'أخرج الهواء كاملاً عبر الفم ببطء لمدة 8 ثوانٍ' : 'Exhale completely with a whoosh sound for 8 seconds')
                  : (isAr ? 'تم استعادة توازن الجهاز العصبي الجارسمبثاوي' : 'Parasympathetic nervous system rebalanced')}
              </p>
            </div>
          </div>

          {/* Action Control Buttons */}
          <div className="space-y-3 border-t border-slate-800 pt-4">
            <div className="flex flex-wrap items-center justify-center gap-3">
              
              {phase === 'idle' ? (
                <button
                  onClick={startExercise}
                  className="flex-1 min-w-[140px] py-3 px-5 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{isAr ? 'بدء التمرين الآن' : 'Start Breathing Exercise'}</span>
                </button>
              ) : isPlaying ? (
                <button
                  onClick={pauseExercise}
                  className="flex-1 min-w-[140px] py-3 px-5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Pause className="w-4 h-4 fill-white" />
                  <span>{isAr ? 'إيقاف مؤقت' : 'Pause Exercise'}</span>
                </button>
              ) : phase !== 'completed' ? (
                <button
                  onClick={startExercise}
                  className="flex-1 min-w-[140px] py-3 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{isAr ? 'استئناف' : 'Resume'}</span>
                </button>
              ) : (
                <button
                  onClick={startExercise}
                  className="flex-1 min-w-[140px] py-3 px-5 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>{isAr ? 'تكرار التمرين' : 'Repeat 4 Cycles'}</span>
                </button>
              )}

              <button
                onClick={resetExercise}
                className="py-3 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-xs flex items-center gap-1.5 transition-colors"
                title={isAr ? 'إعادة ضبط' : 'Reset'}
              >
                <RotateCcw className="w-4 h-4" />
                <span>{isAr ? 'إعادة ضبط' : 'Reset'}</span>
              </button>

              <button
                onClick={() => setVoiceGuidance(!voiceGuidance)}
                className={`py-3 px-4 rounded-2xl border font-bold text-xs flex items-center gap-1.5 transition-colors ${
                  voiceGuidance
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-800'
                    : 'bg-slate-950 text-slate-500 border-slate-800'
                }`}
              >
                {voiceGuidance ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4" />}
                <span>{voiceGuidance ? (isAr ? 'التوجيه الصوتي: مفعل' : 'Voice: On') : (isAr ? 'التوجيه الصوتي: معطل' : 'Voice: Off')}</span>
              </button>

            </div>

            {/* Manual Quick Relax Trigger Button */}
            <div className="flex items-center justify-between gap-2 p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>{isAr ? 'محاكاة تأثير الاسترخاء المباشر:' : 'Simulate Direct Relaxing Impact:'}</span>
              </span>
              <button
                onClick={() => {
                  const relaxedHR = Math.max(62, vitals.heartRate - 6);
                  const relaxedStress = Math.max(10, vitals.stressLevel - 10);
                  onUpdateVitals({ heartRate: relaxedHR, stressLevel: relaxedStress });
                  onTriggerSpeech(
                    isAr
                      ? `تم خفض النبض إلى ${relaxedHR} نبضة ومستوى التوتر إلى ${relaxedStress}%.`
                      : `Lowered heart rate to ${relaxedHR} BPM and stress level to ${relaxedStress}%.`
                  );
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-mono font-bold text-[11px] flex items-center gap-1 transition-colors"
              >
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                <span>-6 BPM {isAr ? 'خفض سريع' : 'Quick Lower HR'}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
