import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Flame,
  Activity,
  AlertTriangle,
  Tag,
  Plus,
  Sparkles,
  CheckCircle2,
  Clock,
  HeartPulse,
  Wind,
  Smile,
  Coffee,
  Briefcase,
  Car,
  Dumbbell,
  Moon,
  Zap,
  ChevronRight,
} from 'lucide-react';
import { Language } from '../types';

interface StressSpikeHeatmapOverlayProps {
  language: Language;
  onTriggerSpeech: (text: string) => void;
  onOpenBreathingOverlay?: (reason?: string) => void;
}

export interface SpikeTimeBlock {
  id: string;
  timeSlot: string; // e.g. "14:00 - 15:00"
  timeShort: string; // e.g. "14:00"
  stressLevel: number; // 0-100%
  peakHr: number; // e.g. 132 BPM
  isSpike: boolean;
  loggedActivity?: string;
  loggedEmotion?: string;
  notes?: string;
}

const INITIAL_TIME_BLOCKS: SpikeTimeBlock[] = [
  { id: 'tb-06', timeSlot: '06:00 - 08:00', timeShort: '06:00', stressLevel: 25, peakHr: 68, isSpike: false },
  { id: 'tb-08', timeSlot: '08:00 - 10:00', timeShort: '08:00', stressLevel: 55, peakHr: 98, isSpike: false, loggedActivity: '🚗 Traffic Rush', loggedEmotion: '😤 Frustration' },
  { id: 'tb-10', timeSlot: '10:00 - 12:00', timeShort: '10:00', stressLevel: 42, peakHr: 84, isSpike: false },
  { id: 'tb-12', timeSlot: '12:00 - 14:00', timeShort: '12:00', stressLevel: 88, peakHr: 136, isSpike: true, loggedActivity: '💼 Work Deadline', loggedEmotion: '⚡ Anxiety' },
  { id: 'tb-14', timeSlot: '14:00 - 16:00', timeShort: '14:00', stressLevel: 94, peakHr: 142, isSpike: true },
  { id: 'tb-16', timeSlot: '16:00 - 18:00', timeShort: '16:00', stressLevel: 62, peakHr: 105, isSpike: true },
  { id: 'tb-18', timeSlot: '18:00 - 20:00', timeShort: '18:00', stressLevel: 38, peakHr: 78, isSpike: false },
  { id: 'tb-20', timeSlot: '20:00 - 22:00', timeShort: '20:00', stressLevel: 28, peakHr: 70, isSpike: false },
];

const PRESET_ACTIVITIES = [
  { id: 'work', icon: Briefcase, labelAr: '💼 اجتماع / موعد عميل', labelEn: '💼 Work Meeting' },
  { id: 'caffeine', icon: Coffee, labelAr: '☕ كافيين زائد', labelEn: '☕ Excessive Caffeine' },
  { id: 'traffic', icon: Car, labelAr: '🚗 زحمة السير', labelEn: '🚗 Traffic Rush' },
  { id: 'workout', icon: Dumbbell, labelAr: '🏋️ تمارين مكثفة', labelEn: '🏋️ Intense Exercise' },
  { id: 'fatigue', icon: Moon, labelAr: '🛏️ قلة نوم / إرهاق', labelEn: '🛏️ Sleep Deprivation' },
];

const PRESET_EMOTIONS = [
  { id: 'anxiety', labelAr: '⚡ قلق / توتر مفاجئ', labelEn: '⚡ Sudden Anxiety' },
  { id: 'frustration', labelAr: '😤 غضب / إحباط', labelEn: '😤 Frustration' },
  { id: 'overwhelmed', labelAr: '😰 ضغط عصبي زائد', labelEn: '😰 Overwhelmed' },
  { id: 'rushed', labelAr: '🏃 عجلة واستعجال', labelEn: '🏃 Hasty / Rushed' },
  { id: 'physical', labelAr: '🤒 إجهاد بدني', labelEn: '🤒 Physical Strain' },
];

export const StressSpikeHeatmapOverlay: React.FC<StressSpikeHeatmapOverlayProps> = ({
  language,
  onTriggerSpeech,
  onOpenBreathingOverlay,
}) => {
  const isAr = language === 'ar';
  const [timeBlocks, setTimeBlocks] = useState<SpikeTimeBlock[]>(INITIAL_TIME_BLOCKS);
  const [selectedBlockId, setSelectedBlockId] = useState<string>('tb-14');
  const [selectedActivity, setSelectedActivity] = useState<string>('');
  const [selectedEmotion, setSelectedEmotion] = useState<string>('');
  const [customNote, setCustomNote] = useState<string>('');
  const [logSavedSuccess, setLogSavedSuccess] = useState<boolean>(false);

  const activeBlock = timeBlocks.find((b) => b.id === selectedBlockId) || timeBlocks[3];

  const handleSaveTriggerLog = () => {
    if (!selectedBlockId) return;

    setTimeBlocks((prev) =>
      prev.map((b) => {
        if (b.id === selectedBlockId) {
          return {
            ...b,
            loggedActivity: selectedActivity || b.loggedActivity || (isAr ? 'نشاط غير مسمى' : 'Logged Activity'),
            loggedEmotion: selectedEmotion || b.loggedEmotion || (isAr ? 'شعور غير مسمى' : 'Logged Emotion'),
            notes: customNote || b.notes,
          };
        }
        return b;
      })
    );

    setLogSavedSuccess(true);
    setTimeout(() => setLogSavedSuccess(false), 3000);

    const speechText = isAr
      ? `تم توثيق محفز ارتفاع التوتر للفترة ${activeBlock.timeSlot}. النشاط: ${selectedActivity || 'مسجل'}, الشعور: ${selectedEmotion || 'مسجل'}.`
      : `Trigger log saved for ${activeBlock.timeSlot}. Activity: ${selectedActivity || 'Recorded'}, Emotion: ${selectedEmotion || 'Recorded'}.`;

    onTriggerSpeech(speechText);
  };

  const getHeatmapColor = (level: number) => {
    if (level >= 80) return { bg: 'bg-rose-600', text: 'text-rose-400', border: 'border-rose-500', shadow: 'shadow-rose-950/80', badge: 'HIGH SPIKE' };
    if (level >= 50) return { bg: 'bg-amber-500', text: 'text-amber-400', border: 'border-amber-500', shadow: 'shadow-amber-950/80', badge: 'MODERATE' };
    return { bg: 'bg-emerald-500', text: 'text-emerald-400', border: 'border-emerald-600', shadow: 'shadow-emerald-950/80', badge: 'OPTIMAL' };
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 shadow-2xl relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Title & Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-950 text-rose-400 border border-rose-800 flex items-center justify-center font-bold shrink-0 shadow-lg">
            <Flame className="w-6 h-6 text-rose-500 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-mono font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-rose-400" />
                STRESS SPIKE HEAT-MAP INTERACTIVE
              </span>
              <span className="text-[10px] text-cyan-400 font-mono font-bold">24H TIMELINE</span>
            </div>

            <h3 className="text-base font-black text-white mt-1">
              {isAr ? 'خريطة الإجهاد الحرارية التفاعلية وتوثيق المحفزات' : 'Interactive Stress Spike Heat-Map & Trigger Logger'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isAr
                ? 'انقر على الفترات الزمنية ذات الارتفاع المفاجئ للنبض والتوتر لتحديد الأنشطة والمشاعر المسببة'
                : 'Tap on time blocks experiencing stress spikes to attach custom triggers and emotional context'}
            </p>
          </div>
        </div>

        {/* Dynamic Spike Counter */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-2xl bg-slate-950 text-rose-400 border border-slate-800 text-xs font-mono font-bold flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
            <span>
              {timeBlocks.filter((b) => b.isSpike).length} {isAr ? 'ارتفاعات حادة' : 'SPIKES DETECTED'}
            </span>
          </div>
        </div>
      </div>

      {/* 1. Hourly Interactive Heat-Map Bar */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-slate-400 px-1">
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isAr ? 'التسلسل الزمني لشدة الإجهاد على مدار اليوم' : 'Daily Stress Intensity Timeline'}</span>
          </span>
          <span className="text-[10px] font-mono text-slate-500">TAP BLOCK TO INSPECT</span>
        </div>

        {/* Heatmap Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2.5">
          {timeBlocks.map((block) => {
            const isSelected = block.id === selectedBlockId;
            const heat = getHeatmapColor(block.stressLevel);

            return (
              <motion.button
                key={block.id}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => {
                  setSelectedBlockId(block.id);
                  setSelectedActivity(block.loggedActivity || '');
                  setSelectedEmotion(block.loggedEmotion || '');
                  setCustomNote(block.notes || '');
                }}
                className={`p-3 rounded-2xl border transition-all text-left flex flex-col justify-between h-28 relative overflow-hidden group ${
                  isSelected
                    ? 'bg-slate-950 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)] ring-2 ring-cyan-400/50 scale-[1.02]'
                    : 'bg-slate-950/80 border-slate-800/80 hover:bg-slate-900'
                }`}
              >
                {/* Heat Indicator Bar */}
                <div className={`absolute top-0 left-0 right-0 h-1.5 ${heat.bg}`} />

                {/* Top Block Info */}
                <div className="flex items-center justify-between w-full pt-1">
                  <span className="text-[11px] font-mono font-bold text-slate-300">{block.timeShort}</span>
                  {block.isSpike && (
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" title="Stress Spike" />
                  )}
                </div>

                {/* Middle Stress Score & HR */}
                <div className="my-1">
                  <div className={`text-lg font-black font-mono ${heat.text}`}>
                    {block.stressLevel}%
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {block.peakHr} BPM
                  </div>
                </div>

                {/* Bottom Trigger Badge Indicator */}
                <div className="truncate w-full">
                  {block.loggedActivity ? (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 truncate block">
                      {block.loggedActivity}
                    </span>
                  ) : block.isSpike ? (
                    <span className="text-[9px] font-bold px-1 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 truncate block">
                      {isAr ? 'لم يُسجل' : '+ Log Cause'}
                    </span>
                  ) : (
                    <span className="text-[9px] font-mono text-slate-500 block">
                      {isAr ? 'مستقر' : 'Normal'}
                    </span>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Heat-map Color Legend */}
        <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-1 px-1 font-mono">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>{isAr ? 'مستقر (<50%)' : 'Optimal (<50%)'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span>{isAr ? 'متوسط (50-79%)' : 'Moderate (50-79%)'}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>{isAr ? 'ارتفاع حاد (≥80%)' : 'Spike Alert (≥80%)'}</span>
            </span>
          </div>

          <span className="text-slate-500">{isAr ? 'تزامن بيانات PPG المستمرة' : 'Continuous PPG Telemetry'}</span>
        </div>
      </div>

      {/* 2. Detailed Selected Block Trigger Logging Form */}
      {activeBlock && (
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0">
                <Tag className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-xs font-black text-white flex items-center gap-2">
                  <span>
                    {isAr
                      ? `تفاصيل فترة الإجهاد (${activeBlock.timeSlot})`
                      : `Selected Spike Event (${activeBlock.timeSlot})`}
                  </span>
                  {activeBlock.isSpike && (
                    <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800 text-[10px] font-mono font-bold">
                      SPIKE DETECTED
                    </span>
                  )}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {isAr
                    ? `ذروة النبض: ${activeBlock.peakHr} BPM • نسبة التوتر: ${activeBlock.stressLevel}%`
                    : `Peak Heart Rate: ${activeBlock.peakHr} BPM • Stress Index: ${activeBlock.stressLevel}%`}
                </p>
              </div>
            </div>

            {/* Quick Breathing Action if High Spike */}
            {activeBlock.stressLevel >= 80 && onOpenBreathingOverlay && (
              <button
                onClick={() =>
                  onOpenBreathingOverlay(
                    isAr
                      ? `ارتفاع التوتر في الفترة (${activeBlock.timeSlot}) - بدء جلسة التنفس الموجه`
                      : `High Stress Spike (${activeBlock.stressLevel}%) at ${activeBlock.timeSlot}`
                  )
                }
                className="py-1.5 px-3 rounded-xl bg-amber-950 hover:bg-amber-900 text-amber-300 border border-amber-800 text-xs font-bold flex items-center gap-1.5 transition-all"
              >
                <Wind className="w-3.5 h-3.5 text-amber-400" />
                <span>{isAr ? 'تمرين التنفس الموجه' : 'Guided Breathing'}</span>
              </button>
            )}
          </div>

          {/* Activity Selection Grid */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">
              {isAr ? '1. اختر النشاط المسبب للإجهاد:' : '1. Select Associated Activity:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {PRESET_ACTIVITIES.map((act) => {
                const label = isAr ? act.labelAr : act.labelEn;
                const isSelected = selectedActivity === label;
                return (
                  <button
                    key={act.id}
                    onClick={() => setSelectedActivity(label)}
                    className={`py-1.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      isSelected
                        ? 'bg-cyan-950 text-cyan-300 border-cyan-500 shadow-md scale-105'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Emotion Selection Grid */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">
              {isAr ? '2. اختر الحالة العاطفية المرافقة:' : '2. Select Emotional State:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {PRESET_EMOTIONS.map((emo) => {
                const label = isAr ? emo.labelAr : emo.labelEn;
                const isSelected = selectedEmotion === label;
                return (
                  <button
                    key={emo.id}
                    onClick={() => setSelectedEmotion(label)}
                    className={`py-1.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      isSelected
                        ? 'bg-purple-950 text-purple-300 border-purple-500 shadow-md scale-105'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Save Log Action Button */}
          <div className="flex items-center justify-between pt-2">
            {logSavedSuccess ? (
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-3 py-1.5 rounded-xl border border-emerald-800 flex items-center gap-1.5 animate-bounce">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isAr ? 'تم حفظ سبب الارتفاع بنجاح!' : 'Spike Trigger Saved!'}</span>
              </span>
            ) : (
              <span className="text-[11px] text-slate-400">
                {activeBlock.loggedActivity
                  ? (isAr ? `مسجل حالياً: ${activeBlock.loggedActivity}` : `Currently logged: ${activeBlock.loggedActivity}`)
                  : (isAr ? 'اختر نشاطاً وشعوراً ثم انقر حفظ' : 'Select activity & emotion to save')}
              </span>
            )}

            <button
              onClick={handleSaveTriggerLog}
              className="py-2 px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'حفظ محفز الإجهاد' : 'Save Trigger Log'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
