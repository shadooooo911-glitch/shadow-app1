import React from 'react';
import { Check, CheckCircle2, CreditCard, Lock, ShieldCheck, Sparkles, Star } from 'lucide-react';
import { Language, PatientProfile } from '../types';

interface Screen6SubscriptionProps {
  language: Language;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
}

export const Screen6Subscription: React.FC<Screen6SubscriptionProps> = ({
  language,
  patientProfile,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-mono font-bold">
              PRO COMMERCIAL MODEL
            </span>
            <span className="text-xs text-slate-400">الشاشة 6 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1 flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-cyan-400" />
            <span>{isAr ? 'إدارة الاشتراك والتراخيص (Shadow Care PRO)' : 'Subscription & Commercial Licensing'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `النموذج التجاري والتسعيير المشفر لـ (${patientProfile.name}) مع ميزات البراءة الـ 19 كاملة`
              : `Commercial model and partner licensing for ${patientProfile.name}`}
          </p>
        </div>

        <span className="text-[10px] font-mono px-3 py-1.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
          VIP ENTERPRISE LICENSED
        </span>
      </div>

      {/* Subscription Card ($00.00 Placeholder) */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-cyan-500/50 shadow-[0_0_50px_rgba(6,182,212,0.15)] relative overflow-hidden space-y-6">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold">
              <Star className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
              <span>{isAr ? 'باقة الشركاء والمنظومات الطبية' : 'PRO Partner Enterprise Tier'}</span>
            </div>
            <h3 className="text-2xl font-black text-white">Shadow Care Medical PRO</h3>
          </div>

          <div className="text-right">
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-black font-mono text-cyan-400">$00.00</span>
              <span className="text-xs text-slate-400">/ {isAr ? 'شهرياً' : 'monthly'}</span>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">{isAr ? 'نسخة تجريبية معتمدة' : 'Verified Preview Tier'}</span>
          </div>
        </div>

        {/* Partner Pricing Disclaimer Box */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/40 text-xs text-amber-200 leading-relaxed space-y-1">
          <div className="font-bold text-amber-400 flex items-center gap-1.5">
            <Lock className="w-4 h-4" />
            <span>{isAr ? 'تنويه رسمي بخصوص التسعير والدفع:' : 'Official Notice on Pricing & Billing:'}</span>
          </div>
          <p>
            {isAr
              ? 'تنويه رسمي: السعر التجريبي حالياً $00.00. تحديد السعر الفعلي وآلية التسعير والدفع ستكون مستقبلاً بالاتفاق مع الشركاء والاستثمار الطبي والمستشفيات المعتمدة.'
              : 'Official Notice: Subscription price is currently $00.00 as a partner preview. Final commercial pricing and billing integration will be determined in future agreements with medical partners and investors.'}
          </p>
        </div>

        {/* Included Features List */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-300">
            {isAr ? 'الميزات والتراخيص المشمولة في باقة PRO:' : 'Included PRO Features & Patents:'}
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'تفعيل كامل لبنود براءة الاختراع الـ 19 الرسمية' : 'Full 19 Official Patent Claims active'}</span>
            </div>

            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'القناة الصوتية Audio-First للزر البرتقالي (Watch Ultra)' : 'Watch Ultra Orange Button Audio-First Controller'}</span>
            </div>

            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'الماسح الضوئي الذكي (Vision AI) للأكل والقهوة والأدوية' : 'Vision AI Fast Scanner for Food, Coffee & Meds'}</span>
            </div>

            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'رادار أمان القيادة، السباحة، الجبال والطقس البيئي' : 'Driving Safety, Swimming & Mountain Eco Shield'}</span>
            </div>

            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'تشفير حيوي محلي 100% بدون أي تسريب للبيانات' : '100% Local Encrypted Biometric Ledger (Claim-07)'}</span>
            </div>

            <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'نظام التصعيد الطارئ المتدرج الآلي (997/911)' : 'Official Tiered Emergency Escalation System (997/911)'}</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => onTriggerSpeech(isAr ? 'اشتراكك نشط ومفعل بنجاح كنسخة شريك معتمدة.' : 'PRO Subscription active as partner preview.')}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 text-slate-950 font-black text-xs uppercase tracking-wider hover:opacity-90 transition-all shadow-lg"
        >
          {isAr ? 'الاشتراك مفعّل حالياً (Partner Access Granted)' : 'Partner Subscription Active'}
        </button>

      </div>

    </div>
  );
};
