import React, { useState } from 'react';
import { Check, CheckCircle2, Clock, Info, Pill, Plus, Sparkles, Trash2, Volume2 } from 'lucide-react';
import { Language, PatientProfile, VitaminSupplementItem } from '../types';

interface VitaminsSupplementsLogProps {
  language: Language;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
}

export const VitaminsSupplementsLog: React.FC<VitaminsSupplementsLogProps> = ({
  language,
  patientProfile,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  const [vitamins, setVitamins] = useState<VitaminSupplementItem[]>([
    {
      id: 'vit-1',
      nameAr: 'فيتامين د3 (Vitamin D3 5000 IU)',
      nameEn: 'Vitamin D3 5000 IU',
      dosage: 'كبسولة واحدة (5000 IU)',
      category: 'vitamin',
      timeSlot: '01:00 PM (مع الغداء)',
      takenToday: false,
      bestTakenWithAr: 'يفضل تناوله مع وجبة دسمة تحتوي على دهون صحية لزيادة الامتصاص بنسبة 50%.',
      bestTakenWithEn: 'Best taken with a meal containing healthy fats for 50% better absorption.',
      benefitsAr: 'دعم صحة العظام والأسنان والمناعة وتحسين مزاج التوتر.',
      benefitsEn: 'Supports bone health, immunity, and reduces HRV stress.',
    },
    {
      id: 'vit-2',
      nameAr: 'أوميغا 3 المتقدم (Omega 3 Triple Strength)',
      nameEn: 'Omega 3 Triple Strength',
      dosage: 'كبسولة واحدة 1000mg',
      category: 'supplement',
      timeSlot: '08:30 PM (مع العشاء)',
      takenToday: false,
      bestTakenWithAr: 'تناوله بعد الوجبة الرئيسية مباشرة لمنع حموضة المعدة.',
      bestTakenWithEn: 'Take directly after dinner to avoid reflux.',
      benefitsAr: 'تعزيز صحة الأوعية الدموية وخفض الكوليسترول الضار.',
      benefitsEn: 'Promotes vascular health and cardiovascular longevity.',
    },
    {
      id: 'vit-3',
      nameAr: 'مغنيسيوم جليسينات (Magnesium Glycinate)',
      nameEn: 'Magnesium Glycinate 400mg',
      dosage: 'كبسولتان قبل النوم',
      category: 'mineral',
      timeSlot: '10:15 PM (قبل النوم)',
      takenToday: false,
      bestTakenWithAr: 'تناوله قبل النوم بـ 45 دقيقة مع كوب ماء دافئ لتنعيم العضلات.',
      bestTakenWithEn: 'Take 45 mins before sleep with warm water to relax muscles.',
      benefitsAr: 'استرخاء العضلات، الوقاية من الشد العضلي وتحسين كفاءة النوم العميق.',
      benefitsEn: 'Prevents muscle cramps and enhances deep sleep quality.',
    },
    {
      id: 'vit-4',
      nameAr: 'زنيك بيكولينات (Zinc Picolinate 30mg)',
      nameEn: 'Zinc Picolinate 30mg',
      dosage: 'حبة واحدة',
      category: 'mineral',
      timeSlot: '02:00 PM',
      takenToday: true,
      bestTakenWithAr: 'يفضل عدم تناوله مع الكالسيوم أو القهوة مباشرة.',
      bestTakenWithEn: 'Do not take concurrently with calcium or coffee.',
      benefitsAr: 'تعزيز المناعة وتسريع استشفاء الأنسجة بعد الرياضة.',
      benefitsEn: 'Boosts immune response and tissue recovery after workout.',
    },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newVitaminName, setNewVitaminName] = useState('');
  const [newDosage, setNewDosage] = useState('');
  const [newTimeSlot, setNewTimeSlot] = useState('');
  const [newCategory, setNewCategory] = useState<'vitamin' | 'supplement' | 'mineral'>('vitamin');
  const [newBestWith, setNewBestWith] = useState('');

  const takenCount = vitamins.filter((v) => v.takenToday).length;

  const handleToggleVitamin = (id: string) => {
    setVitamins((prev) =>
      prev.map((v) => {
        if (v.id === id) {
          const nextTaken = !v.takenToday;
          if (nextTaken) {
            onTriggerSpeech(
              isAr
                ? `تم تسجيل أخذ ${v.nameAr} بنجاح وتوثيقه في سجل الفيتامينات.`
                : `Logged ${v.nameEn} intake.`
            );
          }
          return { ...v, takenToday: nextTaken };
        }
        return v;
      })
    );
  };

  const handleAddVitamin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVitaminName.trim()) return;

    const newItem: VitaminSupplementItem = {
      id: 'vit-' + Date.now(),
      nameAr: newVitaminName,
      nameEn: newVitaminName,
      dosage: newDosage || 'جرعة يومية',
      category: newCategory,
      timeSlot: newTimeSlot || '09:00 AM',
      takenToday: false,
      bestTakenWithAr: newBestWith || 'يرجى اتباع إرشادات الطبيب أو الصيدلي.',
      bestTakenWithEn: newBestWith || 'Follow doctor instructions.',
      benefitsAr: 'مكمل غذائي داعم للصحة الحيوية.',
      benefitsEn: 'Nutritional supplement supporting vitality.',
    };

    setVitamins((prev) => [...prev, newItem]);
    setNewVitaminName('');
    setNewDosage('');
    setNewTimeSlot('');
    setNewBestWith('');
    setShowAddModal(false);

    onTriggerSpeech(
      isAr
        ? `تم إضافة ${newItem.nameAr} إلى سجل المكملات بنجاح.`
        : `Added ${newItem.nameEn} to vitamins log.`
    );
  };

  const handleDeleteVitamin = (id: string) => {
    setVitamins((prev) => prev.filter((v) => v.id !== id));
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold">
            <Pill className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-mono font-bold">
                PATENT CLAIM-03 & 09
              </span>
              <span className="text-[10px] text-indigo-400 font-mono font-bold">VITAMIN & SUPPLEMENT LEDGER</span>
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              {isAr ? 'سجل الفيتامينات والمكملات الغذائية اليومية' : 'Vitamins & Dietary Supplements Log'}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-slate-950 text-emerald-400 border border-slate-800">
            {takenCount} / {vitamins.length} {isAr ? 'تم تناولها' : 'Taken'}
          </span>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إضافة مكمل جديد' : 'Add Supplement'}</span>
          </button>
        </div>
      </div>

      {/* Grid of Vitamin Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {vitamins.map((vit) => (
          <div
            key={vit.id}
            className={`p-5 rounded-2xl border transition-all space-y-3 ${
              vit.takenToday
                ? 'bg-slate-950/90 border-emerald-500/60 shadow-[0_0_15px_rgba(16,185,129,0.1)]'
                : 'bg-slate-950 border-slate-800 hover:border-indigo-500/50'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                  vit.category === 'vitamin'
                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                    : vit.category === 'mineral'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                    : 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                }`}>
                  {vit.category === 'vitamin' ? (isAr ? 'فيتامين' : 'Vitamin') :
                   vit.category === 'mineral' ? (isAr ? 'معدن أساسي' : 'Essential Mineral') :
                   (isAr ? 'مكمل غذائي' : 'Dietary Supplement')}
                </span>

                <h4 className="text-base font-black text-white mt-1.5">
                  {isAr ? vit.nameAr : vit.nameEn}
                </h4>
                <p className="text-xs text-slate-400">{vit.dosage}</p>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800">
                  <Clock className="w-3 h-3 text-cyan-400" />
                  <span>{vit.timeSlot}</span>
                </div>

                <button
                  onClick={() => handleDeleteVitamin(vit.id)}
                  className="p-1 rounded bg-slate-900 hover:bg-rose-950 text-slate-500 hover:text-rose-400"
                  title="حذف"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Absorption advice card */}
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 text-[11px] text-slate-300 space-y-1">
              <div className="flex items-center gap-1 text-cyan-400 font-bold">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>{isAr ? 'نصيحة الأداء والامتصاص الأمثل:' : 'Optimal Absorption Advice:'}</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                {isAr ? vit.bestTakenWithAr : vit.bestTakenWithEn}
              </p>
            </div>

            {/* Interactive Intake Button */}
            <button
              onClick={() => handleToggleVitamin(vit.id)}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                vit.takenToday
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/80'
                  : 'bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-700 text-white hover:opacity-90 shadow-md'
              }`}
            >
              {vit.takenToday ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{isAr ? 'تم تناول الجرعة (تأكيد محلي بالسوار)' : 'Taken Today (Recorded)'}</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>{isAr ? 'تسجيل أخذ الفيتامين الآن' : 'Log Vitamin Intake Now'}</span>
                </>
              )}
            </button>
          </div>
        ))}
      </div>

      {/* Add Custom Vitamin Form Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Pill className="w-5 h-5 text-indigo-400" />
                <span>{isAr ? 'إضافة فيتامين أو مكمل غذائي جديد' : 'Add New Vitamin or Supplement'}</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddVitamin} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'اسم الفيتامين / المكمل:' : 'Supplement Name:'}</label>
                <input
                  type="text"
                  value={newVitaminName}
                  onChange={(e) => setNewVitaminName(e.target.value)}
                  placeholder={isAr ? 'مثال: فيتامين سي 1000 ملجم' : 'e.g. Vitamin C 1000mg'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'الجرعة:' : 'Dosage:'}</label>
                  <input
                    type="text"
                    value={newDosage}
                    onChange={(e) => setNewDosage(e.target.value)}
                    placeholder={isAr ? 'مثال: كبسولة واحدة' : 'e.g. 1 capsule'}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'التصنيف:' : 'Category:'}</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="vitamin">{isAr ? 'فيتامين' : 'Vitamin'}</option>
                    <option value="supplement">{isAr ? 'مكمل غذائي' : 'Supplement'}</option>
                    <option value="mineral">{isAr ? 'معدن أساسي' : 'Mineral'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'موعد التناول اليومي:' : 'Time Slot:'}</label>
                <input
                  type="text"
                  value={newTimeSlot}
                  onChange={(e) => setNewTimeSlot(e.target.value)}
                  placeholder={isAr ? 'مثال: 01:00 PM مع الغداء' : 'e.g. 01:00 PM with Lunch'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-indigo-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'نصيحة الامتصاص:' : 'Best Taken With:'}</label>
                <input
                  type="text"
                  value={newBestWith}
                  onChange={(e) => setNewBestWith(e.target.value)}
                  placeholder={isAr ? 'مثال: مع وجبة دسمة أو قبل النوم' : 'e.g. With fat meal or bedtime'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-950 text-slate-400 hover:text-white font-bold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black"
                >
                  {isAr ? 'حفظ وتوثيق الفيتامين' : 'Save Vitamin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
