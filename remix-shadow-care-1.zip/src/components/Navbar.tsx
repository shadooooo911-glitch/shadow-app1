import React from 'react';
import { Activity, BatteryCharging, Calendar, EyeOff, Moon, ShieldAlert, ShieldCheck, Sparkles, Sun, User, Globe, Heart, Zap, Pill, Flame, CreditCard } from 'lucide-react';
import { Language, PatientProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  patientProfile: PatientProfile;
  ultraBatterySaver: boolean;
  setUltraBatterySaver: (val: boolean | ((prev: boolean) => boolean)) => void;
  autoNightMode?: boolean;
  setAutoNightMode?: (val: boolean | ((prev: boolean) => boolean)) => void;
  isLowBlueLightActive?: boolean;
  onToggleNightModeOverride?: () => void;
  onOpenSOS: () => void;
  onOpenProfile: () => void;
  onOpenPatentModal: () => void;
  onOpenWeeklyDigest: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  language,
  setLanguage,
  patientProfile,
  ultraBatterySaver,
  setUltraBatterySaver,
  autoNightMode = true,
  setAutoNightMode,
  isLowBlueLightActive = false,
  onToggleNightModeOverride,
  onOpenSOS,
  onOpenProfile,
  onOpenPatentModal,
  onOpenWeeklyDigest,
}) => {
  const isAr = language === 'ar';

  const navItems = [
    {
      id: 'readiness',
      labelAr: '1. الجاهزية والجهد اليومي',
      labelEn: '1. Readiness & Energy',
      icon: Zap,
    },
    {
      id: 'heartrate',
      labelAr: '2. نبضات القلب والجهد الحيوي',
      labelEn: '2. Heart Rate & Vitals',
      icon: Heart,
    },
    {
      id: 'safemed',
      labelAr: '3. الأدوية والمواعيد الطبية',
      labelEn: '3. Safe-Med Schedule',
      icon: Pill,
    },
    {
      id: 'scanner',
      labelAr: '4. الماسح الضوئي الذكي (Vision AI)',
      labelEn: '4. Fast Vision AI Scanner',
      icon: Sparkles,
    },
    {
      id: 'ecosports',
      labelAr: '5. أمان القيادة والرياضة والطقس',
      labelEn: '5. Eco-Sports & Driving',
      icon: Flame,
    },
    {
      id: 'subscription',
      labelAr: '6. إدارة الاشتراك (PRO)',
      labelEn: '6. Subscription PRO',
      icon: CreditCard,
    },
  ];

  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-xl border-b border-slate-800/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 lg:px-8">
        
        {/* Top Utility Bar */}
        <div className="flex items-center justify-between py-3 border-b border-slate-900 gap-2">
          
          {/* Brand Logo & Patent Badge */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-0.5 shadow-[0_0_20px_rgba(6,182,212,0.4)]">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-tight text-white flex items-center gap-1.5">
                  <span>SHADOW CARE</span>
                  <span className="text-cyan-400 font-mono text-xs">PRO</span>
                </h1>

                <button
                  onClick={onOpenPatentModal}
                  className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-mono hover:bg-cyan-900 transition-colors"
                >
                  <ShieldCheck className="w-3 h-3 text-cyan-400" />
                  <span>{isAr ? '19 بنود براءة الاختراع' : '19 Patent Claims'}</span>
                </button>
              </div>

              <p className="text-[11px] text-slate-400 font-medium hidden md:block">
                {isAr
                  ? `نظام المتابعة الصحية المتقدم • مراقبة صحة (${patientProfile.name})`
                  : `Advanced Vital Health Engine • Monitoring ${patientProfile.name}`}
              </p>
            </div>
          </div>

          {/* Top Actions */}
          <div className="flex items-center gap-2">
            
            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(isAr ? 'en' : 'ar')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-300 transition-all"
              title="تغيير اللغة / Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isAr ? 'EN' : 'عربي'}</span>
            </button>

            {/* Patent Modal Trigger on Mobile */}
            <button
              onClick={onOpenPatentModal}
              className="sm:hidden p-2 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800 text-xs"
              title="براءة الاختراع"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>

            {/* Automatic Night Mode / Low Blue Light Filter Toggle */}
            <button
              onClick={onToggleNightModeOverride}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                isLowBlueLightActive
                  ? 'bg-amber-950 text-amber-300 border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
              title={
                isAr
                  ? 'النمط ليلي التلقائي (Low Blue Light) لمنع إجهاد العين عند الغروب'
                  : 'Automatic Sunset Night Mode (Low Blue Light Filter)'
              }
            >
              {isLowBlueLightActive ? (
                <Moon className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              ) : (
                <EyeOff className="w-3.5 h-3.5 text-slate-400" />
              )}
              <span className="text-[11px]">
                {isLowBlueLightActive
                  ? isAr
                    ? 'وضع الغروب'
                    : 'Night Mode'
                  : isAr
                  ? 'وضع ليلي'
                  : 'Auto Night'}
              </span>
            </button>

            {/* Battery Saver */}
            <button
              onClick={() => setUltraBatterySaver((prev) => !prev)}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                ultraBatterySaver
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-500 animate-pulse'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px]">
                {ultraBatterySaver
                  ? (isAr ? 'التوفير الفائق' : 'Ultra Battery')
                  : (isAr ? 'توفير البطارية' : 'Battery Saver')}
              </span>
            </button>

            {/* User Profile */}
            <button
              onClick={onOpenProfile}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-colors"
              title={isAr ? 'ملف المريض والطوارئ' : 'Patient Profile'}
            >
              <User className="w-4 h-4 text-cyan-400" />
            </button>

            {/* Sunday Weekly Digest Button */}
            <button
              onClick={onOpenWeeklyDigest}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/80 text-indigo-300 font-bold text-xs transition-all shadow-md"
              title={isAr ? 'الموجز الأسبوعي الأحد' : 'Sunday Weekly Digest'}
            >
              <Calendar className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              <span className="hidden sm:inline">{isAr ? 'الموجز الأسبوعي' : 'Weekly Digest'}</span>
            </button>

            {/* Emergency SOS Button */}
            <button
              onClick={onOpenSOS}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white font-black text-xs shadow-[0_0_20px_rgba(225,29,72,0.5)] hover:scale-105 transition-all transform active:scale-95 animate-pulse"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{isAr ? 'استغاثة SOS' : 'SOS Call'}</span>
            </button>

          </div>
        </div>

        {/* 6 Screen Navigation Tabs */}
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-2 no-scrollbar scroll-smooth text-xs font-bold">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl whitespace-nowrap transition-all shrink-0 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-[0_0_15px_rgba(6,182,212,0.4)] scale-102'
                    : 'bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-cyan-400'}`} />
                <span>{isAr ? item.labelAr : item.labelEn}</span>
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
