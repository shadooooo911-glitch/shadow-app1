import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Award,
  Volume2,
  Download,
  Share2,
  X,
  Sparkles,
  HeartPulse,
  Pill,
  Activity,
  ShieldCheck,
  Zap,
  Clock,
  Sun,
  ChevronRight,
} from 'lucide-react';
import { CurrentVitals, Language, MedicationItem, PatientProfile } from '../types';

interface WeeklyDigestOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  patientProfile: PatientProfile;
  medications: MedicationItem[];
  vitals: CurrentVitals;
  onTriggerSpeech: (text: string) => void;
}

interface DayTrend {
  dayAr: string;
  dayEn: string;
  score: number;
  medsTaken: number;
  medsTotal: number;
  avgHr: number;
  isToday?: boolean;
}

const WEEKLY_TREND_DATA: DayTrend[] = [
  { dayAr: 'الإثنين', dayEn: 'Mon', score: 82, medsTaken: 4, medsTotal: 4, avgHr: 72 },
  { dayAr: 'الثلاثاء', dayEn: 'Tue', score: 85, medsTaken: 4, medsTotal: 4, avgHr: 70 },
  { dayAr: 'الأربعاء', dayEn: 'Wed', score: 79, medsTaken: 3, medsTotal: 4, avgHr: 76 },
  { dayAr: 'الخميس', dayEn: 'Thu', score: 91, medsTaken: 4, medsTotal: 4, avgHr: 68 },
  { dayAr: 'الجمعة', dayEn: 'Fri', score: 88, medsTaken: 4, medsTotal: 4, avgHr: 71 },
  { dayAr: 'السبت', dayEn: 'Sat', score: 94, medsTaken: 4, medsTotal: 4, avgHr: 66 },
  { dayAr: 'الأحد', dayEn: 'Sun', score: 92, medsTaken: 4, medsTotal: 4, avgHr: 69, isToday: true },
];

export const WeeklyDigestOverlay: React.FC<WeeklyDigestOverlayProps> = ({
  isOpen,
  onClose,
  language,
  patientProfile,
  medications,
  vitals,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';
  const [activeTab, setActiveTab] = useState<'recovery' | 'meds' | 'insights'>('recovery');
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const totalMedsDoses = WEEKLY_TREND_DATA.reduce((acc, d) => acc + d.medsTotal, 0);
  const totalMedsTaken = WEEKLY_TREND_DATA.reduce((acc, d) => acc + d.medsTaken, 0);
  const overallAdherencePercent = Math.round((totalMedsTaken / totalMedsDoses) * 100);
  const avgWeeklyScore = Math.round(
    WEEKLY_TREND_DATA.reduce((acc, d) => acc + d.score, 0) / WEEKLY_TREND_DATA.length
  );

  const audioSummaryText = isAr
    ? `التقرير الأسبوعي للمريض ${patientProfile.name}: نسبة الالتزام بالأدوية بلغت ${overallAdherencePercent} بالمائة. معدل التعافي الأسبوعي ${avgWeeklyScore} بالمائة. نبض القلب بمتوسط 70 نبضة في الدقيقة.`
    : `Weekly Digest for ${patientProfile.name}: Medication adherence reached ${overallAdherencePercent}%. Average weekly recovery index is ${avgWeeklyScore}%. Average heart rate is 70 BPM.`;

  const handlePlayVoice = () => {
    onTriggerSpeech(audioSummaryText);
  };

  const handleExportPdf = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
    onTriggerSpeech(
      isAr
        ? 'تم تصدير الموجز الأسبوعي المعتمد كملف PDF طبي.'
        : 'Weekly certified Digest exported as medical PDF report.'
    );
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xl overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25 }}
          className="relative w-full max-w-3xl bg-slate-900 border-2 border-indigo-500/40 rounded-3xl shadow-2xl overflow-hidden text-white my-auto max-h-[90vh] flex flex-col"
        >
          {/* Top Decorative Gradient Line */}
          <div className="h-1.5 bg-gradient-to-r from-cyan-500 via-indigo-500 via-purple-500 to-emerald-500" />

          {/* Modal Header */}
          <div className="p-6 bg-slate-950/90 border-b border-slate-800 flex items-start justify-between gap-4 shrink-0">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold shrink-0 shadow-lg">
                <Calendar className="w-6 h-6 text-indigo-400 animate-pulse" />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px] font-mono font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-indigo-400" />
                    SUNDAY WEEKLY DIGEST
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 font-bold">
                    {isAr ? 'تحديث تلقائي' : 'AUTO-GENERATED'}
                  </span>
                </div>

                <h3 className="text-lg font-black text-white mt-1">
                  {isAr ? `الموجز الأسبوعي للتعافي والدواء • ${patientProfile.name}` : `Weekly Recovery & Med Digest • ${patientProfile.name}`}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isAr ? 'ملخص الأداء الصحي والالتزام بالخطة العلاجية للأسبوع المنصرم' : '7-day health trends, vital stability index, and medication adherence synthesis'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              title={isAr ? 'إغلاق الموجز' : 'Close Digest'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Top Quick Metrics Summary Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-950/50 border-b border-slate-800/80 shrink-0">
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold">{isAr ? 'معدل الالتزام بالأدوية' : 'Med Adherence'}</p>
                <p className="text-base font-black text-emerald-400">{overallAdherencePercent}%</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold">{isAr ? 'متوسط الجاهزية' : 'Avg Readiness'}</p>
                <p className="text-base font-black text-cyan-400">{avgWeeklyScore}%</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-950 text-purple-400 border border-purple-800 flex items-center justify-center shrink-0">
                <HeartPulse className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold">{isAr ? 'متوسط النبض' : 'Avg Heart Rate'}</p>
                <p className="text-base font-black text-purple-300">70 BPM</p>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center shrink-0">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400 font-bold">{isAr ? 'أعلى يوم للجاهزية' : 'Peak Day'}</p>
                <p className="text-base font-black text-amber-400">{isAr ? 'السبت (94%)' : 'Sat (94%)'}</p>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex border-b border-slate-800 px-6 bg-slate-950/30 shrink-0">
            <button
              onClick={() => setActiveTab('recovery')}
              className={`py-3 px-4 font-bold text-xs border-b-2 flex items-center gap-2 transition-all ${
                activeTab === 'recovery'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>{isAr ? 'اتجاهات الجاهزية والتعافي' : 'Recovery & Readiness Trends'}</span>
            </button>

            <button
              onClick={() => setActiveTab('meds')}
              className={`py-3 px-4 font-bold text-xs border-b-2 flex items-center gap-2 transition-all ${
                activeTab === 'meds'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Pill className="w-4 h-4" />
              <span>{isAr ? 'سجل الالتزام الدوائي' : 'Medication Adherence'}</span>
            </button>

            <button
              onClick={() => setActiveTab('insights')}
              className={`py-3 px-4 font-bold text-xs border-b-2 flex items-center gap-2 transition-all ${
                activeTab === 'insights'
                  ? 'border-indigo-500 text-indigo-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>{isAr ? 'توصيات الطبيب الذكي' : 'AI Physician Insights'}</span>
            </button>
          </div>

          {/* Scrollable Content Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1">
            {/* TAB 1: RECOVERY TRENDS */}
            {activeTab === 'recovery' && (
              <div className="space-y-6">
                {/* 7-Day Bar Chart Visualizer */}
                <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-cyan-400" />
                      <span>{isAr ? 'منحنى مؤشر التعافي اليومي (من الإثنين إلى الأحد)' : 'Daily Recovery Index (Mon - Sun)'}</span>
                    </h4>
                    <span className="text-[10px] font-mono text-cyan-400 font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                      TARGET &gt; 80%
                    </span>
                  </div>

                  <div className="h-44 flex items-end justify-between gap-2 pt-6 pb-2 px-2">
                    {WEEKLY_TREND_DATA.map((d, idx) => (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                        <span className="text-[10px] font-mono font-bold text-cyan-300 opacity-0 group-hover:opacity-100 transition-opacity">
                          {d.score}%
                        </span>
                        <div className="w-full max-w-[36px] bg-slate-900 rounded-t-xl overflow-hidden h-full flex items-end relative border border-slate-800">
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${d.score}%` }}
                            transition={{ duration: 0.6, delay: idx * 0.08 }}
                            className={`w-full rounded-t-xl ${
                              d.isToday
                                ? 'bg-gradient-to-t from-cyan-600 to-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.4)]'
                                : 'bg-gradient-to-t from-slate-700 to-indigo-500'
                            }`}
                          />
                        </div>
                        <span
                          className={`text-xs font-bold ${
                            d.isToday ? 'text-emerald-400 font-black' : 'text-slate-400'
                          }`}
                        >
                          {isAr ? d.dayAr : d.dayEn}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Biometric Highlights */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                      <span>{isAr ? 'تحسن كفاءة النوم وإعادة الشحن' : 'Sleep Efficiency & Recharge'}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {isAr
                        ? 'ارتفعت جودة النوم العميق بمقدار 14% مقارنة بالأسبوع الماضي، بمتوسط 7.4 ساعات نوم يومياً.'
                        : 'Deep sleep quality improved by 14% compared to last week, averaging 7.4 hours nightly.'}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-purple-400">
                      <HeartPulse className="w-4 h-4 text-purple-400" />
                      <span>{isAr ? 'مؤشر تقلب النبض HRV' : 'HRV Recovery Stability'}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {isAr
                        ? 'ارتفع مؤشر HRV ليبلغ 68ms، مما يعكس استجابة ممتازة للجهاز العصبي ونقص التوتر.'
                        : 'HRV index rose to 68ms, reflecting robust autonomic nervous system recovery and lower stress.'}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: MEDICATION ADHERENCE */}
            {activeTab === 'meds' && (
              <div className="space-y-6">
                {/* Adherence Score Header Banner */}
                <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-emerald-950/80 border border-emerald-800/80 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-900 text-emerald-300 border border-emerald-700 flex items-center justify-center font-black text-lg">
                      {overallAdherencePercent}%
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {isAr ? 'نسبة الالتزام بالخطة العلاجية' : 'Overall Treatment Plan Adherence'}
                      </h4>
                      <p className="text-xs text-emerald-300/90 mt-0.5">
                        {isAr
                          ? `تم تناول ${totalMedsTaken} جرعة من أصل ${totalMedsDoses} جرعة مقررة هذا الأسبوع.`
                          : `Successfully taken ${totalMedsTaken} out of ${totalMedsDoses} prescribed doses this week.`}
                      </p>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs font-bold font-mono">
                    EXCELLENT
                  </span>
                </div>

                {/* Individual Medication Status Cards */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-wider">
                    {isAr ? 'تفاصيل الأدوية المسجلة هذا الأسبوع' : 'Prescription Adherence Breakdown'}
                  </h4>

                  {medications.map((med) => (
                    <div
                      key={med.id}
                      className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0">
                          <Pill className="w-4 h-4 text-purple-400" />
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-white">
                            {isAr ? med.nameAr : med.nameEn} ({med.dosage})
                          </h5>
                          <p className="text-[11px] text-slate-400">
                            {med.frequency} • {med.timeSlot}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-3 py-1 rounded-xl border border-emerald-800 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>100% {isAr ? 'التزام' : 'On-Time'}</span>
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: AI PHYSICIAN INSIGHTS */}
            {activeTab === 'insights' && (
              <div className="space-y-4">
                <div className="p-5 rounded-2xl bg-slate-950 border border-indigo-900/60 space-y-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                    <h4 className="text-sm font-black text-white">
                      {isAr ? 'الملخص الطبي والتوصيات المخصصة للأسبوع القادم' : 'AI Medical Synthesis & Weekly Guidance'}
                    </h4>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                    {isAr
                      ? `ممتاز جداً يا ${patientProfile.name}! أظهرت مؤشراتك أسبوعاً مستقراً للغاية مع التزام شبه كامل بمواعيد الأدوية. ساعدت تمارين التنفس 4-7-8 والتعرض لضوء الشمس الصباحي على تخفيض فترات الإجهاد بنسبة 35%. نوصي بالاستمرار بنفس الخطة مع الحفاظ على معدل شرب الماء فوق 2000 مل يومياً.`
                      : `Great progress, ${patientProfile.name}! Your vitals showed high stability this week with stellar medication compliance. Morning sunlight routines and 4-7-8 breathing sessions reduced stress durations by 35%. Continue maintaining water intake above 2,000ml daily.`}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-800/60 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Sun className="w-5 h-5 text-amber-400" />
                    <div>
                      <h5 className="text-xs font-bold text-white">
                        {isAr ? 'الهدف الجديد للأسبوع القادم' : 'Target for Next Week'}
                      </h5>
                      <p className="text-[11px] text-indigo-200">
                        {isAr ? 'زيادة التعرض للشمس الصباحية إلى 25 دقيقة يومياً' : 'Increase morning sunlight exposure to 25 mins daily'}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950 px-3 py-1 rounded-xl border border-amber-800">
                    +5 MINS
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer Actions */}
          <div className="p-5 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0">
            <button
              onClick={handlePlayVoice}
              className="py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 text-xs font-bold flex items-center gap-2 transition-all"
            >
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <span>{isAr ? 'استماع للتقرير الصوتي' : 'Play Audio Digest'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportPdf}
                className={`py-2.5 px-4 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all ${
                  downloadSuccess
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800'
                }`}
              >
                {downloadSuccess ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Download className="w-4 h-4 text-indigo-400" />
                )}
                <span>
                  {downloadSuccess
                    ? isAr
                      ? 'تم التصدير'
                      : 'Exported'
                    : isAr
                    ? 'تصدير تقرير PDF'
                    : 'Export PDF Report'}
                </span>
              </button>

              <button
                onClick={onClose}
                className="py-2.5 px-5 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black shadow-lg transition-all"
              >
                {isAr ? 'حفظ وإغلاق الموجز' : 'Dismiss & Save Digest'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
