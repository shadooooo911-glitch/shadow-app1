import React, { useState } from 'react';
import { Ambulance, Car, Compass, Droplets, Flame, MapPin, Mountain, Phone, ShieldCheck, Sun, Thermometer, Waves, Wind } from 'lucide-react';
import { CurrentVitals, EcoWeatherData, Language, PatientProfile } from '../types';

interface Screen5EcoSportsRadarProps {
  language: Language;
  vitals: CurrentVitals;
  ecoWeather: EcoWeatherData;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
}

export const Screen5EcoSportsRadar: React.FC<Screen5EcoSportsRadarProps> = ({
  language,
  vitals,
  ecoWeather,
  patientProfile,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';
  const [selectedSportMode, setSelectedSportMode] = useState<'driving' | 'swimming' | 'climbing' | 'gym'>('driving');
  const [consumedHydration, setConsumedHydration] = useState(1.8); // Liters
  const requiredHydration = (2.5 + (ecoWeather.temperatureC > 35 ? 0.8 : 0.3)).toFixed(1);

  const handleLogHydration = () => {
    const nextVal = +(consumedHydration + 0.3).toFixed(1);
    setConsumedHydration(nextVal);
    onTriggerSpeech(isAr ? `تم تسجيل شرب 300 مل من الماء. الإجمالي اليومي: ${nextVal} لتر.` : `Logged 300ml water. Total today: ${nextVal}L.`);
  };

  const handleSelectMode = (mode: 'driving' | 'swimming' | 'climbing' | 'gym') => {
    setSelectedSportMode(mode);
    if (mode === 'driving') {
      onTriggerSpeech(isAr ? 'تم تفعيل رادار أمان القيادة وانحناء الرقبة.' : 'Driving safety radar active.');
    } else if (mode === 'swimming') {
      onTriggerSpeech(isAr ? 'تم تفعيل نمط السباحة والمجهود المائي الهيدروديناميكي.' : 'Swimming water mode active.');
    } else if (mode === 'climbing') {
      onTriggerSpeech(isAr ? 'تم تفعيل نمط تسلق الجبال ومراقبة الأكسجين والارتفاعات.' : 'Mountain climbing altitude mode active.');
    } else {
      onTriggerSpeech(isAr ? 'تم تفعيل نمط الجيم والوقاية الاستباقية من الشد العضلي.' : 'Gym mode cramp prevention active.');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-orange-950 text-orange-300 border border-orange-800 text-[10px] font-mono font-bold">
              PATENT CLAIM-10 & CLAIMS 18-19
            </span>
            <span className="text-xs text-slate-400">الشاشة 5 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1 flex items-center gap-2">
            <Flame className="w-6 h-6 text-orange-400" />
            <span>{isAr ? 'التنبيهات المناخية، حاسبة الجفاف والتصعيد الهرمي' : 'Geolocated Weather Shield & Escalation'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `ربط تلقائي بالموقع وقراءة الحرارة والرطوبة للوقاية من الجفاف وتفعيل بروتوكول التصعيد الهرمي لـ (${patientProfile.name})`
              : `Dynamic GPS weather shield & tiered emergency escalation protocol for ${patientProfile.name}`}
          </p>
        </div>

        {/* GPS Location Badge */}
        <div className="flex items-center gap-2 bg-slate-950 px-3.5 py-2 rounded-2xl border border-slate-800 text-xs font-mono font-bold text-cyan-400">
          <MapPin className="w-4 h-4 text-rose-500 animate-pulse" />
          <span>{isAr ? ecoWeather.locationNameAr : ecoWeather.locationNameEn}</span>
        </div>
      </div>

      {/* Weather Metrics & Hydration Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Sun className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'درجة الحرارة / المؤشر' : 'Temp / Heat Index'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-white">
            {ecoWeather.temperatureC}°C
            <span className="text-xs text-amber-400 font-sans ml-1">({ecoWeather.heatIndexC}°C)</span>
          </div>
          <div className="text-[10px] text-amber-400 font-bold">{isAr ? 'خطر إجهاد حراري متوسط' : 'Moderate Heat Risk'}</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Wind className="w-4 h-4 text-cyan-400" />
            <span>{isAr ? 'الرطوبة النسبية' : 'Relative Humidity'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-white">
            {ecoWeather.humidityPercent}%
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">{isAr ? 'جفاف معتدل' : 'Moderate Dryness'}</div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Mountain className="w-4 h-4 text-indigo-400" />
            <span>{isAr ? 'الارتفاع والضغط' : 'Altitude Meter'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-white">
            {ecoWeather.altitudeMeters}
            <span className="text-xs text-slate-400 font-sans ml-1">m</span>
          </div>
          <div className="text-[10px] text-indigo-400 font-bold">{isAr ? 'ضغط جوي آمن' : 'Safe Pressure'}</div>
        </div>

        {/* Dynamic Hydration Card */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <Droplets className="w-4 h-4 text-blue-400" />
              <span>{isAr ? 'حاسبة السوائل' : 'Hydration Calc'}</span>
            </span>
            <button
              onClick={handleLogHydration}
              className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800 hover:bg-blue-900"
            >
              + 300ml
            </button>
          </div>
          <div className="text-xl font-black font-mono text-blue-400">
            {consumedHydration}L / {requiredHydration}L
          </div>
          <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-blue-400 h-full rounded-full transition-all"
              style={{ width: `${Math.min(100, (consumedHydration / +requiredHydration) * 100)}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Hierarchical Emergency Escalation Box (Claims 18 & 19) */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Ambulance className="w-5 h-5 text-rose-500 animate-pulse" />
            <div>
              <h3 className="text-sm font-black text-white">
                {isAr ? 'بروتوكول التصعيد الطارئ الهرمي المزدوج (Patent Claims 18 & 19)' : 'Tiered Emergency Escalation Protocol (Claims 18 & 19)'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isAr ? 'تنبيه الأهل بالبيت أولاً، ثم التصعيد الآلي للإسعاف بعد 45 ثانية' : 'Notifies house residents first, then auto-escalates to official dispatch (997/911)'}
              </p>
            </div>
          </div>

          <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-rose-950 text-rose-300 border border-rose-800 font-bold">
            2-TIER ESCALATION
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          
          {/* Tier 1: House Residents First */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between font-bold text-amber-400">
              <span className="flex items-center gap-1.5">
                <Phone className="w-4 h-4" />
                <span>{isAr ? 'المرحلة 1: المقيم بالمنزل (House Resident)' : 'Tier 1: Resident Family'}</span>
              </span>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-amber-950 border border-amber-800">45s TIMER</span>
            </div>
            <p className="text-slate-300">
              {isAr ? 'تنبيه هاتف الزوجة/الأخ المقيم بالبيت أولاً لمنع الفزع وإعطاء مهلة لإلغاء الإنذار.' : 'Notifies house resident phone first with "I\'m Fine" countdown.'}
            </p>
            <div className="font-mono text-[11px] text-slate-400 bg-slate-900 p-2 rounded-xl border border-slate-800">
              📞 {patientProfile.emergencyContactName} ({patientProfile.emergencyContactPhone})
            </div>
          </div>

          {/* Tier 2: Official Dispatch */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between font-bold text-rose-400">
              <span className="flex items-center gap-1.5">
                <Ambulance className="w-4 h-4" />
                <span>{isAr ? 'المرحلة 2: الإسعاف والطوارئ (Official 997/911)' : 'Tier 2: Official Dispatch'}</span>
              </span>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-rose-950 border border-rose-800">AUTO DISPATCH</span>
            </div>
            <p className="text-slate-300">
              {isAr ? 'عند عدم الاستجابة، يتم الاتصال تلقائياً بهيئة الإسعاف مع إرسال موقع GPS والتقرير الطبي المشفّر.' : 'Automatic 997/911 dispatch with live GPS coordinates and encrypted Clinic Pass.'}
            </p>
            <div className="font-mono text-[11px] text-rose-300 bg-rose-950/40 p-2 rounded-xl border border-rose-800">
              🚨 {isAr ? 'الهيئة السعودية للإسعاف / الطوارئ (997 / 911)' : 'Official Red Crescent Emergency Dispatch (997/911)'}
            </div>
          </div>

        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-black text-white">
            {isAr ? 'أنماط الأمان والرياضات المخصصة:' : 'Specialized Safety & Sport Modes:'}
          </h3>
          <span className="text-[10px] font-mono px-2.5 py-0.5 rounded bg-orange-950 text-orange-400 font-bold border border-orange-800">
            ADAPTIVE SHIELD
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-bold">
          <button
            onClick={() => handleSelectMode('driving')}
            className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
              selectedSportMode === 'driving'
                ? 'bg-emerald-950 text-emerald-300 border-emerald-500 shadow-lg'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Car className="w-6 h-6 text-emerald-400" />
            <span>{isAr ? 'رادار أمان القيادة' : 'Driving Safety'}</span>
          </button>

          <button
            onClick={() => handleSelectMode('swimming')}
            className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
              selectedSportMode === 'swimming'
                ? 'bg-cyan-950 text-cyan-300 border-cyan-500 shadow-lg'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Waves className="w-6 h-6 text-cyan-400" />
            <span>{isAr ? 'نمط السباحة (مجهود مائي)' : 'Swimming Mode'}</span>
          </button>

          <button
            onClick={() => handleSelectMode('climbing')}
            className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
              selectedSportMode === 'climbing'
                ? 'bg-indigo-950 text-indigo-300 border-indigo-500 shadow-lg'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Mountain className="w-6 h-6 text-indigo-400" />
            <span>{isAr ? 'تسلق الجبال (أكسجين)' : 'Mountain Climbing'}</span>
          </button>

          <button
            onClick={() => handleSelectMode('gym')}
            className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
              selectedSportMode === 'gym'
                ? 'bg-orange-950 text-orange-300 border-orange-500 shadow-lg'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Flame className="w-6 h-6 text-orange-400" />
            <span>{isAr ? 'الشارع والجيم (الشد العضلي)' : 'Gym & Muscle Shield'}</span>
          </button>
        </div>

        {/* Selected Mode Details Box */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          {selectedSportMode === 'driving' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
                <span>{isAr ? 'حالة تركيز السائق والوقاية من النعاس (Driving Focus)' : 'Driver Focus & Anti-Drowsiness'}</span>
                <span className="font-mono text-emerald-400">ACTIVE RADAR</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isAr
                  ? 'يقوم رادار القيادة بمراقبة زاوية الرقبة وتغيرات HRV لمنع الغفوة والتشتت السمعي، مع إطلاق تنبيهات ناطقة فورية عند انحناء الرقبة أكثر من 20 درجة.'
                  : 'Monitors driver neck angle and HRV variations to prevent drowsiness with real-time audio corrections.'}
              </p>
            </div>
          )}

          {selectedSportMode === 'swimming' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-cyan-400">
                <span>{isAr ? 'تتبع المجهود المائي ومقاومة المياه (Water Hydrodynamics)' : 'Hydrodynamic Water Strain Tracking'}</span>
                <span className="font-mono text-cyan-400">WATER SEALED</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isAr
                  ? 'تعديل المعايرة الذاتية لمستشعر SpO2 الضوئي ليعمل بكفاءة تحت الماء ويحسب كتم النفس والسعرات المستهلكة في المجهود المائي.'
                  : 'Calibrates optical PPG sensors underwater to monitor breath holding and hydrodynamic stroke effort.'}
              </p>
            </div>
          )}

          {selectedSportMode === 'climbing' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-400">
                <span>{isAr ? 'رصد نقص الأكسجين بالارتفاعات (Altitude Hypoxia Guard)' : 'Altitude Hypoxia Guard'}</span>
                <span className="font-mono text-indigo-400">ALTITUDE ACTIVE</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isAr
                  ? 'حساب الضغط الجوي وارتفاع الـ 612m للوقاية من الدوار ونقص الأكسجين الحاد أثناء التسلق.'
                  : 'Calculates ambient barometric pressure and altitude to predict acute mountain sickness and hypoxia.'}
              </p>
            </div>
          )}

          {selectedSportMode === 'gym' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-orange-400">
                <span>{isAr ? 'الوقاية الاستباقية من الشد والإجهاد العضلي (Muscle Cramp Shield)' : 'Proactive Muscle Cramp Shield'}</span>
                <span className="font-mono text-orange-400">HYDRATION GUARD</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isAr
                  ? 'تحليل معدل التعرق ورطوبة الجو لمنع الشد العضلي المفاجئ أثناء رفع الأوزان، والتنبيه بشرب الماء والمغنيسيوم.'
                  : 'Analyzes sweat rate and ambient heat index to issue proactive hydration and magnesium reminders.'}
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
