import React, { useState } from 'react';
import { Calendar, CheckCircle2, Circle, Clock, Coffee, Moon, Pill, Plus, ShieldCheck, Sparkles, Trash2, Zap } from 'lucide-react';
import { Language, PatientProfile, ScheduleEventItem } from '../types';

interface DailyScheduleManagerProps {
  language: Language;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
  onUpdateBodyEnergy?: (newEnergy: number) => void;
}

export const DailyScheduleManager: React.FC<DailyScheduleManagerProps> = ({
  language,
  patientProfile,
  onTriggerSpeech,
  onUpdateBodyEnergy,
}) => {
  const isAr = language === 'ar';

  const [scheduleItems, setScheduleItems] = useState<ScheduleEventItem[]>([
    {
      id: 'sch-1',
      time: '07:00 AM',
      titleAr: 'الاستيقاظ ورصد شحن الطاقة الصباحي (Morning Charge 65%)',
      titleEn: 'Morning Wakeup & Energy Charge Check (65%)',
      category: 'morning_charge',
      completed: true,
      energyBudgetPercent: 65,
      priority: 'high',
      notesAr: 'ميزانية الطاقة المحسوبة تلقائياً بناءً على جودة النوم الليلية.',
      notesEn: 'Calculated energy budget based on nocturnal sleep HRV.',
    },
    {
      id: 'sch-[2]',
      time: '08:00 AM',
      titleAr: 'جرعة علاجات القلب والضغط (كونكور 5 ملجم)',
      titleEn: 'Concor 5mg Heart & Blood Pressure Dose',
      category: 'medication',
      completed: true,
      energyBudgetPercent: 0,
      priority: 'critical',
      notesAr: 'محمية ومشفّرة محلياً ضمن بروتوكول Claim-03.',
      notesEn: 'Encrypted dose under Claim-03 protocol.',
    },
    {
      id: 'sch-3',
      time: '09:30 AM',
      titleAr: 'نافذة تناول كوب القهوة الأول (تتبع الكافيين)',
      titleEn: 'First Coffee Cup Window (Caffeine Tracker)',
      category: 'caffeine_window',
      completed: true,
      energyBudgetPercent: -5,
      priority: 'normal',
      notesAr: 'جرعة كافيين 75mg ترفع التنبؤ بالتركيز دون تجاوز ضربات القلب.',
      notesEn: '75mg caffeine dose within safe HR limits.',
    },
    {
      id: 'sch-4',
      time: '11:30 AM',
      titleAr: 'رصد استقامة العمود الفقري وتصحيح انحناء الرقبة',
      titleEn: 'Spine Alignment & Neck Inclination Scan',
      category: 'work_posture',
      completed: false,
      energyBudgetPercent: -10,
      priority: 'high',
      notesAr: 'تنبيه ناطق بالسوار عند زيادة انحناء الرقبة عن 20 درجة.',
      notesEn: 'Voice alert if neck tilt exceeds 20 degrees.',
    },
    {
      id: 'sch-5',
      time: '01:00 PM',
      titleAr: 'جرعة فيتامين د3 (5000 IU) مع وجبة الغداء',
      titleEn: 'Vitamin D3 (5000 IU) Intake with Lunch',
      category: 'medication',
      completed: false,
      energyBudgetPercent: 0,
      priority: 'normal',
    },
    {
      id: 'sch-6',
      time: '05:30 PM',
      titleAr: 'جولة المشي الرياضي التكيفية (مراقبة النبض والضغط)',
      titleEn: 'Adaptive Workout Walk (HR & BP Guard)',
      category: 'workout',
      completed: false,
      energyBudgetPercent: -20,
      priority: 'high',
      notesAr: 'تنبيه آلي بالحد الأقصى للنبض الآمن (140 BPM).',
      notesEn: 'Safe HR cap alert at 140 BPM.',
    },
    {
      id: 'sch-7',
      time: '11:00 PM',
      titleAr: 'تفعيل وضع حماية النوم والسهر الوقائي (Sleep Shield Engine)',
      titleEn: 'Sleep Shield Engine Activation (11 PM)',
      category: 'sleep_shield',
      completed: false,
      energyBudgetPercent: +30,
      priority: 'critical',
      notesAr: 'تحضير الجسم للنوم وإطفاء التنبيهات غير الطارئة.',
      notesEn: 'Prepares body for recovery sleep.',
    },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newCategory, setNewCategory] = useState<ScheduleEventItem['category']>('custom');
  const [newPriority, setNewPriority] = useState<ScheduleEventItem['priority']>('normal');

  const completedCount = scheduleItems.filter((item) => item.completed).length;

  const handleToggleCompleted = (id: string) => {
    setScheduleItems((prev) => {
      const updated = prev.map((item) => {
        if (item.id === id) {
          const nextState = !item.completed;
          if (nextState) {
            onTriggerSpeech(
              isAr
                ? `تم إنجاز وتوثيق الموعد (${item.titleAr}) بنجاح.`
                : `Completed event: ${item.titleEn}.`
            );
          }
          return { ...item, completed: nextState };
        }
        return item;
      });

      // Calculate new body battery score based on completed items starting from base 65
      const netEnergyChange = updated
        .filter((it) => it.completed)
        .reduce((sum, it) => sum + (it.energyBudgetPercent || 0), 0);

      const calculatedEnergy = Math.min(100, Math.max(10, Math.round(netEnergyChange)));
      if (onUpdateBodyEnergy) {
        onUpdateBodyEnergy(calculatedEnergy);
      }

      return updated;
    });
  };

  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    let defaultEnergyImpact = 0;
    if (newCategory === 'workout') defaultEnergyImpact = -20;
    if (newCategory === 'caffeine_window') defaultEnergyImpact = -5;
    if (newCategory === 'morning_charge') defaultEnergyImpact = 65;
    if (newCategory === 'sleep_shield') defaultEnergyImpact = 30;

    const newItem: ScheduleEventItem = {
      id: 'sch-' + Date.now(),
      time: newTime || '04:00 PM',
      titleAr: newTitle,
      titleEn: newTitle,
      category: newCategory,
      completed: false,
      energyBudgetPercent: defaultEnergyImpact,
      priority: newPriority,
    };

    setScheduleItems((prev) => [...prev, newItem].sort((a, b) => a.time.localeCompare(b.time)));
    setNewTitle('');
    setNewTime('');
    setShowAddForm(false);

    onTriggerSpeech(
      isAr
        ? `تم إضافة الموعد الجديد إلى جدول ${patientProfile.name} بنجاح.`
        : `Added new schedule event for ${patientProfile.name}.`
    );
  };

  const handleDeleteEvent = (id: string) => {
    setScheduleItems((prev) => prev.filter((item) => item.id !== id));
  };

  const getCategoryIcon = (category: ScheduleEventItem['category']) => {
    switch (category) {
      case 'morning_charge':
        return <Zap className="w-4 h-4 text-emerald-400" />;
      case 'medication':
        return <Pill className="w-4 h-4 text-indigo-400" />;
      case 'caffeine_window':
        return <Coffee className="w-4 h-4 text-amber-400" />;
      case 'work_posture':
        return <Sparkles className="w-4 h-4 text-cyan-400" />;
      case 'sleep_shield':
        return <Moon className="w-4 h-4 text-blue-400" />;
      default:
        return <Calendar className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold">
            <Calendar className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-mono font-bold">
                PATENT CLAIMS 01, 09 & 17
              </span>
              <span className="text-[10px] text-cyan-400 font-mono font-bold">DAILY TIMELINE</span>
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              {isAr ? 'إدارة الجدول والروتين اليومي الموحد' : 'Unified Daily Schedule & Timeline Manager'}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-xs font-mono font-bold px-3.5 py-1.5 rounded-xl bg-slate-950 text-cyan-400 border border-slate-800">
            {completedCount} / {scheduleItems.length} {isAr ? 'مكتمل' : 'Completed'}
          </div>

          <button
            onClick={() => setShowAddForm(true)}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-colors shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إضافة موعد' : 'Add Event'}</span>
          </button>
        </div>
      </div>

      {/* Progress Summary Banner */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400 font-mono font-black text-sm flex items-center justify-center">
            {Math.round((completedCount / (scheduleItems.length || 1)) * 100)}%
          </div>
          <div>
            <div className="font-bold text-white">
              {isAr ? `جدول الصحة والروتين اليومي لـ (${patientProfile.name})` : `Daily Routine for ${patientProfile.name}`}
            </div>
            <div className="text-[11px] text-slate-400">
              {isAr
                ? 'دمج مواعيد الأدوية، الكافيين، الرياضة، وحماية النوم 11 PM مع رصيد شحن الجاهزية 65%.'
                : 'Fuses medications, caffeine windows, workout, and 11 PM Sleep Shield.'}
            </div>
          </div>
        </div>

        <div className="w-full md:w-48 bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
          <div
            className="bg-cyan-400 h-full rounded-full transition-all"
            style={{ width: `${(completedCount / (scheduleItems.length || 1)) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Schedule Events Timeline */}
      <div className="space-y-3">
        {scheduleItems.map((item) => (
          <div
            key={item.id}
            className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
              item.completed
                ? 'bg-slate-950/70 border-emerald-500/50 opacity-80'
                : item.priority === 'critical'
                ? 'bg-slate-950 border-rose-800/80 shadow-[0_0_12px_rgba(225,29,72,0.1)]'
                : 'bg-slate-950 border-slate-800 hover:border-cyan-500/50'
            }`}
          >
            <div className="flex items-start gap-3">
              <button
                onClick={() => handleToggleCompleted(item.id)}
                className={`mt-0.5 p-1 rounded-full transition-colors ${
                  item.completed ? 'text-emerald-400' : 'text-slate-600 hover:text-cyan-400'
                }`}
              >
                {item.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <Circle className="w-5 h-5 text-slate-500" />
                )}
              </button>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-cyan-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" />
                    <span>{item.time}</span>
                  </span>

                  {item.priority === 'critical' && (
                    <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-mono font-bold">
                      CRITICAL
                    </span>
                  )}

                  <span className="p-1 rounded bg-slate-900 border border-slate-800">
                    {getCategoryIcon(item.category)}
                  </span>
                </div>

                <h4 className={`text-sm font-bold ${item.completed ? 'line-through text-slate-400' : 'text-white'}`}>
                  {isAr ? item.titleAr : item.titleEn}
                </h4>

                {item.notesAr && (
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {isAr ? item.notesAr : item.notesEn}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                onClick={() => handleToggleCompleted(item.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  item.completed
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {item.completed ? (isAr ? 'تم الإنجاز' : 'Done') : (isAr ? 'علامة إنجاز' : 'Mark Done')}
              </button>

              <button
                onClick={() => handleDeleteEvent(item.id)}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-rose-950 text-slate-500 hover:text-rose-400"
                title="حذف"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Custom Schedule Event Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-cyan-400" />
                <span>{isAr ? 'إضافة موعد أو حدث جديد بالجدول' : 'Add New Schedule Event'}</span>
              </h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddEvent} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'عنوان الموعد / النشاط:' : 'Event Title:'}</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: فحص ضغط الدم أو جلسة التأمل' : 'e.g. Meditation or BP Check'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'الوقت (hh:mm AM/PM):' : 'Time:'}</label>
                  <input
                    type="text"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    placeholder="04:30 PM"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 focus:outline-none font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'الأولوية:' : 'Priority:'}</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="normal">{isAr ? 'عادية (Normal)' : 'Normal'}</option>
                    <option value="high">{isAr ? 'مهمة (High)' : 'High'}</option>
                    <option value="critical">{isAr ? 'حرجة (Critical)' : 'Critical'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-bold">{isAr ? 'التصنيف الحيوي:' : 'Category:'}</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 focus:outline-none"
                >
                  <option value="workout">{isAr ? 'تمارين ورياضة (Workout)' : 'Workout'}</option>
                  <option value="medication">{isAr ? 'علاج ومكمل (Medication)' : 'Medication'}</option>
                  <option value="caffeine_window">{isAr ? 'كافيين (Caffeine)' : 'Caffeine'}</option>
                  <option value="work_posture">{isAr ? 'قوام ورقبة (Posture)' : 'Posture'}</option>
                  <option value="sleep_shield">{isAr ? 'نوم وحماية (Sleep Shield)' : 'Sleep Shield'}</option>
                  <option value="custom">{isAr ? 'آخر (Custom)' : 'Custom'}</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 rounded-xl bg-slate-950 text-slate-400 hover:text-white font-bold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-black"
                >
                  {isAr ? 'إضافة الموعد' : 'Add Event'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
