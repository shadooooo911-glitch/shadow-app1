import React, { useState } from 'react';
import { Activity, AlertTriangle, Battery, BatteryCharging, CheckCircle2, Droplets, Moon, Plus, RotateCcw, ShieldAlert, Sparkles, Sun, UserCheck, Volume2, Zap } from 'lucide-react';
import { DailyScheduleManager } from './DailyScheduleManager';
import { CircadianRhythmWidget } from './CircadianRhythmWidget';
import { SleepGuardAndRecoveryDashboard } from './SleepGuardAndRecoveryDashboard';
import { WeeklyTrendChart } from './WeeklyTrendChart';
import { VitalAnomalyMonitor } from './VitalAnomalyMonitor';
import { SmartShortcutsRow } from './SmartShortcutsRow';
import { CurrentVitals, Language, PatientProfile } from '../types';

interface Screen1ReadinessProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  onUpdateVitals: (vitals: Partial<CurrentVitals>) => void;
  onTriggerSpeech: (text: string) => void;
  onOpenSOSModal: () => void;
  onOpenBreathingOverlay?: (reason?: string) => void;
  onNavigateTab?: (tabId: string) => void;
}

export const Screen1Readiness: React.FC<Screen1ReadinessProps> = ({
  language,
  vitals,
  patientProfile,
  onUpdateVitals,
  onTriggerSpeech,
  onOpenSOSModal,
  onOpenBreathingOverlay,
  onNavigateTab,
}) => {
  const isAr = language === 'ar';

  // Sleep Shield & Morning Charge State
  const [sleepHours, setSleepHours] = useState(7.5);
  const [sleepScore, setSleepScore] = useState(88);
  const [morningBudgetPercent, setMorningBudgetPercent] = useState(65);
  const [lateNightWarningStage, setLateNightWarningStage] = useState<0 | 1 | 2 | 3>(0);

  // Water Intake Tracking State (Target from Patient Profile)
  const [waterIntakeMl, setWaterIntakeMl] = useState<number>(1250);
  const waterGoalMl = patientProfile.targetWaterIntakeMl || 2500;

  const handleAddWater = (amountMl: number) => {
    const newIntake = waterIntakeMl + amountMl;
    setWaterIntakeMl(newIntake);

    // Boost Body Battery energy level (+3% per 250ml glass up to max 100%)
    const energyBoost = Math.round((amountMl / 250) * 3);
    const updatedEnergy = Math.min(100, Math.max(10, vitals.bodyEnergy + energyBoost));

    onUpdateVitals({ bodyEnergy: updatedEnergy });

    const msg = isAr
      ? `تم إضافة ${amountMl} مل من الماء (الإجمالي ${newIntake} مل من ${waterGoalMl} مل). ارتفع شحن بطارية الجسم إلى ${updatedEnergy}%.`
      : `Added ${amountMl}ml of water (Total: ${newIntake}ml / ${waterGoalMl}ml). Body Battery energy boosted to ${updatedEnergy}%.`;
    onTriggerSpeech(msg);
  };

  const handleResetWater = () => {
    setWaterIntakeMl(0);
    const msg = isAr ? 'تم إعادة ضبط تتبع شرب الماء اليومي.' : 'Daily water intake tracker reset.';
    onTriggerSpeech(msg);
  };

  // Determine current alert level state
  let alertTier: 'green' | 'yellow' | 'red' = 'green';
  if (vitals.heartRate > 120 || vitals.spo2 < 92 || vitals.bodyEnergy < 35) {
    alertTier = 'red';
  } else if (vitals.heartRate > 95 || vitals.stressLevel > 60 || vitals.postureNeckAngle > 22) {
    alertTier = 'yellow';
  }

  const handleRecalibrateMorningBudget = () => {
    setMorningBudgetPercent(65);
    onUpdateVitals({
      bodyEnergy: 85,
      stressLevel: 18,
      heartRate: 70,
    });
    const msg = isAr
      ? 'تم تفعيل خوارزمية شحن الصباح وميزانية الجدول اليومي بنسبة 65% عند الاستيقاظ بنجاح.'
      : 'Morning Charge Budget recalibrated to 65% daily energy budget upon wake-up.';
    onTriggerSpeech(msg);
  };

  const handleSimulateLateNightStayOut = () => {
    const nextStage = ((lateNightWarningStage + 1) % 4) as 0 | 1 | 2 | 3;
    setLateNightWarningStage(nextStage);

    if (nextStage === 1) {
      onTriggerSpeech(isAr ? 'تنبيه السهر الوقائي المرحلة 1: تجاوزت الساعة 11 مساءً خارج البيت. يرجى التوجه للمنزل.' : 'Sleep Shield Level 1: Past 11 PM outdoors. Head home for rest.');
    } else if (nextStage === 2) {
      onTriggerSpeech(isAr ? 'تنبيه السهر المرحلة 2: خفض ميزانية الطاقة غداً بنسبة 30% بسبب السهر خارج البيت!' : 'Sleep Shield Level 2: Tomorrow energy budget reduced by 30% due to late stay!');
    } else if (nextStage === 3) {
      onTriggerSpeech(isAr ? 'تنبيه السهر المرحلة 3 (أحمر): تنبيه هاتف المقيم بالمنزل واستشعار الإرهاق الحراري!' : 'Sleep Shield Level 3 (Red): Resident notified of severe late-night fatigue outdoors!');
    }
  };

  const handleSetAlertTier = (tier: 'green' | 'yellow' | 'red') => {
    if (tier === 'green') {
      onUpdateVitals({
        heartRate: 72,
        spo2: 98,
        bodyEnergy: 88,
        stressLevel: 22,
        postureNeckAngle: 12,
      });
      const msg = isAr ? 'تم إعادة تعيين المؤشرات الحيوية لنطاق الجاهزية الأخضر الآمن.' : 'Vitals reset to Green safe readiness tier.';
      onTriggerSpeech(msg);
    } else if (tier === 'yellow') {
      onUpdateVitals({
        heartRate: 104,
        spo2: 95,
        bodyEnergy: 52,
        stressLevel: 68,
        postureNeckAngle: 26,
      });
      const msg = isAr ? 'تنبيه أصفر متوسط! الجهد اليومي متزايد مع انحناء في الرقبة.' : 'Yellow Warning Tier! Moderate daily effort and neck slouching.';
      onTriggerSpeech(msg);
    } else {
      onUpdateVitals({
        heartRate: 138,
        spo2: 89,
        bodyEnergy: 24,
        stressLevel: 88,
        postureNeckAngle: 32,
      });
      const msg = isAr ? 'تحذير أحمر طارئ! انخفاض طاقة الجسم وارتفاع تسارع النبض!' : 'Red Critical Alert! Critical body energy drop and pulse spike!';
      onTriggerSpeech(msg);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-mono font-bold">
              PATENT CLAIM-01, CLAIM-12 & CLAIM-17
            </span>
            <span className="text-xs text-slate-400">الشاشة 1 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1">
            {isAr ? 'مؤشر الجاهزية، شحن الصباح والتعافي (Morning Charge & Sleep Shield)' : 'Readiness Index, Morning Charge & Sleep Shield'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `محرك التحليل التراكمي المدمج لحالة (${patientProfile.name}) مع ميزانية شحن الصباح 65% ونظام السهر الوقائي`
              : `Integrated cumulative readiness engine for ${patientProfile.name} with 65% morning budget & sleep shield`}
          </p>
        </div>

        {/* Quick Tier Simulator */}
        <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 px-2">
            {isAr ? 'محاكاة التدرج:' : 'Simulate Tier:'}
          </span>
          <button
            onClick={() => handleSetAlertTier('green')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              alertTier === 'green' ? 'bg-emerald-500 text-slate-950 shadow-md font-black' : 'bg-slate-900 text-emerald-400 hover:bg-slate-800'
            }`}
          >
            {isAr ? '1. أخضر (آمن)' : '1. Green'}
          </button>
          <button
            onClick={() => handleSetAlertTier('yellow')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              alertTier === 'yellow' ? 'bg-amber-500 text-slate-950 shadow-md font-black' : 'bg-slate-900 text-amber-400 hover:bg-slate-800'
            }`}
          >
            {isAr ? '2. أصفر (تحذير)' : '2. Yellow'}
          </button>
          <button
            onClick={() => handleSetAlertTier('red')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              alertTier === 'red' ? 'bg-rose-600 text-white shadow-md font-black animate-pulse' : 'bg-slate-900 text-rose-400 hover:bg-slate-800'
            }`}
          >
            {isAr ? '3. أحمر (إنذار)' : '3. Red'}
          </button>
        </div>
      </div>

      {/* Dynamic Adaptive Smart Shortcuts Row */}
      <SmartShortcutsRow
        language={language}
        vitals={vitals}
        patientProfile={patientProfile}
        waterIntakeMl={waterIntakeMl}
        onAddWater={handleAddWater}
        onOpenBreathingOverlay={onOpenBreathingOverlay}
        onNavigateTab={(tab) => onNavigateTab && onNavigateTab(tab)}
        onOpenSOSModal={onOpenSOSModal}
        onRecalibrateBudget={handleRecalibrateMorningBudget}
        onTriggerSpeech={onTriggerSpeech}
      />

      {/* Morning Charge Budget & Sleep Shield Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Morning Charge Budget Card (65% Budget) */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sun className="w-5 h-5 text-amber-400 animate-spin-slow" />
              <div>
                <h3 className="text-sm font-black text-white">
                  {isAr ? 'خوارزمية شحن الصباح (Morning Charge Budget)' : 'Morning Charge Budget Algorithm'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'معايرة طاقة اليوم المستهدفة عند الاستيقاظ (65%)' : 'Target daily readiness calibration upon waking'}
                </p>
              </div>
            </div>

            <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-amber-950 text-amber-300 border border-amber-800 font-bold">
              65% BUDGET
            </span>
          </div>

          <div className="flex items-center justify-between bg-slate-950 p-4 rounded-2xl border border-slate-800">
            <div>
              <span className="text-xs text-slate-400 block">{isAr ? 'ميزانية اليوم المقترحة:' : 'Target Daily Energy Budget:'}</span>
              <span className="text-3xl font-black font-mono text-amber-400">{morningBudgetPercent}%</span>
            </div>
            <button
              onClick={handleRecalibrateMorningBudget}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-colors shadow-md flex items-center gap-1.5"
            >
              <Zap className="w-4 h-4" />
              <span>{isAr ? 'إعادة المعايرة لـ 65%' : 'Recalibrate 65%'}</span>
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            {isAr
              ? 'تعتمد الخوارزمية على حجز 35% من طاقة الجسم كاحتياطي استعادة خلوي حرج، وتوزيع 65% فقط للجدول والجهد اليومي لمنع الإرهاق التراكمي.'
              : 'Reserves 35% cellular recovery buffer and caps active effort budget at 65% to prevent burnout.'}
          </p>
        </div>

        {/* Sleep Shield Engine & Late Night Warning */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Moon className="w-5 h-5 text-indigo-400" />
              <div>
                <h3 className="text-sm font-black text-white">
                  {isAr ? 'محرك النوم والوقاية من السهر (Sleep Shield Engine)' : 'Sleep Shield Engine (7-8 Hours Goal)'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'متابعة جودة وساعات النوم وتنبيهات السهر المتدرجة' : 'Tracks sleep hours (7-8h) and graduated late-night alerts'}
                </p>
              </div>
            </div>

            <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold">
              PATENT CLAIM-12
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-mono">{isAr ? 'ساعات النوم' : 'Sleep Hours'}</span>
              <p className="text-2xl font-black font-mono text-indigo-400">{sleepHours} <span className="text-xs">ساعة</span></p>
            </div>
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-400 uppercase font-mono">{isAr ? 'مؤشر التعافي' : 'Recovery Score'}</span>
              <p className="text-2xl font-black font-mono text-emerald-400">{sleepScore}%</p>
            </div>
          </div>

          {/* Late-Night Alert Stage Simulator */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-mono block">{isAr ? 'وضع السهر الوقائي خارج البيت:' : 'Late Night Stay-Out Shield:'}</span>
              <span className={`text-xs font-bold ${
                lateNightWarningStage === 0 ? 'text-emerald-400' :
                lateNightWarningStage === 1 ? 'text-amber-400' :
                lateNightWarningStage === 2 ? 'text-orange-400' : 'text-rose-500 animate-pulse'
              }`}>
                {lateNightWarningStage === 0 && (isAr ? 'آمن - بالمنزل' : 'Safe / Indoors')}
                {lateNightWarningStage === 1 && (isAr ? 'مرحلة 1: تنبيه السهر 11 مساءً' : 'Stage 1: 11 PM Alert')}
                {lateNightWarningStage === 2 && (isAr ? 'مرحلة 2: خفض ميزانية الغد 30%' : 'Stage 2: -30% Tomorrow Budget')}
                {lateNightWarningStage === 3 && (isAr ? 'مرحلة 3: إنذار الأهل بالبيت!' : 'Stage 3: House Resident Alert!')}
              </span>
            </div>

            <button
              onClick={handleSimulateLateNightStayOut}
              className="px-3 py-1.5 rounded-xl bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-xs font-bold transition-colors"
            >
              {isAr ? 'اختبار السهر' : 'Test Stay-Out Alert'}
            </button>
          </div>
        </div>

      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Readiness Meter Gauge */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center text-center space-y-6 relative overflow-hidden">
          <div className="absolute top-4 left-4 text-[10px] font-mono text-cyan-400 font-bold bg-cyan-950/60 px-2.5 py-1 rounded-full border border-cyan-800">
            CLAIM-17 (Body Energy)
          </div>

          <div className="relative w-48 h-48 flex items-center justify-center mt-4">
            {/* Outer Circular Glow */}
            <div className={`absolute inset-0 rounded-full border-8 border-slate-800 ${
              alertTier === 'green' ? 'border-t-emerald-500 text-emerald-400' :
              alertTier === 'yellow' ? 'border-t-amber-500 text-amber-400' : 'border-t-rose-600 text-rose-500'
            } animate-spin-slow`}></div>

            <div className="flex flex-col items-center justify-center space-y-1">
              <Zap className={`w-8 h-8 ${
                alertTier === 'green' ? 'text-emerald-400' : alertTier === 'yellow' ? 'text-amber-400' : 'text-rose-500 animate-bounce'
              }`} />
              <span className="text-4xl font-black text-white font-mono">{vitals.bodyEnergy}%</span>
              <span className="text-xs font-bold text-slate-400">
                {isAr ? 'جاهزية الجسم الحالية' : 'Body Readiness Score'}
              </span>
            </div>
          </div>

          {/* Alert Status Card */}
          <div className={`w-full p-4 rounded-2xl border text-right space-y-1 transition-all ${
            alertTier === 'green' ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300' :
            alertTier === 'yellow' ? 'bg-amber-950/40 border-amber-800 text-amber-300' :
            'bg-rose-950/60 border-rose-600 text-rose-200 animate-pulse'
          }`}>
            <div className="flex items-center justify-between font-bold text-xs">
              <span className="flex items-center gap-1.5">
                {alertTier === 'green' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                {alertTier === 'yellow' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                {alertTier === 'red' && <ShieldAlert className="w-4 h-4 text-rose-400" />}
                <span>
                  {alertTier === 'green' && (isAr ? 'المستوى 1: ممتاز ومترابط حيويّاً' : 'Tier 1: Excellent Readiness')}
                  {alertTier === 'yellow' && (isAr ? 'المستوى 2: إجهاد متوسط يتطلب الراحة' : 'Tier 2: Moderate Fatigue Alert')}
                  {alertTier === 'red' && (isAr ? 'المستوى 3: إنذار طارئ للتدخل الفوري' : 'Tier 3: Critical Emergency Alert')}
                </span>
              </span>
              <span className="font-mono text-[10px] uppercase">{alertTier}</span>
            </div>
            <p className="text-[11px] opacity-90 leading-relaxed">
              {alertTier === 'green' && (isAr ? 'الوظائف الحيوية في نطاق الأمان والتوازن الكامل مع النوم والأنشطة.' : 'All vital routines balanced with sleep and activity logs.')}
              {alertTier === 'yellow' && (isAr ? 'تراكم إجهاد عضلي وارتفاع طفيف في HRV. يوصى بالحد من الحركة المكثفة.' : 'Accumulated strain detected. Light activity recommended.')}
              {alertTier === 'red' && (isAr ? 'تفعيل بروتوكول Fail-Safe (Claim-08) لحفظ طاقة الجسم وتنشيط الاستغاثة!' : 'Fail-Safe Protocol (Claim-08) engaged to preserve energy!')}
            </p>

            {onOpenBreathingOverlay && (
              <button
                onClick={() =>
                  onOpenBreathingOverlay(
                    alertTier === 'red'
                      ? (isAr ? 'إنذار مرتفع للطاقة وتناغم القلب — خفّض النبض عبر التنفس 4-7-8' : 'High Energy Stress Alert — Lower HR via 4-7-8 Breathwork')
                      : (isAr ? 'جلسة تنظيم النفس 4-7-8 لخفض التوتر وإعادة توازن النبض' : '4-7-8 Breathing session to lower stress and regulate pulse')
                  )
                }
                className="w-full mt-2 py-2 px-3 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm"
              >
                <span>🫁</span>
                <span>{isAr ? 'بدء تمرين التنفس 4-7-8 لخفض التوتر' : 'Start 4-7-8 Breathing Exercise'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Center: Posture & Biomechanics (Patent 4 & 5) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Posture & Vertebral Structural Adaptation Card */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold">
                  🦴
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    {isAr ? 'نظام الرصد القوامي والعمود الفقري (Claim-04 & Claim-05)' : 'Posture & Spine Monitoring System'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr ? 'رصد زوايا انحناء الرقبة وملاءمة القوام أثناء العمل والقيادة' : 'Neck inclination & vertebral posture alignment'}
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold">
                BIOMECHANICS
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Neck Angle */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isAr ? 'انحناء الرقبة (Neck Angle)' : 'Neck Inclination'}</span>
                  <span className={`font-mono font-bold ${vitals.postureNeckAngle > 20 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {vitals.postureNeckAngle}°
                  </span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${vitals.postureNeckAngle > 20 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                    style={{ width: `${Math.min(100, (vitals.postureNeckAngle / 40) * 100)}%` }}
                  ></div>
                </div>
                <div className="text-[10px] text-slate-500">
                  {vitals.postureNeckAngle > 20
                    ? (isAr ? 'تنبيه: انحناء حاد يضغط الفقرات العنقية' : 'Warning: High cervical pressure')
                    : (isAr ? 'وضعية سليمة ومريحة للفقرات' : 'Healthy cervical spinal posture')}
                </div>
              </div>

              {/* Spine Alignment */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">{isAr ? 'مؤشر استقامة الفقرات (Spine Alignment)' : 'Spine Alignment Score'}</span>
                  <span className="font-mono font-bold text-cyan-400">{vitals.spineAlignmentScore}%</span>
                </div>
                <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-cyan-400 h-full rounded-full transition-all"
                    style={{ width: `${vitals.spineAlignmentScore}%` }}
                  ></div>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'حدود الأمان الميكانيكية للعمود الفقري مفعّلة' : 'Mechanical vertebral safety threshold active'}
                </div>
              </div>
            </div>

            {/* Correct Posture Audio Button */}
            <button
              onClick={() => {
                onUpdateVitals({ postureNeckAngle: 11, spineAlignmentScore: 94 });
                onTriggerSpeech(isAr ? 'تم تعديل واستقامة القوام والعمود الفقري بنجاح.' : 'Posture corrected and spine aligned.');
              }}
              className="w-full py-2.5 rounded-xl bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-xs font-bold transition-colors flex items-center justify-center gap-2"
            >
              <Volume2 className="w-4 h-4 text-indigo-400" />
              <span>{isAr ? 'تأكيد تعديل وضعية الجلوس والقوام بالصوت' : 'Confirm Audio Posture Correction'}</span>
            </button>
          </div>

          {/* Fail-Safe & Emergency Buffer Battery Reserve (Patent 8 & 16) */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <BatteryCharging className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-sm font-black text-white">
                    {isAr ? 'احتياطي الطاقة للطوارئ (Claim-08 & Claim-16 Fail-Safe)' : 'Emergency Battery Buffer & Fail-Safe'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isAr ? 'حجز طاقة إجباري لا يتجاوزه الجهاز، مخصص للاتصال والتصعيد' : 'Mandatory battery energy reserve strictly held for emergency rescue'}
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                15% LOCKED RESERVE
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-300">{isAr ? 'الذاكرة المؤقتة لطاقة الطوارئ:' : 'Locked Emergency Buffer:'}</span>
                <span className="font-mono text-emerald-400">15% (3.8 Hours SOS Runtime)</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-3 p-0.5 border border-slate-800 flex">
                <div className="w-[85%] bg-slate-700 h-full rounded-l-full"></div>
                <div className="w-[15%] bg-emerald-500 h-full rounded-r-full animate-pulse" title="Emergency Buffer Reserve"></div>
              </div>
              <div className="text-[11px] text-slate-400 pt-1">
                {isAr
                  ? 'حتى في حال انخفاض بطارية السوار لـ 0% للميزات العامة، يظل هذا الاحتياطي نشطاً طوارئياً لإرسال إحداثيات GPS والإشعارات.'
                  : 'Even if smartwatch reaches 0% normal battery, this 15% reserve guarantees SOS broadcast & GPS.'}
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Daily Hydration & Water Intake Widget */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-cyan-900/60 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold shrink-0">
              <Droplets className="w-6 h-6 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 text-[10px] font-mono font-bold">
                  HYDRATION MONITOR
                </span>
                <span className="text-[10px] text-cyan-400 font-mono font-bold">BODY BATTERY CHARGE</span>
              </div>
              <h3 className="text-base font-black text-white mt-0.5">
                {isAr ? 'تتبع شرب الماء اليومي (Daily Water Intake & Hydration Tracker)' : 'Daily Hydration & Water Intake Tracker'}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-slate-950 text-cyan-400 border border-slate-800 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>{isAr ? 'تأثير الطاقة: +3% لكل 250مل' : 'Energy Impact: +3% per 250ml'}</span>
            </span>

            <button
              onClick={handleResetWater}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
              title={isAr ? 'إعادة ضبط الترتيب' : 'Reset Water Log'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Hydration Progress & Meter */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          
          <div className="md:col-span-2 space-y-2 p-4 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-bold flex items-center gap-2">
                <span>{isAr ? 'المأخوذ اليومي / الهدف الموصى به:' : 'Today Intake / Target Daily Intake:'}</span>
                {waterIntakeMl >= waterGoalMl && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 animate-bounce">
                    🎉 {isAr ? 'تم تحقيق الهدف اليومي!' : 'Goal Achieved!'}
                  </span>
                )}
              </span>
              <span className="font-mono font-black text-cyan-400 text-sm">
                {waterIntakeMl} ml / {waterGoalMl} ml ({Math.min(100, Math.round((waterIntakeMl / waterGoalMl) * 100))}%)
              </span>
            </div>

            {/* Visual Liquid Progress Bar */}
            <div className="w-full bg-slate-900 rounded-full h-4 overflow-hidden border border-slate-800 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-600 via-cyan-400 to-emerald-400 transition-all duration-500 flex items-center justify-end pr-2 text-[10px] font-mono font-black text-slate-950"
                style={{ width: `${Math.min(100, (waterIntakeMl / waterGoalMl) * 100)}%` }}
              >
                {Math.min(100, Math.round((waterIntakeMl / waterGoalMl) * 100))}%
              </div>
            </div>

            <p className="text-[11px] text-slate-400 pt-1">
              {isAr
                ? 'الحفاظ على رطوبة الجسم يمنع الجفاف، ويزيد من مرونة مؤشر HRV ويرفع طاقة الجسم الحيوية.'
                : 'Optimal hydration prevents cellular fatigue, improves HRV index, and maintains baseline body battery.'}
            </p>
          </div>

          {/* Quick-Add Buttons */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5">
            <button
              onClick={() => handleAddWater(250)}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md transition-all group"
            >
              <Plus className="w-4 h-4 text-cyan-200 group-hover:scale-125 transition-transform" />
              <span>{isAr ? '+250 مل (كوب ماء)' : '+250ml Glass (+3% Energy)'}</span>
            </button>

            <button
              onClick={() => handleAddWater(500)}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md transition-all group"
            >
              <Plus className="w-4 h-4 text-indigo-200 group-hover:scale-125 transition-transform" />
              <span>{isAr ? '+500 مل (قارورة ماء)' : '+500ml Bottle (+6% Energy)'}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Circadian Rhythm & Natural Light Exposure Tracker */}
      <CircadianRhythmWidget
        language={language}
        onTriggerSpeech={onTriggerSpeech}
      />

      {/* Daily Schedule Timeline & Routine Manager */}
      <DailyScheduleManager
        language={language}
        patientProfile={patientProfile}
        onTriggerSpeech={onTriggerSpeech}
        onUpdateBodyEnergy={(newEnergy) => onUpdateVitals({ bodyEnergy: newEnergy })}
      />

      {/* Recharts Weekly Trend Analysis Chart with Daily Mood Correlation */}
      <WeeklyTrendChart
        language={language}
        vitals={vitals}
        onTriggerSpeech={onTriggerSpeech}
      />

      {/* 30-Day Rolling Vital Baseline Anomaly Monitor */}
      <VitalAnomalyMonitor
        language={language}
        vitals={vitals}
        onTriggerSpeech={onTriggerSpeech}
        onUpdateVitals={onUpdateVitals}
      />

      {/* Sleep Guard Cut-Off, Body Battery Dynamic Drain & Recovery Trend AI */}
      <SleepGuardAndRecoveryDashboard
        language={language}
        vitals={vitals}
        patientProfile={patientProfile}
        onTriggerSpeech={onTriggerSpeech}
        onUpdateVitals={onUpdateVitals}
      />

    </div>
  );
};
