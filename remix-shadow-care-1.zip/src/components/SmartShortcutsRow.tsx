import React from 'react';
import { motion } from 'motion/react';
import {
  Wind,
  Pill,
  Droplets,
  Zap,
  Activity,
  AlertTriangle,
  Sparkles,
  ShieldAlert,
  Sun,
  Flame,
  CheckCircle2,
  ChevronRight,
  Compass,
  HeartPulse,
} from 'lucide-react';
import { CurrentVitals, Language, PatientProfile } from '../types';

interface SmartShortcutItem {
  id: string;
  titleAr: string;
  titleEn: string;
  badgeAr?: string;
  badgeEn?: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
  borderColor: string;
  isHighPriority?: boolean;
  action: () => void;
}

interface SmartShortcutsRowProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  waterIntakeMl: number;
  onAddWater: (amountMl: number) => void;
  onOpenBreathingOverlay?: (reason?: string) => void;
  onNavigateTab: (tabId: string) => void;
  onOpenSOSModal: () => void;
  onRecalibrateBudget: () => void;
  onTriggerSpeech: (text: string) => void;
}

export const SmartShortcutsRow: React.FC<SmartShortcutsRowProps> = ({
  language,
  vitals,
  patientProfile,
  waterIntakeMl,
  onAddWater,
  onOpenBreathingOverlay,
  onNavigateTab,
  onOpenSOSModal,
  onRecalibrateBudget,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  // Dynamic state checks
  const isHighStress = vitals.stressLevel > 55 || vitals.heartRate > 100;
  const isLowWater = waterIntakeMl < 1500;
  const isLowEnergy = vitals.bodyEnergy < 45;
  const isHighPostureAngle = vitals.postureNeckAngle > 20;

  // Build dynamic smart shortcuts array ordered by relevance/context
  const shortcuts: SmartShortcutItem[] = [];

  // Priority 1: High Stress / HR Spike -> Quick Breathing Exercise
  if (isHighStress) {
    shortcuts.push({
      id: 'breathing',
      titleAr: 'بدء تمرين التنفس 4-7-8 لتخفيض التوتر',
      titleEn: 'Start 4-7-8 Breathing (High Stress)',
      badgeAr: 'موصى به للتوتر',
      badgeEn: 'RECOMMENDED FOR STRESS',
      icon: Wind,
      color: 'text-amber-400',
      bgColor: 'bg-amber-950/90',
      borderColor: 'border-amber-500',
      isHighPriority: true,
      action: () => {
        if (onOpenBreathingOverlay) {
          onOpenBreathingOverlay(
            isAr
              ? `تنبيه التوتر المرتفع (${vitals.stressLevel}%) - بدء جلسة التنفس الموجه`
              : `High stress level detected (${vitals.stressLevel}%) - Initiating guided breathing`
          );
        } else {
          onNavigateTab('heart');
        }
      },
    });
  }

  // Priority 2: Low Water -> Quick Hydrate Button
  if (isLowWater) {
    shortcuts.push({
      id: 'hydrate',
      titleAr: 'تسجيل شرب ماء (+250 مل)',
      titleEn: 'Quick Hydrate (+250ml Water)',
      badgeAr: 'نقص الترطيب',
      badgeEn: 'HYDRATION NEEDED',
      icon: Droplets,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-950/80',
      borderColor: 'border-cyan-600',
      isHighPriority: isLowWater,
      action: () => {
        onAddWater(250);
      },
    });
  }

  // Priority 3: Low Energy -> Recalibrate Energy Budget
  if (isLowEnergy) {
    shortcuts.push({
      id: 'energy',
      titleAr: 'إعادة معايرة ميزانية الطاقة (65%)',
      titleEn: 'Recalibrate Energy Budget (65%)',
      badgeAr: 'طاقة منخفضة',
      badgeEn: 'LOW BODY BATTERY',
      icon: Zap,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-950/80',
      borderColor: 'border-emerald-600',
      isHighPriority: isLowEnergy,
      action: () => {
        onRecalibrateBudget();
      },
    });
  }

  // Priority 4: Quick Log Medication (Always highly accessible)
  shortcuts.push({
    id: 'medication',
    titleAr: 'تسجيل الدواء السريع',
    titleEn: 'Quick Log Medication',
    badgeAr: 'الجدول الزمني',
    badgeEn: 'SAFE-MED',
    icon: Pill,
    color: 'text-purple-400',
    bgColor: 'bg-purple-950/60',
    borderColor: 'border-purple-800',
    action: () => {
      onNavigateTab('medication');
      onTriggerSpeech(
        isAr ? 'الانتقال إلى شاشة إدارة واستبصار الأدوية Safe-Med.' : 'Navigating to Safe-Med Medication Management.'
      );
    },
  });

  // Priority 5: Posture Correction if neck angle high
  if (isHighPostureAngle) {
    shortcuts.push({
      id: 'posture',
      titleAr: 'فحص انحناء الرقبة وتصحيح الجلسة',
      titleEn: 'Posture & Neck Angle Check',
      badgeAr: 'انحناء 24°',
      badgeEn: 'POSTURE ALERT',
      icon: AlertTriangle,
      color: 'text-rose-400',
      bgColor: 'bg-rose-950/80',
      borderColor: 'border-rose-600',
      action: () => {
        onNavigateTab('heart');
        onTriggerSpeech(
          isAr
            ? `انحناء الرقبة ${vitals.postureNeckAngle} درجة. يرجى رفع الرأس واستقامة الظهر.`
            : `Neck tilt angle ${vitals.postureNeckAngle} degrees. Align back upright.`
        );
      },
    });
  }

  // Standard shortcuts: Eco Sports Radar & Circadian Light
  shortcuts.push({
    id: 'sports',
    titleAr: 'رادار الرياضة والبيئة',
    titleEn: 'Eco-Sports & Thermal Radar',
    badgeAr: 'مؤشر الحرارة',
    badgeEn: 'THERMAL INDEX',
    icon: Compass,
    color: 'text-teal-400',
    bgColor: 'bg-teal-950/60',
    borderColor: 'border-teal-800',
    action: () => {
      onNavigateTab('sports');
    },
  });

  shortcuts.push({
    id: 'sos',
    titleAr: 'بطاقة الطوارئ الطبية SOS',
    titleEn: 'Medical Emergency SOS Pass',
    badgeAr: 'طوارئ',
    badgeEn: 'EMERGENCY',
    icon: ShieldAlert,
    color: 'text-red-400',
    bgColor: 'bg-red-950/80',
    borderColor: 'border-red-600',
    action: () => {
      onOpenSOSModal();
    },
  });

  return (
    <div className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl space-y-3 relative overflow-hidden">
      {/* Top Title & Dynamic Context Indicator */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          </div>
          <div>
            <h4 className="text-xs font-black text-white flex items-center gap-1.5">
              <span>{isAr ? 'اختصارات سريعة ذكية (تتكيف مع حالتك)' : 'Smart Adaptive Shortcuts'}</span>
            </h4>
            <p className="text-[10px] text-slate-400">
              {isAr ? 'تتغير الخيارات تلقائياً استناداً لمؤشراتك الحيوية والتوتر' : 'Shortcuts dynamically update based on real-time vitals'}
            </p>
          </div>
        </div>

        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-cyan-400 border border-slate-800 font-bold">
          {shortcuts.length} {isAr ? 'اختصارات نشطة' : 'ACTIVE'}
        </span>
      </div>

      {/* Horizontal Scrollable Shortcuts Container */}
      <div className="flex items-center gap-3 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
        {shortcuts.map((sc) => {
          const IconComp = sc.icon;
          return (
            <motion.button
              key={sc.id}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.96 }}
              onClick={sc.action}
              className={`shrink-0 p-3 rounded-2xl ${sc.bgColor} border ${sc.borderColor} backdrop-blur-md flex items-center gap-3 transition-all text-left shadow-md group relative overflow-hidden`}
            >
              {sc.isHighPriority && (
                <div className="absolute top-0 right-0 left-0 h-0.5 bg-gradient-to-r from-amber-500 via-rose-500 to-amber-500 animate-pulse" />
              )}

              <div
                className={`w-9 h-9 rounded-xl bg-slate-950/80 ${sc.color} border border-slate-800 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform`}
              >
                <IconComp className="w-5 h-5" />
              </div>

              <div>
                {sc.badgeAr && (
                  <span
                    className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${sc.color} bg-slate-950/70 border border-slate-800 block w-fit mb-0.5`}
                  >
                    {isAr ? sc.badgeAr : sc.badgeEn}
                  </span>
                )}
                <p className="text-xs font-bold text-white whitespace-nowrap">
                  {isAr ? sc.titleAr : sc.titleEn}
                </p>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-0.5 transition-all shrink-0 ltr:rotate-0 rtl:rotate-180" />
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
