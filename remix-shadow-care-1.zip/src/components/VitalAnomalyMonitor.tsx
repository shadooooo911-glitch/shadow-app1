import React, { useState, useEffect } from 'react';
import { AlertTriangle, Activity, Bell, CheckCircle2, ShieldAlert, Sparkles, TrendingDown, TrendingUp, RefreshCw, Zap, Sliders, Volume2 } from 'lucide-react';
import { CurrentVitals, Language } from '../types';

interface VitalAnomalyMonitorProps {
  language: Language;
  vitals: CurrentVitals;
  onTriggerSpeech: (text: string) => void;
  onUpdateVitals?: (vitals: Partial<CurrentVitals>) => void;
}

export const VitalAnomalyMonitor: React.FC<VitalAnomalyMonitorProps> = ({
  language,
  vitals,
  onTriggerSpeech,
  onUpdateVitals,
}) => {
  const isAr = language === 'ar';

  // 30-Day Rolling Averages Baseline (Default: 63 bpm Resting HR, 72 ms HRV)
  const [baselineRHR, setBaselineRHR] = useState<number>(63);
  const [baselineHRV, setBaselineHRV] = useState<number>(72);
  const [sensitivityPercent, setSensitivityPercent] = useState<number>(12); // Alert sensitivity threshold %
  const [lastNotifiedTime, setLastNotifiedTime] = useState<string | null>(null);

  // Compute live deviations
  const currentRHR = vitals.heartRate;
  const currentHRV = vitals.hrvIndex;

  const rhrDiffBpm = currentRHR - baselineRHR;
  const rhrDeviationPercent = Math.round((rhrDiffBpm / baselineRHR) * 100);

  const hrvDiffMs = currentHRV - baselineHRV;
  const hrvDeviationPercent = Math.round((hrvDiffMs / baselineHRV) * 100);

  // Determine Anomaly Status
  const isRhrElevated = rhrDeviationPercent >= sensitivityPercent;
  const isHrvSuppressed = hrvDeviationPercent <= -sensitivityPercent;

  const hasAnomaly = isRhrElevated || isHrvSuppressed;
  const isSevereAnomaly = (isRhrElevated && isHrvSuppressed) || rhrDeviationPercent > 25 || hrvDeviationPercent < -30;

  // Auto-notify voice alert when anomaly detected
  useEffect(() => {
    if (hasAnomaly) {
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      if (lastNotifiedTime !== nowStr) {
        setLastNotifiedTime(nowStr);

        let msg = '';
        if (isAr) {
          msg = `تنبيه انحراف الحيوية: معدل نبض القلب ${currentRHR} (انحراف +${rhrDeviationPercent}% عن المعدل التراكمي لـ 30 يوماً). مؤشر HRV ${currentHRV}ms (${hrvDeviationPercent}%). ينصح بتخفيف المجهود.`;
        } else {
          msg = `Vital Deviation Alert: Resting HR ${currentRHR} bpm (${rhrDeviationPercent}% vs 30-day baseline). HRV is ${currentHRV} ms (${hrvDeviationPercent}%). Recovery caution recommended.`;
        }
        onTriggerSpeech(msg);
      }
    }
  }, [hasAnomaly, currentRHR, currentHRV]);

  // Preset Scenario Testing
  const handleApplyScenario = (preset: 'normal' | 'strain' | 'illness' | 'optimal') => {
    if (!onUpdateVitals) return;

    if (preset === 'normal') {
      onUpdateVitals({ heartRate: 64, hrvIndex: 70, bodyEnergy: 85 });
      const msg = isAr ? 'تم تطبيق نمط الحيوية الطبيعي المستقر.' : 'Applied normal baseline vital scenario.';
      onTriggerSpeech(msg);
    } else if (preset === 'strain') {
      onUpdateVitals({ heartRate: 82, hrvIndex: 48, bodyEnergy: 52 });
      const msg = isAr ? 'تم تطبيق نمط الإجهاد والتعب البدني (+30% نبض، -33% HRV).' : 'Applied heavy physical strain scenario (+30% RHR, -33% HRV).';
      onTriggerSpeech(msg);
    } else if (preset === 'illness') {
      onUpdateVitals({ heartRate: 94, hrvIndex: 38, bodyEnergy: 34 });
      const msg = isAr ? 'تحذير: تم تطبيق نمط الانحراف الحاد المشابه لأعراض العدوى أو الحمى.' : 'Warning: Applied acute deviation scenario (Infection / Fever pattern).';
      onTriggerSpeech(msg);
    } else if (preset === 'optimal') {
      onUpdateVitals({ heartRate: 58, hrvIndex: 88, bodyEnergy: 98 });
      const msg = isAr ? 'تم تطبيق نمط الاستشفاء العالي والنوم العميق.' : 'Applied optimal deep sleep recovery scenario.';
      onTriggerSpeech(msg);
    }
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-amber-900/50 space-y-5 shadow-2xl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold shrink-0">
            <Bell className="w-6 h-6 text-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-mono font-bold">
                PATENT CLAIM-09 ROLLING BASELINE MONITOR
              </span>
              <span className="text-[10px] text-amber-400 font-mono font-bold">30-DAY ANOMALY DETECTOR</span>
            </div>
            <h3 className="text-base font-black text-white mt-0.5">
              {isAr ? 'مراقب الانحراف المباشر عن المعدل التراكمي (30-Day Rolling Vital Anomaly Monitor)' : '30-Day Rolling Vital Baseline Anomaly Monitor'}
            </h3>
          </div>
        </div>

        {/* Anomaly Badge */}
        <div className="flex items-center gap-2">
          <span className={`text-xs font-mono font-bold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 ${
            isSevereAnomaly
              ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse'
              : hasAnomaly
              ? 'bg-amber-950 text-amber-300 border-amber-800'
              : 'bg-emerald-950 text-emerald-300 border-emerald-800'
          }`}>
            {hasAnomaly ? <AlertTriangle className="w-4 h-4 text-amber-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            <span>
              {isSevereAnomaly
                ? (isAr ? 'انحراف حاد عن المعدل' : 'Severe Anomaly Detected')
                : hasAnomaly
                ? (isAr ? 'انحراف ملحوظ' : 'Baseline Deviation')
                : (isAr ? 'مستقر وضمن المعدل الطبيعي' : 'Normal 30-Day Range')}
            </span>
          </span>
        </div>
      </div>

      <p className="text-xs text-slate-400">
        {isAr
          ? 'طبقة الذكاء الاصطناعي لمراقبة السجلات الحيوية: تقوم بتحليل معدل نبض القلب أثناء الراحة (Resting HR) ومؤشر تقلب النبض (HRV) وإخطارك فوراً عند ظهور أي انحراف إحصائي عن المتوسط التراكمي لـ 30 يوماً.'
          : 'AI telemetry logic layer that monitors resting heart rate and HRV against your 30-day rolling baseline to trigger proactive alerts upon statistical deviation.'}
      </p>

      {/* Live Metrics Comparison Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Card 1: Resting Heart Rate (RHR) vs 30-Day Avg */}
        <div className={`p-4 rounded-2xl border transition-all ${
          isRhrElevated ? 'bg-rose-950/40 border-rose-800/80' : 'bg-slate-950 border-slate-800'
        }`}>
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-rose-400" />
              <span className="text-xs font-bold text-white">
                {isAr ? 'نبض الراحة (RHR)' : 'Resting Heart Rate'}
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              30D AVG: <strong className="text-slate-200">{baselineRHR} bpm</strong>
            </span>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-mono font-black text-white">{currentRHR}</span>
                <span className="text-xs text-slate-400 font-mono">bpm</span>
              </div>
              <span className="text-[11px] text-slate-400 block mt-0.5">
                {isAr ? 'القراءة الحالية' : 'Current Value'}
              </span>
            </div>

            <div className="text-right">
              <div className={`flex items-center gap-1 font-mono font-black text-sm ${
                rhrDeviationPercent > 0 ? 'text-rose-400' : 'text-emerald-400'
              }`}>
                {rhrDeviationPercent > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                <span>{rhrDeviationPercent > 0 ? `+${rhrDeviationPercent}%` : `${rhrDeviationPercent}%`}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono block">
                {rhrDiffBpm >= 0 ? `+${rhrDiffBpm} bpm` : `${rhrDiffBpm} bpm`}
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Heart Rate Variability (HRV) vs 30-Day Avg */}
        <div className={`p-4 rounded-2xl border transition-all ${
          isHrvSuppressed ? 'bg-amber-950/40 border-amber-800/80' : 'bg-slate-950 border-slate-800'
        }`}>
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-white">
                {isAr ? 'تفاوت النبض (HRV Index)' : 'Heart Rate Variability'}
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              30D AVG: <strong className="text-slate-200">{baselineHRV} ms</strong>
            </span>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-mono font-black text-white">{currentHRV}</span>
                <span className="text-xs text-slate-400 font-mono">ms</span>
              </div>
              <span className="text-[11px] text-slate-400 block mt-0.5">
                {isAr ? 'القراءة الحالية' : 'Current Value'}
              </span>
            </div>

            <div className="text-right">
              <div className={`flex items-center gap-1 font-mono font-black text-sm ${
                hrvDeviationPercent < 0 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {hrvDeviationPercent < 0 ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
                <span>{hrvDeviationPercent > 0 ? `+${hrvDeviationPercent}%` : `${hrvDeviationPercent}%`}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono block">
                {hrvDiffMs >= 0 ? `+${hrvDiffMs} ms` : `${hrvDiffMs} ms`}
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Active Alert Banner if Anomaly Triggered */}
      {hasAnomaly && (
        <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-fadeIn ${
          isSevereAnomaly ? 'bg-rose-950/90 border-rose-500 text-rose-100 shadow-xl' : 'bg-amber-950/90 border-amber-500 text-amber-100 shadow-xl'
        }`}>
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5 text-amber-300" />
            <div>
              <span className="text-xs font-black block">
                {isAr ? 'تنبيه انحراف معدل الاستشفاء التراكمي:' : 'Rolling 30-Day Baseline Deviation Triggered:'}
              </span>
              <p className="text-[11px] opacity-90 mt-0.5 leading-relaxed">
                {isRhrElevated && isHrvSuppressed
                  ? (isAr
                      ? 'تم رصد ارتفاع في نبض الراحة (+ ' + rhrDeviationPercent + '%) مع انخفاض ملحوظ في مؤشر HRV (' + hrvDeviationPercent + '%). هذا يشير إلى احتمال وجود إجهاد بدني شديد، نقص نوم، أو بداية عدوى فيروسية.'
                      : `Simultaneous elevation in Resting HR (+${rhrDeviationPercent}%) and HRV suppression (${hrvDeviationPercent}%). Indicates high systemic strain, sleep debt, or impending illness.`)
                  : isRhrElevated
                  ? (isAr
                      ? 'نبض الراحة أعلى بـ ' + rhrDeviationPercent + '% من متوسط الـ 30 يوماً. ينصح بشرب الماء وتفادي المشروبات المنبهة.'
                      : `Resting HR is +${rhrDeviationPercent}% above your 30-day baseline. Stay hydrated and avoid intense physical exertion.`)
                  : (isAr
                      ? 'مؤشر HRV أقل بـ ' + Math.abs(hrvDeviationPercent) + '% من المعدل المعتاد. الجهاز العصبي في حالة توتر مرتفعة.'
                      : `HRV is ${hrvDeviationPercent}% below your 30-day baseline, indicating elevated sympathetic nervous tone.`)}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              const text = isAr
                ? `تحذير حيوي: الانحراف الحالي يمثل زيادة ${rhrDeviationPercent}% في النبض وانخفاض ${Math.abs(hrvDeviationPercent)}% في HRV مقارنة بمتوسط 30 يوماً.`
                : `Vital warning: Current deviation represents +${rhrDeviationPercent}% HR and ${hrvDeviationPercent}% HRV vs 30-day average.`;
              onTriggerSpeech(text);
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-900 text-white font-mono font-bold text-xs shrink-0 flex items-center gap-1.5 border border-slate-700"
          >
            <Volume2 className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'إعادة التنبيه الصوتي' : 'Replay Voice Alert'}</span>
          </button>
        </div>
      )}

      {/* Interactive Testing & Scenario Simulation Controls */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
          <span className="text-xs font-bold text-slate-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'اختبار محاكاة سيناريوهات انحراف القياسات:' : 'Simulate 30-Day Anomaly Scenarios:'}</span>
          </span>

          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
            <span>{isAr ? 'عتبة التنبيه:' : 'Alert Sensitivity:'}</span>
            <span className="text-amber-400 font-bold">±{sensitivityPercent}%</span>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => handleApplyScenario('normal')}
            className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-bold transition-all text-center"
          >
            {isAr ? '1. حالة مستقرة' : '1. Normal State'}
          </button>

          <button
            onClick={() => handleApplyScenario('strain')}
            className="py-2.5 px-3 rounded-xl bg-amber-950/60 hover:bg-amber-900/80 border border-amber-800/80 text-amber-300 text-xs font-bold transition-all text-center"
          >
            {isAr ? '2. إجهاد بدني' : '2. Heavy Strain'}
          </button>

          <button
            onClick={() => handleApplyScenario('illness')}
            className="py-2.5 px-3 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/80 text-rose-300 text-xs font-bold transition-all text-center"
          >
            {isAr ? '3. بداية عدوى/حمى' : '3. Infection Alert'}
          </button>

          <button
            onClick={() => handleApplyScenario('optimal')}
            className="py-2.5 px-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-800/80 text-emerald-300 text-xs font-bold transition-all text-center"
          >
            {isAr ? '4. نوم عميق وممتاز' : '4. Deep Recovery'}
          </button>
        </div>

        {/* Custom sensitivity slider */}
        <div className="pt-2 flex items-center justify-between gap-4 text-xs font-mono text-slate-400">
          <label className="shrink-0">{isAr ? 'حساسية مراقبة الانحراف:' : 'Deviation Sensitivity Threshold:'}</label>
          <input
            type="range"
            min="5"
            max="25"
            step="1"
            value={sensitivityPercent}
            onChange={(e) => setSensitivityPercent(Number(e.target.value))}
            className="w-full accent-amber-500 h-2 bg-slate-900 rounded-lg cursor-pointer"
          />
          <span className="font-bold text-amber-400 shrink-0">±{sensitivityPercent}%</span>
        </div>
      </div>

    </div>
  );
};
