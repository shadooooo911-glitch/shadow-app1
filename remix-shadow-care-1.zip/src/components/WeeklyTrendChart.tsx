import React, { useState } from 'react';
import { Activity, TrendingUp, Zap, HeartPulse, Smile, Frown, Meh, Sparkles, Brain, CheckCircle2, Volume2 } from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { CurrentVitals, Language } from '../types';

interface WeeklyTrendChartProps {
  language: Language;
  vitals: CurrentVitals;
  onTriggerSpeech?: (text: string) => void;
}

interface MoodOption {
  id: string;
  emoji: string;
  labelAr: string;
  labelEn: string;
  score: number; // 0 - 100 scale
  hrvImpactMs: number; // impact on HRV
  stressImpactPercent: number; // impact on stress
  color: string;
  bgSelected: string;
  borderSelected: string;
}

const MOOD_OPTIONS: MoodOption[] = [
  {
    id: 'peaceful',
    emoji: '🌟',
    labelAr: 'مرتاح ومستقر جداً',
    labelEn: 'Peaceful & Energized',
    score: 95,
    hrvImpactMs: +18,
    stressImpactPercent: -25,
    color: 'text-amber-400',
    bgSelected: 'bg-amber-950/90',
    borderSelected: 'border-amber-500',
  },
  {
    id: 'calm',
    emoji: '🌿',
    labelAr: 'هادئ ومتوازن',
    labelEn: 'Calm & Balanced',
    score: 80,
    hrvImpactMs: +10,
    stressImpactPercent: -15,
    color: 'text-emerald-400',
    bgSelected: 'bg-emerald-950/90',
    borderSelected: 'border-emerald-500',
  },
  {
    id: 'neutral',
    emoji: '😐',
    labelAr: 'اعتيادي / محايد',
    labelEn: 'Neutral / Steady',
    score: 60,
    hrvImpactMs: 0,
    stressImpactPercent: 0,
    color: 'text-cyan-400',
    bgSelected: 'bg-cyan-950/90',
    borderSelected: 'border-cyan-500',
  },
  {
    id: 'anxious',
    emoji: '⚡',
    labelAr: 'قلق / متوتر',
    labelEn: 'Anxious / Stressed',
    score: 35,
    hrvImpactMs: -12,
    stressImpactPercent: +25,
    color: 'text-rose-400',
    bgSelected: 'bg-rose-950/90',
    borderSelected: 'border-rose-500',
  },
  {
    id: 'exhausted',
    emoji: '🌧️',
    labelAr: 'مرهق / منخفض الطاقة',
    labelEn: 'Exhausted / Low',
    score: 20,
    hrvImpactMs: -20,
    stressImpactPercent: +40,
    color: 'text-purple-400',
    bgSelected: 'bg-purple-950/90',
    borderSelected: 'border-purple-500',
  },
];

export const WeeklyTrendChart: React.FC<WeeklyTrendChartProps> = ({
  language,
  vitals,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';

  // Selected Today's Mood state (defaults to 'calm' or 'peaceful')
  const [selectedMood, setSelectedMood] = useState<MoodOption>(MOOD_OPTIONS[1]);
  const [moodLoggedSuccess, setMoodLoggedSuccess] = useState<boolean>(false);

  // 7-day historical dataset including mood correlation
  const baseData = [
    { day: isAr ? 'الأحد' : 'Sun', heartRate: 68, bodyEnergy: 88, hrvMs: 72, moodScore: 85, moodEmoji: '🌿' },
    { day: isAr ? 'الإثنين' : 'Mon', heartRate: 74, bodyEnergy: 76, hrvMs: 64, moodScore: 70, moodEmoji: '😐' },
    { day: isAr ? 'الثلاثاء' : 'Tue', heartRate: 82, bodyEnergy: 62, hrvMs: 50, moodScore: 40, moodEmoji: '⚡' },
    { day: isAr ? 'الأربعاء' : 'Wed', heartRate: 71, bodyEnergy: 84, hrvMs: 70, moodScore: 80, moodEmoji: '🌿' },
    { day: isAr ? 'الخميس' : 'Thu', heartRate: 86, bodyEnergy: 58, hrvMs: 46, moodScore: 30, moodEmoji: '🌧️' },
    { day: isAr ? 'السبت' : 'Sat', heartRate: 67, bodyEnergy: 92, hrvMs: 78, moodScore: 95, moodEmoji: '🌟' },
    {
      day: isAr ? 'اليوم' : 'Today',
      heartRate: Math.round(vitals.heartRate + (selectedMood.score < 50 ? 6 : -4)),
      bodyEnergy: Math.min(100, Math.max(20, vitals.bodyEnergy + Math.round((selectedMood.score - 60) * 0.2))),
      hrvMs: Math.max(30, vitals.hrvIndex + selectedMood.hrvImpactMs),
      moodScore: selectedMood.score,
      moodEmoji: selectedMood.emoji,
      isToday: true,
    },
  ];

  const handleSelectMood = (mood: MoodOption) => {
    setSelectedMood(mood);
    setMoodLoggedSuccess(true);
    setTimeout(() => setMoodLoggedSuccess(false), 3000);

    const speechText = isAr
      ? `تم تسجيل المزاج اليومي: ${mood.labelAr}. أظهرت البيانات ارتباطاً كبيراً بين الحالة النفسية ومعدل HRV بإنحراف قدره ${mood.hrvImpactMs > 0 ? '+' : ''}${mood.hrvImpactMs} مللي ثانية.`
      : `Logged daily emotional state: ${mood.labelEn}. Correlated HRV response calculated at ${mood.hrvImpactMs > 0 ? '+' : ''}${mood.hrvImpactMs}ms impact on physical recovery.`;

    if (onTriggerSpeech) {
      onTriggerSpeech(speechText);
    }
  };

  // Custom Recharts Tooltip Component
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0]?.payload;
      return (
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl text-xs space-y-1.5 font-mono">
          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1">
            <span className="font-bold text-white">{label}</span>
            <span className="text-base">{dataPoint?.moodEmoji}</span>
          </div>
          {payload.map((entry: any, idx: number) => (
            <div key={idx} className="flex items-center justify-between gap-4">
              <span style={{ color: entry.color }} className="font-bold">
                {entry.name}:
              </span>
              <span className="font-black text-white">
                {entry.value}{' '}
                {entry.dataKey === 'heartRate'
                  ? 'bpm'
                  : entry.dataKey === 'hrvMs'
                  ? 'ms'
                  : '%'}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5 shadow-xl relative overflow-hidden">
      {/* Top Title & Section Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-950 text-indigo-400 border border-indigo-800 flex items-center justify-center font-bold shrink-0">
            <Brain className="w-6 h-6 text-purple-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 text-[10px] font-mono font-bold">
                PSYCHO-NEURO-VITAL CORRELATION
              </span>
              <span className="text-[10px] text-cyan-400 font-mono font-bold">EMOTION & HRV LINK</span>
            </div>
            <h3 className="text-base font-black text-white mt-0.5">
              {isAr
                ? 'سجل المزاج اليومي والارتباط مع استشفاء HRV'
                : 'Daily Mood Tracker & HRV Recovery Correlation'}
            </h3>
          </div>
        </div>

        {/* Dynamic Vitals Summary Chips */}
        <div className="flex items-center gap-2 text-xs font-mono font-bold">
          <div className="px-3 py-1.5 rounded-xl bg-purple-950/80 text-purple-300 border border-purple-800/80 flex items-center gap-1.5">
            <HeartPulse className="w-4 h-4 text-purple-400" />
            <span>
              HRV: {vitals.hrvIndex + selectedMood.hrvImpactMs} ms
            </span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>
              {isAr ? 'الطاقة:' : 'Energy:'}{' '}
              {Math.min(100, Math.max(20, vitals.bodyEnergy + Math.round((selectedMood.score - 60) * 0.2)))}%
            </span>
          </div>
        </div>
      </div>

      {/* 1. Daily Mood Tracking Entry Point */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <Smile className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'كيف تشعر اليوم؟ (سجل حالتك النفسية لرصد تأثيرها البدني):' : 'How are you feeling today? (Log mood to map physical impact):'}</span>
          </div>

          {moodLoggedSuccess && (
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-3 py-1 rounded-full border border-emerald-800 flex items-center gap-1.5 animate-bounce">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isAr ? 'تم تحديث الارتباط بنجاح!' : 'Mood Correlated!'}</span>
            </span>
          )}
        </div>

        {/* Mood Selection Buttons Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {MOOD_OPTIONS.map((mood) => {
            const isSelected = selectedMood.id === mood.id;
            return (
              <button
                key={mood.id}
                onClick={() => handleSelectMood(mood)}
                className={`p-3 rounded-2xl border transition-all text-center flex flex-col items-center justify-center gap-1.5 relative overflow-hidden group ${
                  isSelected
                    ? `${mood.bgSelected} ${mood.borderSelected} shadow-[0_0_15px_rgba(245,158,11,0.2)] scale-[1.02]`
                    : 'bg-slate-900 border-slate-800 hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <span className="text-2xl group-hover:scale-125 transition-transform">{mood.emoji}</span>
                <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {isAr ? mood.labelAr : mood.labelEn}
                </span>
                <span className={`text-[10px] font-mono font-bold ${mood.color}`}>
                  HRV {mood.hrvImpactMs > 0 ? `+${mood.hrvImpactMs}` : mood.hrvImpactMs} ms
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Recharts 7-Day Correlated Trend Chart */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-400">
          <span>{isAr ? 'منحنى تتبع المزاج (0-100) مقابل مؤشر استشفاء HRV وطاقة الجسم' : '7-Day Correlated Timeline (Mood Index vs HRV & Energy)'}</span>
          <span className="text-[10px] font-mono text-cyan-400">LIVE SYNTHESIS</span>
        </div>

        <div className="w-full h-72 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={baseData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <defs>
                <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="day" stroke="#94a3b8" tick={{ fontSize: 11 }} tickLine={false} />
              <YAxis
                yAxisId="left"
                stroke="#c084fc"
                tick={{ fontSize: 11 }}
                domain={[20, 100]}
                tickFormatter={(val) => `${val}`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                stroke="#10b981"
                tick={{ fontSize: 11 }}
                domain={[0, 100]}
                tickFormatter={(val) => `${val}%`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }}
                formatter={(value) => (
                  <span className="text-slate-300 font-bold">
                    {value === 'hrvMs'
                      ? isAr
                        ? 'مؤشر HRV (مللي ثانية)'
                        : 'HRV Index (ms)'
                      : value === 'bodyEnergy'
                      ? isAr
                        ? 'طاقة الجسم (%)'
                        : 'Body Energy (%)'
                      : isAr
                      ? 'مؤشر المزاج العاطفي (0-100)'
                      : 'Emotional Mood Index (0-100)'}
                  </span>
                )}
              />
              <Area
                yAxisId="right"
                type="monotone"
                dataKey="bodyEnergy"
                name="bodyEnergy"
                stroke="#10b981"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#energyGrad)"
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="hrvMs"
                name="hrvMs"
                stroke="#c084fc"
                strokeWidth={3}
                dot={{ r: 5, fill: '#c084fc' }}
                activeDot={{ r: 8 }}
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="moodScore"
                name="moodScore"
                stroke="#f59e0b"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={{ r: 4, fill: '#f59e0b' }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 3. Psycho-Neuro-Vital Correlation Breakdown Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-purple-950/20 to-slate-950 border border-purple-800/40 space-y-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <h4 className="text-xs font-black text-purple-300">
            {isAr ? 'استبصار الارتباط النفسي-البدني (Psycho-Vital Insight)' : 'Emotional-Physical Correlation Summary'}
          </h4>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          {isAr
            ? `تظهر البيانات التحليلية أن أيام المزاج المستقر (${selectedMood.labelAr}) ترتبط بارتفاع مباشر في مؤشر HRV بمقدار +${
                selectedMood.hrvImpactMs > 0 ? selectedMood.hrvImpactMs : 15
              } مللي ثانية، مما يسرع عملية الاستشفاء العضلي والعصبي بأكثر من 28%.`
            : `Analytical telemetry confirms that periods of emotional balance (${selectedMood.labelEn}) directly boost HRV baseline by +${
                selectedMood.hrvImpactMs > 0 ? selectedMood.hrvImpactMs : 15
              }ms, accelerating neuro-muscular recovery by over 28%.`}
        </p>
      </div>
    </div>
  );
};
