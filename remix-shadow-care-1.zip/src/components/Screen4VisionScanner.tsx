import React, { useState } from 'react';
import { Activity, AlertCircle, Camera, Check, CheckCircle2, Coffee, Eye, Flame, Gauge, Pill, ShieldAlert, Sliders, Sparkles, Sun, SunDim, SunMedium, Utensils, Volume2, Zap } from 'lucide-react';
import { Language, PatientProfile, VisionScanResult } from '../types';
import { sampleVisionScans } from '../data/initialData';

interface Screen4VisionScannerProps {
  language: Language;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
}

export const Screen4VisionScanner: React.FC<Screen4VisionScannerProps> = ({
  language,
  patientProfile,
  onTriggerSpeech,
}) => {
  const isAr = language === 'ar';
  const [activeScan, setActiveScan] = useState<VisionScanResult | null>(sampleVisionScans[0]);
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Ambient Light Calibration Feature State
  const [ambientLux, setAmbientLux] = useState<number>(480);
  const [lightModePreset, setLightModePreset] = useState<'dim' | 'balanced' | 'bright'>('balanced');
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [calibrationStep, setCalibrationStep] = useState<number>(0);
  const [isCalibrated, setIsCalibrated] = useState<boolean>(true);
  const [sensorGain, setSensorGain] = useState<number>(1.0);
  const [ledDrivePercent, setLedDrivePercent] = useState<number>(85);
  const [signalQualityIndex, setSignalQualityIndex] = useState<number>(98);

  const handleRunScanScenario = (scanIndex: number) => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      const scan = sampleVisionScans[scanIndex];
      setActiveScan(scan);
      const speechText = isAr ? scan.audioAlertAr : scan.audioAlertEn;
      onTriggerSpeech(speechText);
    }, 1200);
  };

  const handleSelectPresetLight = (preset: 'dim' | 'balanced' | 'bright') => {
    setLightModePreset(preset);
    let lux = 480;
    let gain = 1.0;
    let drive = 85;
    if (preset === 'dim') {
      lux = 75;
      gain = 1.45;
      drive = 100;
    } else if (preset === 'bright') {
      lux = 1750;
      gain = 0.65;
      drive = 45;
    }
    setAmbientLux(lux);
    setSensorGain(gain);
    setLedDrivePercent(drive);
    setIsCalibrated(false);
  };

  const handleRunAmbientCalibration = () => {
    setIsCalibrating(true);
    setCalibrationStep(1);

    const startMsg = isAr
      ? `بدء قياس الإضاءة المحيطة لمعايرة مستشعر نبضات القلب الضوئي. جاري توجيه الكاميرا وحساب نسبة الإشارة إلى الضوضاء...`
      : `Starting ambient light optical HR calibration. Measuring background illuminance and signal noise ratio...`;
    onTriggerSpeech(startMsg);

    setTimeout(() => {
      setCalibrationStep(2);
      setTimeout(() => {
        setCalibrationStep(3);
        setTimeout(() => {
          setIsCalibrating(false);
          setIsCalibrated(true);
          setCalibrationStep(4);
          const sqi = Math.min(99, Math.max(91, Math.round(100 - (ambientLux > 1400 ? 6 : ambientLux < 100 ? 4 : 1))));
          setSignalQualityIndex(sqi);

          const doneMsg = isAr
            ? `تمت معايرة المستشعر الضوئي بنجاح! الإضاءة المحيطة ${ambientLux} Lux، الكسب البصري ${sensorGain}x، وقوة إشارة PPG تبلغ ${sqi}%.`
            : `HR sensor calibration locked! Ambient light ${ambientLux} Lux, gain ${sensorGain}x, PPG signal quality ${sqi}%.`;
          onTriggerSpeech(doneMsg);
        }, 1100);
      }, 1100);
    }, 1100);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-mono font-bold">
              VISION AI (Zero Manual Input)
            </span>
            <span className="text-xs text-slate-400">الشاشة 4 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-cyan-400" />
            <span>{isAr ? 'الماسح الضوئي السريع (Vision AI Scanner)' : 'Fast Vision AI Scanner'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `تحليل ذكي فوري لصور الأكل والقهوة والأدوية مع تنبيهات ناطقة وربط بالجهد الحيوي لـ (${patientProfile.name})`
              : `Instant AI analysis for food, coffee, and medications with spoken alerts for ${patientProfile.name}`}
          </p>
        </div>

        <span className="text-[10px] font-mono px-3 py-1.5 rounded-full bg-slate-950 text-emerald-400 border border-emerald-800 font-bold">
          100% LOCAL PROCESSING
        </span>
      </div>

      {/* Preset Scenario Selector Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        
        {/* Scenario 1: Food */}
        <button
          onClick={() => handleRunScanScenario(0)}
          className={`p-4 rounded-2xl border text-right transition-all flex items-center justify-between ${
            activeScan?.type === 'food'
              ? 'bg-rose-950/60 border-rose-500/80 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="space-y-1">
            <div className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
              <Utensils className="w-4 h-4" />
              <span>{isAr ? 'سيناريو 1: مسح الوجبة الدسمة' : 'Scenario 1: Heavy Meal Scan'}</span>
            </div>
            <div className="text-[11px] text-slate-300">
              {isAr ? 'وجبة مشويات ومقالي كبرى' : 'Heavy Kebabs & Fries'}
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-bold border border-rose-800">
            RED ALERT
          </span>
        </button>

        {/* Scenario 2: Coffee */}
        <button
          onClick={() => handleRunScanScenario(1)}
          className={`p-4 rounded-2xl border text-right transition-all flex items-center justify-between ${
            activeScan?.type === 'coffee'
              ? 'bg-amber-950/60 border-amber-500/80 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="space-y-1">
            <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <Coffee className="w-4 h-4" />
              <span>{isAr ? 'سيناريو 2: مسح كاسة القهوة 3' : 'Scenario 2: 3rd Coffee Cup'}</span>
            </div>
            <div className="text-[11px] text-slate-300">
              {isAr ? 'القهوة الثالثة اليوم + HRV' : '3rd Espresso Cup'}
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-bold border border-amber-800">
            SPIKE WARNING
          </span>
        </button>

        {/* Scenario 3: Medication */}
        <button
          onClick={() => handleRunScanScenario(2)}
          className={`p-4 rounded-2xl border text-right transition-all flex items-center justify-between ${
            activeScan?.type === 'medication'
              ? 'bg-emerald-950/60 border-emerald-500/80 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="space-y-1">
            <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <Pill className="w-4 h-4" />
              <span>{isAr ? 'سيناريو 3: مسح علبة العلاج' : 'Scenario 3: Med Photo'}</span>
            </div>
            <div className="text-[11px] text-slate-300">
              {isAr ? 'كونكور 5 ملجم للقلب' : 'Concor 5mg Pill'}
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-bold border border-emerald-800">
            MATCHED
          </span>
        </button>

      </div>

      {/* Main Interactive Camera View & Result Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Camera View Finder */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center min-h-[320px] relative overflow-hidden group">
          
          {/* Simulated Image Background */}
          {activeScan?.imageUrl ? (
            <img
              src={activeScan.imageUrl}
              alt="Scan Frame"
              className={`absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-all ${
                isScanning ? 'scale-110 filter blur-xs' : 'scale-100'
              }`}
            />
          ) : null}

          {/* Camera Scanning Grid Overlay */}
          <div className="absolute inset-4 border-2 border-dashed border-cyan-400/60 rounded-2xl pointer-events-none flex items-center justify-center">
            {isScanning && (
              <div className="w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent absolute animate-scan-line"></div>
            )}
          </div>

          {/* Action Center */}
          <div className="relative z-10 text-center space-y-4 p-4 bg-slate-950/80 rounded-2xl backdrop-blur-md border border-slate-800 max-w-sm">
            <div className="w-16 h-16 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-400 flex items-center justify-center mx-auto">
              <Camera className={`w-8 h-8 ${isScanning ? 'animate-bounce' : ''}`} />
            </div>

            <div className="space-y-1">
              <h3 className="text-sm font-black text-white">
                {isScanning
                  ? (isAr ? 'جاري تحليل الصورة والنموذج الحيوي...' : 'Analyzing Vision Model...')
                  : (isAr ? 'التقاط صورة سريعة للتحليل' : 'Capture Photo for AI Analysis')}
              </h3>
              <p className="text-[11px] text-slate-400">
                {isAr ? 'وجه الكاميرا نحو الأكل، القهوة، أو شريط العلاج' : 'Point watch camera at meal, coffee, or pill box'}
              </p>
            </div>

            <button
              onClick={() => handleRunScanScenario(activeScan?.type === 'food' ? 1 : activeScan?.type === 'coffee' ? 2 : 0)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-xs hover:opacity-90 shadow-lg transition-all"
            >
              {isAr ? 'التقاط الصورة والتحليل (Snap & Scan)' : 'Snap & Analyze Photo'}
            </button>
          </div>

        </div>

        {/* AI Result Card */}
        {activeScan && (
          <div className={`p-6 rounded-3xl border space-y-5 transition-all ${
            activeScan.riskLevel === 'red'
              ? 'bg-slate-900 border-rose-500/80 shadow-[0_0_30px_rgba(244,63,94,0.2)]'
              : 'bg-slate-900 border-emerald-500/80 shadow-[0_0_30px_rgba(16,185,129,0.2)]'
          }`}>
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2">
                {activeScan.riskLevel === 'red' ? (
                  <ShieldAlert className="w-6 h-6 text-rose-500 animate-bounce" />
                ) : (
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                )}
                <div>
                  <h3 className="text-base font-black text-white">
                    {isAr ? activeScan.titleAr : activeScan.titleEn}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono">{activeScan.timestamp}</p>
                </div>
              </div>

              <span className={`text-[10px] font-mono px-3 py-1 rounded-full font-bold uppercase border ${
                activeScan.riskLevel === 'red'
                  ? 'bg-rose-950 text-rose-300 border-rose-800'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}>
                {activeScan.riskLevel === 'red' ? (isAr ? 'تنبيه عالي المخاطر' : 'HIGH RISK') : (isAr ? 'مطابق وآمن' : 'SAFE MATCH')}
              </span>
            </div>

            {/* Audio Alert Message */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>{isAr ? 'التنبيه الصوتي الصادر فوراً للزر البرتقالي:' : 'Spoken Audio Voice Output:'}</span>
              </div>
              <p className="text-xs font-bold text-white leading-relaxed">
                "{isAr ? activeScan.audioAlertAr : activeScan.audioAlertEn}"
              </p>
            </div>

            {/* Scientific Details */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-400">
                {isAr ? 'التحليل الاستقلابي المتقاطع (Claim-02 & Claim-03):' : 'Cross-Metabolic Scientific Analysis:'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                {isAr ? activeScan.detailsAr : activeScan.detailsEn}
              </p>
            </div>

            <button
              onClick={() => onTriggerSpeech(isAr ? activeScan.audioAlertAr : activeScan.audioAlertEn)}
              className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-400 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <Volume2 className="w-4 h-4" />
              <span>{isAr ? 'إعادة تشغيل التنبيه الصوتي' : 'Replay Voice Alert'}</span>
            </button>
          </div>
        )}

      </div>

      {/* NEW FEATURE: AMBIENT LIGHT HEART RATE SENSOR CALIBRATION VISUAL GUIDE */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-cyan-900/60 space-y-5 shadow-2xl">
        
        {/* Module Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-950 text-cyan-400 border border-cyan-800 flex items-center justify-center font-bold shrink-0">
              <SunMedium className="w-6 h-6 animate-spin-slow text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-mono font-bold">
                  PATENT CLAIM-04 OPTICAL CALIBRATION
                </span>
                <span className="text-[10px] text-cyan-400 font-mono font-bold">PPG SENSOR OPTIMIZER</span>
              </div>
              <h3 className="text-base font-black text-white mt-0.5">
                {isAr ? 'دليل ودوزنة مستشعر النبض بحسب الإضاءة المحيطة (Ambient Light HR Calibration Guide)' : 'Ambient Light Optical HR Sensor Calibration Guide'}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={`text-xs font-mono font-bold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 ${
              isCalibrated
                ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                : 'bg-amber-950 text-amber-400 border-amber-800'
            }`}>
              {isCalibrated ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-amber-400" />}
              <span>{isCalibrated ? (isAr ? 'المعايرة محكمة 100%' : 'Calibration Locked') : (isAr ? 'يتطلب معايرة إضاءة' : 'Calibration Needed')}</span>
            </span>
          </div>
        </div>

        {/* Ambient Light Environment Simulator & Preset Buttons */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-xs font-bold text-white block">
                {isAr ? '1. حدد أو اضبط مستوى الإضاءة المحيطة الحالية:' : '1. Select Ambient Lighting Environment:'}
              </span>
              <p className="text-[11px] text-slate-400">
                {isAr
                  ? 'يتم دوزنة كسب المستشعر الضوئي (PPG Optical Gain) تلقائياً لتفادي التشويش الناجم عن الشمس أو الغرف المظلمة.'
                  : 'Automatically compensates optical sensor gain & LED drive to neutralize solar glare or dim illumination noise.'}
              </p>
            </div>

            <div className="flex items-center gap-2 font-mono text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-amber-400 shrink-0">
              <Sun className="w-4 h-4 text-amber-400" />
              <span>{ambientLux} LUX</span>
            </div>
          </div>

          {/* Preset Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => handleSelectPresetLight('dim')}
              className={`p-3 rounded-xl border text-right transition-all flex items-center justify-between ${
                lightModePreset === 'dim'
                  ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2">
                <SunDim className="w-5 h-5 text-indigo-400" />
                <div>
                  <span className="text-xs font-bold block">{isAr ? 'إضاءة خافتة / غرفة مغلقة' : 'Dim / Low Light Room'}</span>
                  <span className="text-[10px] text-slate-400 font-mono">&lt; 100 Lux (Gain +45%)</span>
                </div>
              </div>
              {lightModePreset === 'dim' && <Check className="w-4 h-4 text-indigo-400" />}
            </button>

            <button
              onClick={() => handleSelectPresetLight('balanced')}
              className={`p-3 rounded-xl border text-right transition-all flex items-center justify-between ${
                lightModePreset === 'balanced'
                  ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2">
                <SunMedium className="w-5 h-5 text-emerald-400" />
                <div>
                  <span className="text-xs font-bold block">{isAr ? 'إضاءة مكتبية متوازنة' : 'Balanced Indoor Light'}</span>
                  <span className="text-[10px] text-slate-400 font-mono">300 - 600 Lux (Standard)</span>
                </div>
              </div>
              {lightModePreset === 'balanced' && <Check className="w-4 h-4 text-emerald-400" />}
            </button>

            <button
              onClick={() => handleSelectPresetLight('bright')}
              className={`p-3 rounded-xl border text-right transition-all flex items-center justify-between ${
                lightModePreset === 'bright'
                  ? 'bg-amber-950/80 border-amber-500 text-white shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2">
                <Sun className="w-5 h-5 text-amber-400" />
                <div>
                  <span className="text-xs font-bold block">{isAr ? 'أشعة شمس مباشرة / خارجية' : 'Direct Outdoor Sunlight'}</span>
                  <span className="text-[10px] text-slate-400 font-mono">&gt; 1500 Lux (Notch Filter)</span>
                </div>
              </div>
              {lightModePreset === 'bright' && <Check className="w-4 h-4 text-amber-400" />}
            </button>
          </div>

          {/* Interactive Lux Slider */}
          <div className="pt-2 space-y-1.5">
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>{isAr ? 'مقياس الشدة الضوئية المستشعرة:' : 'Continuous Ambient Illuminance Sensor:'}</span>
              <span className="text-amber-300 font-bold">{ambientLux} Lux</span>
            </div>
            <input
              type="range"
              min="50"
              max="2000"
              step="25"
              value={ambientLux}
              onChange={(e) => {
                const lux = Number(e.target.value);
                setAmbientLux(lux);
                setIsCalibrated(false);
                if (lux < 150) {
                  setLightModePreset('dim');
                  setSensorGain(1.45);
                  setLedDrivePercent(100);
                } else if (lux > 1200) {
                  setLightModePreset('bright');
                  setSensorGain(0.65);
                  setLedDrivePercent(45);
                } else {
                  setLightModePreset('balanced');
                  setSensorGain(1.0);
                  setLedDrivePercent(85);
                }
              }}
              className="w-full accent-amber-500 h-2 bg-slate-900 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Visual Target Alignment & Calibration Guide HUD */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          
          {/* Visual Targeting Circle Overlay */}
          <div className="flex flex-col items-center justify-center p-6 bg-slate-900 rounded-2xl border border-slate-800 relative overflow-hidden text-center space-y-4">
            
            {/* Pulsing Target Calibration Alignment Frame */}
            <div className={`w-36 h-36 rounded-full border-4 flex items-center justify-center relative transition-all duration-500 ${
              isCalibrating
                ? 'border-cyan-400 animate-spin-slow shadow-[0_0_30px_rgba(34,211,238,0.4)]'
                : isCalibrated
                ? 'border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                : 'border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
            }`}>
              <div className="w-28 h-28 rounded-full bg-slate-950/80 border border-slate-800 flex flex-col items-center justify-center p-2">
                {isCalibrating ? (
                  <Gauge className="w-8 h-8 text-cyan-400 animate-pulse" />
                ) : isCalibrated ? (
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                ) : (
                  <Eye className="w-8 h-8 text-amber-400" />
                )}
                <span className="text-[10px] font-mono font-bold text-white mt-1">
                  {isCalibrating
                    ? (isAr ? 'جاري المعايرة...' : 'Calibrating...')
                    : isCalibrated
                    ? (isAr ? 'الإشارة ممتازة' : 'PPG LOCKED')
                    : (isAr ? 'وجه نحو الضوء' : 'ALIGN LIGHT')}
                </span>
              </div>

              {/* Corner reticle marks */}
              <div className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400"></div>
              <div className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400"></div>
              <div className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400"></div>
              <div className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400"></div>
            </div>

            <button
              onClick={handleRunAmbientCalibration}
              disabled={isCalibrating}
              className={`w-full py-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                isCalibrating
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-500 via-cyan-500 to-blue-600 text-slate-950 hover:opacity-90'
              }`}
            >
              <Zap className="w-4 h-4 text-slate-950" />
              <span>
                {isCalibrating
                  ? (isAr ? 'جاري قياس ومعايرة الحساس...' : 'Calibrating HR Sensor...')
                  : (isAr ? 'تشغيل معايرة الإضاءة المحيطية للمستشعر' : 'Run Ambient Light Calibration')}
              </span>
            </button>
          </div>

          {/* Real-time Optical Parameters Metrics */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>{isAr ? 'مؤشرات ضبط المستشعر البصري الفورية:' : 'Live Optical PPG Sensor Calibrated Metrics:'}</span>
            </h4>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">{isAr ? 'الكسب البصري (Optical Gain):' : 'Optical Gain Offset:'}</span>
                <span className="text-sm font-mono font-black text-cyan-400">{sensorGain}x</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">{isAr ? 'شدة LED للمستشعر:' : 'PPG LED Drive:'}</span>
                <span className="text-sm font-mono font-black text-amber-400">{ledDrivePercent}%</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">{isAr ? 'جودة إشارة PPG:' : 'PPG Signal Quality:'}</span>
                <span className="text-sm font-mono font-black text-emerald-400">{signalQualityIndex}%</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">{isAr ? 'إلغاء تشويش الضوء:' : 'Ambient Noise Cut:'}</span>
                <span className="text-sm font-mono font-black text-indigo-400">-18 dB</span>
              </div>
            </div>

            {/* Calibration Steps Indicator */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                <span>{isAr ? 'مراحل دقة المعايرة:' : 'Calibration Progress:'}</span>
                <span className="text-cyan-400 font-bold">{isCalibrated ? '4 / 4' : `${calibrationStep} / 4`}</span>
              </div>

              <div className="grid grid-cols-4 gap-1">
                <div className={`h-1.5 rounded-full ${calibrationStep >= 1 || isCalibrated ? 'bg-cyan-400' : 'bg-slate-800'}`}></div>
                <div className={`h-1.5 rounded-full ${calibrationStep >= 2 || isCalibrated ? 'bg-amber-400' : 'bg-slate-800'}`}></div>
                <div className={`h-1.5 rounded-full ${calibrationStep >= 3 || isCalibrated ? 'bg-blue-400' : 'bg-slate-800'}`}></div>
                <div className={`h-1.5 rounded-full ${calibrationStep >= 4 || isCalibrated ? 'bg-emerald-400' : 'bg-slate-800'}`}></div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
