import React, { useState } from 'react';
import { AlertTriangle, Coffee, CupSoda, Flame, Info, Plus, RotateCcw, ShieldAlert, Sparkles, Trash2, Volume2, Zap } from 'lucide-react';
import { CaffeineLogItem, Language, PatientProfile } from '../types';

interface CaffeineTrackerProps {
  language: Language;
  patientProfile: PatientProfile;
  onTriggerSpeech: (text: string) => void;
  onUpdateVitalsStress?: (hrDelta: number, stressDelta: number) => void;
}

export const CaffeineTracker: React.FC<CaffeineTrackerProps> = ({
  language,
  patientProfile,
  onTriggerSpeech,
  onUpdateVitalsStress,
}) => {
  const isAr = language === 'ar';
  const maxCaffeineLimit = 300; // mg safe limit for heart-monitored profile

  const [caffeineLogs, setCaffeineLogs] = useState<CaffeineLogItem[]>([
    {
      id: 'caf-1',
      nameAr: 'إسبريسو سينجل (Espresso)',
      nameEn: 'Single Espresso',
      caffeineMg: 75,
      time: '08:30 AM',
      type: 'espresso',
    },
    {
      id: 'caf-2',
      nameAr: 'قهوة أمريكانو (Americano)',
      nameEn: 'Americano Coffee',
      caffeineMg: 95,
      time: '11:15 AM',
      type: 'americano',
    },
  ]);

  const [customName, setCustomName] = useState('');
  const [customMg, setCustomMg] = useState(80);
  const [showCustomForm, setShowCustomForm] = useState(false);

  const totalCaffeineMg = caffeineLogs.reduce((sum, item) => sum + item.caffeineMg, 0);
  const isWarningZone = totalCaffeineMg >= 240;
  const isOverLimit = totalCaffeineMg >= maxCaffeineLimit;

  // Preset quick logging buttons
  const presets = [
    { nameAr: 'إسبريسو (Single)', nameEn: 'Single Espresso', mg: 75, type: 'espresso' as const, icon: Coffee },
    { nameAr: 'أمريكانو / كبسولة', nameEn: 'Americano / Pod', mg: 95, type: 'americano' as const, icon: Coffee },
    { nameAr: 'قهوة تركية / عربية', nameEn: 'Turkish / Arabic Coffee', mg: 85, type: 'turkish' as const, icon: Coffee },
    { nameAr: 'شاي أحمر / أخضر', nameEn: 'Tea (Red / Green)', mg: 45, type: 'tea' as const, icon: CupSoda },
    { nameAr: 'مشروب طاقة (Energy)', nameEn: 'Energy Drink', mg: 160, type: 'energy' as const, icon: Zap },
  ];

  const handleAddPreset = (preset: typeof presets[0]) => {
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newItem: CaffeineLogItem = {
      id: 'caf-' + Date.now(),
      nameAr: preset.nameAr,
      nameEn: preset.nameEn,
      caffeineMg: preset.mg,
      time: nowTime,
      type: preset.type,
    };

    const newTotal = totalCaffeineMg + preset.mg;
    setCaffeineLogs((prev) => [newItem, ...prev]);

    if (newTotal >= maxCaffeineLimit) {
      const msg = isAr
        ? `تحذير لـ ${patientProfile.name}! تجاوزت حد الكافيين الآمن بـ ${newTotal} ملجم. الكاسة الثالثة قد تسبب تسارع النبض وارتفاع التوتر.`
        : `Warning for ${patientProfile.name}! Caffeine limit exceeded (${newTotal}mg). Third cup alert!`;
      onTriggerSpeech(msg);
      if (onUpdateVitalsStress) onUpdateVitalsStress(14, 25);
    } else if (newTotal >= 200) {
      const msg = isAr
        ? `تنبيه الكافيين: الجرعة الإجمالية وصلت لـ ${newTotal} ملجم. يرجى التوقف لتجنب الأرق والتأثير على نوم الليل.`
        : `Caffeine alert: Total reached ${newTotal}mg. Pause caffeine intake for better sleep.`;
      onTriggerSpeech(msg);
      if (onUpdateVitalsStress) onUpdateVitalsStress(6, 12);
    } else {
      const msg = isAr
        ? `تم تسجيل تناول ${preset.nameAr} (${preset.mg} ملجم). الجرعة الإجمالية: ${newTotal} ملجم.`
        : `Logged ${preset.nameEn} (${preset.mg}mg). Total: ${newTotal}mg.`;
      onTriggerSpeech(msg);
    }
  };

  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newItem: CaffeineLogItem = {
      id: 'caf-' + Date.now(),
      nameAr: customName,
      nameEn: customName,
      caffeineMg: Number(customMg) || 80,
      time: nowTime,
      type: 'custom',
    };
    setCaffeineLogs((prev) => [newItem, ...prev]);
    setCustomName('');
    setShowCustomForm(false);
    const msg = isAr
      ? `تم إضافة ${newItem.nameAr} بنجاح.`
      : `Added ${newItem.nameEn} successfully.`;
    onTriggerSpeech(msg);
  };

  const handleRemoveLog = (id: string) => {
    setCaffeineLogs((prev) => prev.filter((item) => item.id !== id));
  };

  const handleResetLogs = () => {
    setCaffeineLogs([]);
    const msg = isAr ? 'تم إعادة تعيين سجل الكافيين اليومي.' : 'Daily caffeine log reset.';
    onTriggerSpeech(msg);
  };

  // 3rd Cup Alert Simulator
  const handleSimulateThirdCupAlert = () => {
    handleAddPreset({
      nameAr: 'كوب القهوة الثالث (الكاسة الثالثة - تحذير!)',
      nameEn: '3rd Coffee Cup (Warning Spike)',
      mg: 110,
      type: 'espresso',
      icon: Coffee,
    });
  };

  return (
    <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-950 text-amber-400 border border-amber-800 flex items-center justify-center font-bold">
            <Coffee className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-mono font-bold">
                PATENT CLAIM-03 & 17
              </span>
              <span className="text-[10px] text-amber-400 font-mono font-bold">CAFFEINE SHIELD</span>
            </div>
            <h3 className="text-lg font-black text-white mt-0.5">
              {isAr ? 'حاسبة وتتبع الكافيين اليومي (Caffeine Tracker)' : 'Daily Caffeine Tracker & Clearance Meter'}
            </h3>
          </div>
        </div>

        <button
          onClick={handleResetLogs}
          className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-400 text-xs font-bold border border-slate-800 flex items-center gap-1.5 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>{isAr ? 'إعادة التعيين' : 'Reset Logs'}</span>
        </button>
      </div>

      {/* Progress & Meter Gauge */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Total Intake Display */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 flex flex-col justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold">{isAr ? 'إجمالي الكافيين المستهلك:' : 'Total Caffeine Intake:'}</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className={`text-4xl font-black font-mono ${
                isOverLimit ? 'text-rose-500 animate-pulse' : isWarningZone ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {totalCaffeineMg}
              </span>
              <span className="text-sm text-slate-400 font-bold">mg / {maxCaffeineLimit} mg</span>
            </div>
          </div>

          <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                isOverLimit ? 'bg-rose-500' : isWarningZone ? 'bg-amber-400' : 'bg-emerald-400'
              }`}
              style={{ width: `${Math.min(100, (totalCaffeineMg / maxCaffeineLimit) * 100)}%` }}
            ></div>
          </div>
        </div>

        {/* 3rd Cup Alert Status Box */}
        <div className={`p-5 rounded-2xl border space-y-2 flex flex-col justify-between ${
          isOverLimit
            ? 'bg-rose-950/60 border-rose-600 text-rose-200'
            : isWarningZone
            ? 'bg-amber-950/40 border-amber-800 text-amber-300'
            : 'bg-emerald-950/30 border-emerald-800/80 text-emerald-300'
        }`}>
          <div className="flex items-center justify-between font-bold text-xs">
            <span className="flex items-center gap-1.5">
              {isOverLimit ? <ShieldAlert className="w-4 h-4 text-rose-400 animate-bounce" /> : <Info className="w-4 h-4 text-amber-400" />}
              <span>
                {isOverLimit
                  ? (isAr ? 'تنبيه الكاسة الثالثة (خطر تسارع النبض!)' : '3rd Cup Alert (Pulse Spike Risk!)')
                  : isWarningZone
                  ? (isAr ? 'قرب الجرعة القصوى (انتبه لموعد النوم)' : 'Near Max Limit (Watch sleep window)')
                  : (isAr ? 'الجرعة في نطاق التوازن الآمن' : 'Safe Caffeine Balanced Tier')}
              </span>
            </span>
          </div>

          <p className="text-[11px] leading-relaxed opacity-90">
            {isAr
              ? 'يقوم نظام Claim-03 بموازنة الكافيين مع ضربات القلب ونظام كونكور الموصوف لمنع الارتفاع المضلل في الإجهاد.'
              : 'Claim-03 isolates caffeine stimulation from exercise loads to preserve vital accuracy.'}
          </p>

          <button
            onClick={handleSimulateThirdCupAlert}
            className="w-full py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'اختبار تنبيه الكاسة الثالثة' : 'Test 3rd Cup Alert'}</span>
          </button>
        </div>

        {/* Half-Life Clearance Estimate */}
        <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-xs text-slate-400 font-bold">{isAr ? 'زمن تكسير الكافيين بالجسم (Half-Life):' : 'Caffeine Metabolism Half-Life:'}</span>
          <div className="text-2xl font-black font-mono text-cyan-400">
            ~ 5.5 <span className="text-xs font-sans text-slate-400">{isAr ? 'ساعات متبقية' : 'hours remaining'}</span>
          </div>
          <p className="text-[11px] text-slate-400">
            {isAr ? 'ينصح بالتوقف عن الكافيين قبل 6 ساعات من موعد النوم لحماية Sleep Shield.' : 'Avoid caffeine 6h prior to bedtime to protect Sleep Shield.'}
          </p>
        </div>

      </div>

      {/* Interactive Quick Add Buttons */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold text-slate-300">{isAr ? 'أزرار التسجيل السريع للكافيين:' : 'Quick Log Preset Buttons:'}</h4>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
          {presets.map((p, idx) => {
            const IconComponent = p.icon;
            return (
              <button
                key={idx}
                onClick={() => handleAddPreset(p)}
                className="p-3 rounded-2xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 text-right transition-all flex flex-col justify-between space-y-2 group"
              >
                <div className="flex items-center justify-between w-full">
                  <IconComponent className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-bold border border-amber-800">
                    +{p.mg}mg
                  </span>
                </div>
                <div>
                  <div className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                    {isAr ? p.nameAr : p.nameEn}
                  </div>
                  <div className="text-[10px] text-slate-500">{isAr ? 'اضغط للتسجيل' : 'Tap to Log'}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Adder Toggle */}
      <div>
        {!showCustomForm ? (
          <button
            onClick={() => setShowCustomForm(true)}
            className="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-cyan-400 border border-slate-800 text-xs font-bold transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إضافة مشروب كافيين مخصص' : 'Add Custom Caffeine Drink'}</span>
          </button>
        ) : (
          <form onSubmit={handleAddCustom} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between text-xs font-bold text-white">
              <span>{isAr ? 'بيانات المشروب المخصص:' : 'Custom Caffeine Details:'}</span>
              <button
                type="button"
                onClick={() => setShowCustomForm(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder={isAr ? 'اسم المشروب (مثال: لاتيه بذور الكاكاو)' : 'Drink Name (e.g. Cocoa Latte)'}
                className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
                required
              />

              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={customMg}
                  onChange={(e) => setCustomMg(Number(e.target.value))}
                  placeholder="Caffeine mg"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none font-mono"
                  required
                />
                <span className="text-xs text-slate-400 font-bold">mg</span>
              </div>
            </div>

            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-black text-xs hover:opacity-90 transition-opacity"
            >
              {isAr ? 'تأكيد وحفظ الجرعة' : 'Save Dose'}
            </button>
          </form>
        )}
      </div>

      {/* Logged History List */}
      <div className="space-y-2">
        <span className="text-xs font-bold text-slate-400">{isAr ? 'سجل مشروبات الكافيين اليوم:' : 'Logged Caffeine History Today:'}</span>
        
        {caffeineLogs.length === 0 ? (
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-500">
            {isAr ? 'لم يتم تسجيل أي مشروبات كافيين اليوم.' : 'No caffeine logged today yet.'}
          </div>
        ) : (
          <div className="space-y-2">
            {caffeineLogs.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <Coffee className="w-4 h-4 text-amber-400" />
                  <div>
                    <span className="font-bold text-white block">{isAr ? item.nameAr : item.nameEn}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{item.time}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono font-black text-amber-400 text-sm">+{item.caffeineMg} mg</span>
                  <button
                    onClick={() => handleRemoveLog(item.id)}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
