import React, { useEffect, useRef } from 'react';
import { Activity, AlertCircle, FileText, Heart, HeartPulse, ShieldAlert, Sparkles, Thermometer, Wind, Zap } from 'lucide-react';
import { CurrentVitals, Language, PatientProfile } from '../types';
import { StressSpikeHeatmapOverlay } from './StressSpikeHeatmapOverlay';

interface Screen2HeartRateProps {
  language: Language;
  vitals: CurrentVitals;
  patientProfile: PatientProfile;
  onSimulateSpike: (type?: 'tachycardia' | 'hypoxia' | 'fever') => void;
  onTriggerSpeech: (text: string) => void;
  onOpenClinicPass: () => void;
  onOpenBreathingOverlay?: (reason?: string) => void;
}

export const Screen2HeartRate: React.FC<Screen2HeartRateProps> = ({
  language,
  vitals,
  patientProfile,
  onSimulateSpike,
  onTriggerSpeech,
  onOpenClinicPass,
  onOpenBreathingOverlay,
}) => {
  const isAr = language === 'ar';
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [liveGlowOpacity, setLiveGlowOpacity] = React.useState<number>(0.5);

  // Animated ECG Line Canvas with Real-time Breathing Synchronization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let step = 0;
    const startTime = performance.now();

    const render = (currentTime: number) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const elapsed = (currentTime - startTime) / 1000;
      // Calculate breathing frequency matching real-time heart rate (BPM / 60 = beats per sec)
      const bpmHz = Math.max(40, Math.min(180, vitals.heartRate)) / 60;
      const breathPhase = Math.sin(elapsed * bpmHz * Math.PI * 2); // -1 to 1 oscillation
      const breathScale = 1 + breathPhase * 0.18; // 0.82 to 1.18 breathing expansion scale

      const isHighHR = vitals.heartRate > 120;
      const mainColor = isHighHR ? '#ef4444' : '#06b6d4';
      const glowColor = isHighHR ? 'rgba(239, 68, 68, 0.35)' : 'rgba(6, 182, 212, 0.3)';

      // 1. Subtle Radial Background Breathing Glow
      const centerY = canvas.height / 2;
      const glowRadius = Math.max(20, (canvas.height / 2) * breathScale * 1.5);
      const bgGlow = ctx.createRadialGradient(canvas.width / 2, centerY, 5, canvas.width / 2, centerY, glowRadius * 3);
      bgGlow.addColorStop(0, glowColor);
      bgGlow.addColorStop(1, 'rgba(15, 23, 42, 0)');
      ctx.fillStyle = bgGlow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 2. Grid background lines
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.08)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 3. Synchronized Breathing ECG Waveform
      ctx.save();
      ctx.shadowColor = mainColor;
      ctx.shadowBlur = 8 + breathPhase * 6; // Dynamic breathing shadow blur
      ctx.strokeStyle = mainColor;
      ctx.lineWidth = 2.2 + breathPhase * 0.6; // Dynamic line width expansion
      ctx.beginPath();

      step += isHighHR ? 4.5 : 2.5;

      for (let x = 0; x < canvas.width; x++) {
        const offset = (x + step) % 120;
        let amp = 1;

        // Apply amplitude modulation based on breathing phase
        let y = centerY;

        if (offset > 40 && offset < 50) {
          y = centerY - 10 * breathScale; // P wave
        } else if (offset >= 50 && offset < 55) {
          y = centerY + 12 * breathScale; // Q wave
        } else if (offset >= 55 && offset < 65) {
          y = centerY - 48 * breathScale; // R peak (synchronized breathing expansion)
        } else if (offset >= 65 && offset < 70) {
          y = centerY + 22 * breathScale; // S wave
        } else if (offset >= 80 && offset < 95) {
          y = centerY - 16 * breathScale; // T wave
        }

        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.restore();

      // 4. Glowing Rhythmical Pulse Dots at R-Peaks
      ctx.fillStyle = mainColor;
      for (let x = 0; x < canvas.width; x++) {
        const offset = (x + step) % 120;
        if (offset >= 58 && offset <= 60) {
          const rPeakY = centerY - 48 * breathScale;
          ctx.beginPath();
          ctx.arc(x, rPeakY, 3.5 * breathScale, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Update state glow for card border breathing
      setLiveGlowOpacity(0.4 + breathPhase * 0.25);

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => cancelAnimationFrame(animationFrameId);
  }, [vitals.heartRate]);

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner & Patent Ref */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-mono font-bold">
              PATENT CLAIM-02, CLAIM-12 & CLAIM-13
            </span>
            <span className="text-xs text-slate-400">الشاشة 2 من 6</span>
          </div>
          <h2 className="text-xl font-black text-white mt-1 flex items-center gap-2">
            <HeartPulse className="w-6 h-6 text-rose-500 animate-pulse" />
            <span>{isAr ? 'نبضات القلب، التقرير الطبي و HRV' : 'Heart Rate, Clinic Pass & HRV'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAr
              ? `خوارزمية التنبؤ بالإجهاد وتوليد التقرير الطبي الموثق بضغطة زر لـ (${patientProfile.name})`
              : `HRV Stress prediction and Cryptographic Clinic Pass generator for ${patientProfile.name}`}
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Clinic Pass Button */}
          <button
            onClick={onOpenClinicPass}
            className="px-4 py-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black text-xs shadow-lg hover:opacity-90 transition-all flex items-center gap-2"
          >
            <FileText className="w-4 h-4" />
            <span>{isAr ? 'توليد التقرير الطبي (Clinic Pass - البند 13)' : 'Generate Clinic Pass (Claim-13)'}</span>
          </button>

          {/* Spike Triggers */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
            <button
              onClick={() => onSimulateSpike('tachycardia')}
              className="px-2.5 py-1 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 text-[11px] font-bold transition-all"
            >
              {isAr ? 'تسارع نبض' : 'Tachycardia'}
            </button>
            <button
              onClick={() => onSimulateSpike('hypoxia')}
              className="px-2.5 py-1 rounded-xl bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 text-[11px] font-bold transition-all"
            >
              {isAr ? 'نقص أكسجين' : 'Hypoxia'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Heart Rate Big Display */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold text-slate-400">{isAr ? 'معدل نبضات القلب' : 'Heart Rate'}</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800 font-bold">
              PPG SENSOR ACTIVE
            </span>
          </div>

          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className={`text-6xl font-black font-mono tracking-tight ${
                vitals.heartRate > 120 ? 'text-rose-500 animate-pulse' : 'text-white'
              }`}>
                {vitals.heartRate}
              </span>
              <span className="text-sm font-bold text-slate-400">BPM</span>
            </div>

            <div className="p-3 rounded-2xl bg-rose-950/60 text-rose-400 border border-rose-800/80 animate-ping">
              <Heart className="w-6 h-6 fill-rose-500" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
            <div className="flex items-center justify-between">
              <span>{isAr ? 'النطاق المستهدف المخصص:' : 'Personal Target Range:'}</span>
              <span className="font-mono text-emerald-400 font-bold">
                {(patientProfile.targetHeartRateMin ?? 60)} - {(patientProfile.targetHeartRateMax ?? 100)} BPM
              </span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-slate-900">
              <span className="text-[11px] text-slate-400">{isAr ? 'مؤشر الهدف:' : 'Goal Status:'}</span>
              {vitals.heartRate >= (patientProfile.targetHeartRateMin ?? 60) && vitals.heartRate <= (patientProfile.targetHeartRateMax ?? 100) ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                  ✓ {isAr ? 'ضمن الهدف المحدد' : 'Goal Met (In Range)'}
                </span>
              ) : vitals.heartRate > (patientProfile.targetHeartRateMax ?? 100) ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1 animate-pulse">
                  ⚠ {isAr ? 'تجاوز الحد الأقصى' : 'Exceeds Max Target'}
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
                  ↓ {isAr ? 'أقل من الحد الأدنى' : 'Below Min Target'}
                </span>
              )}
            </div>
          </div>

          {onOpenBreathingOverlay && (
            <button
              onClick={() =>
                onOpenBreathingOverlay(
                  vitals.heartRate > (patientProfile.targetHeartRateMax ?? 100)
                    ? (isAr ? `تنبيه تسارع النبض (${vitals.heartRate} BPM) — ابدأ تمرين 4-7-8 لتهدئة القلب` : `Pulse Spike Alert (${vitals.heartRate} BPM) — Start 4-7-8 exercise to lower HR`)
                    : (isAr ? 'جلسة تنفس 4-7-8 تفاعلية لتعزيز صحة القلب والنبض' : 'Interactive 4-7-8 breathwork session for cardiac recovery')
                )
              }
              className={`w-full py-2.5 px-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                vitals.heartRate > (patientProfile.targetHeartRateMax ?? 100)
                  ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white animate-pulse'
                  : 'bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300'
              }`}
            >
              <Wind className="w-4 h-4 text-cyan-400" />
              <span>
                {vitals.heartRate > (patientProfile.targetHeartRateMax ?? 100)
                  ? (isAr ? '🫁 تهدئة النبض فوراً عبر تمرين 4-7-8' : '🫁 Lower Heart Rate Now (4-7-8)')
                  : (isAr ? 'تمرين التنفس 4-7-8 لتخفيض النبض' : '4-7-8 Breathwork Overlay')}
              </span>
            </button>
          )}
        </div>

        {/* SpO2 Oxygen Display */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold text-slate-400">{isAr ? 'نسبة تشبع الأكسجين (SpO2)' : 'Oxygen Saturation'}</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
              OPTICAL SENSOR
            </span>
          </div>

          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className={`text-6xl font-black font-mono tracking-tight ${
                vitals.spo2 < 92 ? 'text-rose-500 animate-pulse' : 'text-cyan-400'
              }`}>
                {vitals.spo2}%
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-cyan-950/60 text-cyan-400 border border-cyan-800/80">
              <Activity className="w-6 h-6" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <span>{isAr ? 'حالة التروية الدموية:' : 'Perfusion Status:'}</span>
            <span className={`font-mono font-bold ${vitals.spo2 < 92 ? 'text-rose-400' : 'text-emerald-400'}`}>
              {vitals.spo2 < 92 ? (isAr ? 'منخفضة - يتطلب متابعة' : 'Low Hypoxia') : (isAr ? 'ممتازة ومستقرة' : 'Optimal')}
            </span>
          </div>
        </div>

        {/* HRV Stress Prediction Algorithm (Patent Claim 12) */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold text-slate-400">{isAr ? 'التنبؤ بالإجهاد HRV (Claim-12)' : 'HRV Stress Prediction'}</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800 font-bold">
              PROACTIVE
            </span>
          </div>

          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-6xl font-black font-mono tracking-tight text-amber-400">
                {vitals.hrvIndex || 64}
              </span>
              <span className="text-sm font-bold text-slate-400">ms</span>
            </div>

            <div className="p-3 rounded-2xl bg-amber-950/60 text-amber-400 border border-amber-800/80">
              <Zap className="w-6 h-6" />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <span>{isAr ? 'توقع الإجهاد الاستقلابي:' : 'Metabolic Stress Projection:'}</span>
            <span className="font-mono text-amber-400 font-bold">{vitals.stressLevel}% (منخفض)</span>
          </div>
        </div>

      </div>

      {/* Real-time ECG Stream Canvas */}
      <div
        className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 transition-all duration-300 relative overflow-hidden"
        style={{
          boxShadow: `0 0 ${15 + liveGlowOpacity * 20}px ${
            vitals.heartRate > 120 ? 'rgba(239, 68, 68, 0.25)' : 'rgba(6, 182, 212, 0.22)'
          }`,
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
            <h3 className="text-sm font-black text-white">
              {isAr ? 'مخطط النبض الكهربائي والتشتت الضوئي الحيوي (ECG / PPG Stream)' : 'Real-Time ECG / PPG Waveform Stream'}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span
              className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 font-bold flex items-center gap-1.5"
              style={{ opacity: 0.6 + liveGlowOpacity * 0.4 }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-ping" />
              <span>{isAr ? `تزامن حيوي (${vitals.heartRate} BPM)` : `Breathing Sync (${vitals.heartRate} BPM)`}</span>
            </span>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-3 py-1 rounded-full border border-cyan-800 font-bold">
              250 Hz LIVE STREAM
            </span>
          </div>
        </div>

        <div className="bg-slate-950 rounded-2xl border border-slate-800/90 p-2 overflow-hidden relative">
          <canvas ref={canvasRef} width={800} height={140} className="w-full h-32 block" />
        </div>
      </div>

      {/* Interactive Stress Spike Heat-Map Overlay */}
      <StressSpikeHeatmapOverlay
        language={language}
        onTriggerSpeech={onTriggerSpeech}
        onOpenBreathingOverlay={onOpenBreathingOverlay}
      />

      {/* Vital Roots Engine Overview Cards (Patent Claim 1 & 2) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* BP */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-bold">{isAr ? 'ضغط الدم (BP)' : 'Blood Pressure'}</span>
            <span className="text-[9px] font-mono text-slate-500">
              Max &le;{patientProfile.targetBpSystolicMax ?? 130}/{patientProfile.targetBpDiastolicMax ?? 85}
            </span>
          </div>
          <div className="text-xl font-black font-mono text-white">
            {vitals.bloodPressureSystolic} / {vitals.bloodPressureDiastolic}
            <span className="text-xs text-slate-400 font-sans ml-1">mmHg</span>
          </div>
          {vitals.bloodPressureSystolic <= (patientProfile.targetBpSystolicMax ?? 130) && vitals.bloodPressureDiastolic <= (patientProfile.targetBpDiastolicMax ?? 85) ? (
            <div className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
              ✓ {isAr ? 'ضمن الهدف المخصص' : 'Within Target Goal'}
            </div>
          ) : (
            <div className="text-[10px] text-rose-400 font-bold flex items-center gap-1 animate-pulse">
              ⚠ {isAr ? 'تجاوز الحد المستهدف' : 'Exceeds BP Target Goal'}
            </div>
          )}
        </div>

        {/* Temp */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400 font-bold">{isAr ? 'حرارة الجسم' : 'Body Temp'}</span>
          <div className="text-xl font-black font-mono text-white">
            {vitals.temperature}
            <span className="text-xs text-slate-400 font-sans ml-1">°C</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">{isAr ? 'طبيعي' : 'Normal'}</div>
        </div>

        {/* Respiratory */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400 font-bold">{isAr ? 'معدل التنفس' : 'Respiratory'}</span>
          <div className="text-xl font-black font-mono text-white">
            {vitals.respiratoryRate}
            <span className="text-xs text-slate-400 font-sans ml-1">r/m</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">{isAr ? 'عميق ومنتظم' : 'Regular'}</div>
        </div>

        {/* Vital Roots Status */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <span className="text-[11px] text-slate-400 font-bold">{isAr ? 'نموذج الجذور (Claim-01)' : 'Vital Roots'}</span>
          <div className="text-xs font-bold text-cyan-400 pt-1">
            {isAr ? 'مُدمج محلياً 100%' : '100% Local Fused'}
          </div>
          <div className="text-[10px] text-slate-500">{isAr ? 'نوم + أدوية + مناخ' : 'Sleep + Meds + Weather'}</div>
        </div>
      </div>

    </div>
  );
};
