import React, { useState } from 'react';
import { CheckCircle2, FileText, KeyRound, Lock, ShieldCheck, X } from 'lucide-react';
import { Language, LegalLedgerEntry, PatentClaimItem } from '../types';

interface PatentClaimsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  claims: PatentClaimItem[];
  ledger: LegalLedgerEntry[];
}

export const PatentClaimsModal: React.FC<PatentClaimsModalProps> = ({
  isOpen,
  onClose,
  language,
  claims,
  ledger,
}) => {
  const [activeTab, setActiveTab] = useState<'claims' | 'ledger'>('claims');
  const isAr = language === 'ar';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-[0_0_60px_rgba(6,182,212,0.2)] overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-black shadow-lg">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-white">
                  {isAr ? 'وثيقة براءة الاختراع المعتمدة (19 بنود قانونية)' : 'Official Patent Document (19 Claims)'}
                </h3>
                <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                  PATENT APPROVED
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {isAr
                  ? 'محرك الحماية الفكرية المشفر محلياً بنسبة 100% بدون أي تسريب للبيانات الحيوية'
                  : '100% Local Encrypted IP Protection Engine with Zero Data Leakage'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950 px-6 pt-3 gap-4">
          <button
            onClick={() => setActiveTab('claims')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'claims'
                ? 'text-cyan-400 border-cyan-400'
                : 'text-slate-400 border-transparent hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{isAr ? 'البنود الـ 19 الرسمية (Claims 1 - 19)' : 'Official 19 Claims'}</span>
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-2 ${
              activeTab === 'ledger'
                ? 'text-cyan-400 border-cyan-400'
                : 'text-slate-400 border-transparent hover:text-white'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>{isAr ? 'السجل القانوني المحلي (Compliance Web Ledger)' : 'Compliance Web Ledger'}</span>
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'claims' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {claims.map((claim) => (
                <div
                  key={claim.id}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 transition-all space-y-2 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
                      {claim.claimNumber}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                      <CheckCircle2 className="w-3 h-3" />
                      {isAr ? 'نشط ومفعّل' : 'ACTIVE'}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {isAr ? claim.titleAr : claim.titleEn}
                  </h4>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {isAr ? claim.summaryAr : claim.summaryEn}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                <Lock className="w-8 h-8 text-cyan-400 shrink-0" />
                <div className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'يتم توثيق كل تنبيه واستجابة للمستخدم في هذا السجل المشفّر محلياً برقم تجزئة (Cryptographic Hash). يهدف هذا السجل لإخلاء المسؤولية القانونية التشغيلية للشركة وربطها بالاستجابة الواعية للمستخدم وفقاً لـ Claim-07.'
                    : 'Every alert and user response is logged locally in this encrypted ledger using cryptographic hashes for operational compliance (Claim-07).'}
                </div>
              </div>

              <div className="space-y-2">
                {ledger.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-mono text-cyan-400 font-bold">{entry.claimRef}</span>
                      <span className="font-mono text-slate-500">{entry.timestamp}</span>
                    </div>

                    <div className="font-bold text-white">
                      {isAr ? entry.eventAr : entry.eventEn}
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-900">
                      <span className="text-slate-400">{isAr ? `تفاعل المستخدم: ${entry.userResponse}` : `Response: ${entry.userResponse}`}</span>
                      <span className="font-mono text-emerald-400 text-[10px]">Hash: {entry.encryptedHash}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-500">
          <span className="font-mono">IP REPO: SHADOW-CARE-PATENT-2026</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 transition-colors"
          >
            {isAr ? 'إغلاق الوثيقة' : 'Close Document'}
          </button>
        </div>

      </div>
    </div>
  );
};
